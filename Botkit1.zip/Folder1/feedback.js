var sdk = require("./lib/sdk");
var config = require("./config");
var _ = require('lodash');
var sub = require("./lib/RedisClient.js").createClient(config.redis);
var pub = require("./lib/RedisClient.js").createClient(config.redis);
pub.config("SET", "notify-keyspace-events", "KExA");

var os = require("os");
var hostname = os.hostname().replace(/\./g, '');

function updateRedisWithData(uuid, data) {
    var id = uuid + ":" + hostname;
    console.log("updating the redis :" + id);
    try {
        pub.set(id, JSON.stringify(data));
        pub.expire(id, 90);
        sub.subscribe("__keyspace@0__:" + id);
    } catch (Err) {
        console.log("Error in updating the redis", Err);
    }
}

sub.on('message', function (channel, msg) {
    try {
        if (msg == "expired") {
            console.log("Triggered Feedback Message to User on " + channel + " message : " + msg);
            if (channel && channel.split(":")[2] && hostname === channel.split(":")[2]) {
                var id = channel.split(":")[1];
                console.log("id", id)
                pub.get(id + ":data", function (err, reply) {
                    var data = JSON.parse(reply);
                    if (data.context && data.context.session && data.context.session.BotUserSession && data.context.session.BotUserSession.isFeedbackTriggered && data.context.session.BotUserSession.isFeedbackTriggered == data.context.session.BotUserSession.fusionSid) {
                        console.log("already triggered the feedback");
                    } else {
                        // data.context.session.BotUserSession.isFeebackTriggered = data.context.session.UserContext.secureCustomData.fusionSid;
                        data.toJSON = function () {
                            return {
                                __payloadClass: 'OnMessagePayload',
                                requestId: data.requestId,
                                botId: data.botId,
                                componentId: data.componentId,
                                sendUserMessageUrl: data.sendUserMessageUrl,
                                sendBotMessageUrl: data.sendBotMessageUrl,
                                context: data.context,
                                channel: data.channel,
                                metaInfo: {
                                    'nlMeta': {
                                        'isRefresh': true,
                                        'intent': 'Feedback'
                                    }
                                },
                                message: "Feedback",
                            }
                        }
                        console.log("Sending discard all to nl internally");
                        data.context.session.BotUserSession.isFeedbackTriggered = data.context.session.BotUserSession.fusionSid;
                        pub.set(id + ":data", JSON.stringify(data));
                        return sdk.sendBotMessage(data);
                    }
                });
            } else {
                console.log("Ignoring Other host need to handle this")
            }
        }
    } catch (err) {
        console.log("error in feedback", err);
    }
});

module.exports = updateRedisWithData;


