


var request = require('request-promise');
var _ = require('lodash');
const fs = require('fs');
const log = '/home/kore/.forever/cova.log';
const fsOpts = { flag: 'r', encoding: 'utf8' };


function IsJsonString(str) {
    try {
        JSON.parse(str);
    } catch (e) {
        return false;
    }
    return true;
}


var finalResult = [];


// function grepWithShell (file, done) {
//     const spawn = require('child_process').spawn;
//     let res = '';
//     const child = spawn('grep', [ '-e', process.argv[2], file ]);
//     child.stdout.on('data', function (buffer) { res += buffer.toString(); });
//     child.stdout.on('end', function() { done(null, res); });
// }


function makeAPI(phoneNumber, siteId, msg, index, expectedOutPut) {
    // console.log("Request is: " + JSON.stringify(req.body) + " headers " + JSON.stringify(req.headers));
    console.log(msg, index);
    var uuid = index + "_" + phoneNumber + "_" + siteId + "_" + Math.round(new Date().getTime() / 1000)
    try {
        var body = {
            "from": {
                "id": "+1" + phoneNumber + "@" + siteId
            },
            "to": {
                "id": "st-5bda0ad1-6529-5279-948e-7d70bf790d80"
            },
            "message": {
                "text": msg
            },
            "session": {
                "new": true
            },
            "siteId": siteId,
            "channelId": "SMSAG",
            "uuid": uuid
        }
        var options = {
            method: 'POST',
            url: "https://b172935-vip.nam.nsroot.net/chatbot/hooks/st-fc77c68b-a12c-5024-aae0-7aa1680690fa",
            body: body,
            json: true,
            headers: {
                'Content-Type': 'application/json',
                'Authorization': "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwiYXBwSWQiOiJjcy1iODAxZDRlOS1iNTEwLTU0ZDYtOWNjNC0xNDJmZDhlN2NiMWQifQ.-Yoh1De6cltL3WFpN7T_95Y6n-0lt_n2dIKXjFdWatU"
            }
        };
        console.log("options are ", options);
        request(options, function (error, response, body) {
            if (!error) {
                console.log('Kore response [' + response.statusCode + '] body:  ' + JSON.stringify(body));
                var botResponseText = "";
                //var resOut = body.text;
                var responseText = body.text;
                if (Array.isArray(responseText)) {
                    responseText.forEach(function (element) {
                        //console.log(" in Array " + element + " typeof element" + typeof element);
                        if (IsJsonString(element)) {
                            botResponseText = JSON.parse(element).textmessage;
                            if (botResponseText.textmessage) {
                                botResponseText = botResponseText.textmessage;
                            }
                        } else if (typeof element === 'object') {
                            botResponseText = element.textmessage;
                        } else {
                            botResponseText = element;
                        }
                    });
                } else if (responseText instanceof Object) {
                    //console.log(" in object " + element);
                    botResponseText = JSON.parse(responseText).text;
                    //animateMessage(message);
                } else {
                    // console.log(" in default " + responseText + " type of: " + typeof responseText);
                    if (IsJsonString(responseText)) {
                        botResponseText = JSON.parse(responseText).textmessage;
                        if (!botResponseText) {
                            botResponseText = JSON.parse(responseText).text;
                        }
                    } else {
                        botResponseText = responseText;
                    }
                }
                //console.log("res Output is: " + botResponseText);
                var r = {
                    "Input": msg,
                    "Expected OutPut": expectedOutPut,
                    "Actual Output": botResponseText,
                    "status": "pass"
                }
                if (expectedOutPut && expectedOutPut !== "@@@@" && botResponseText && botResponseText.includes(expectedOutPut)) {
                    console.log("Pass For" + uuid + "__Actual Output: " + botResponseText + " expected outPut: " + expectedOutPut);
                    r["status"] = "pass";
                    //}
                } else if (expectedOutPut === "@@@@") {
                    r["status"] = "pass";
                    console.log("Pass For" + uuid + "__Actual Output: " + botResponseText + " expected outPut: " + expectedOutPut);
                } else {
                    r["status"] = "fail";
                    console.log("Failed For" + uuid + "__Actual Output: " + botResponseText + " expected outPut: " + expectedOutPut);
                }
                finalResult.push(r);
            } else {
                console.log('Error happened: ' + error);
            }
        });
    } catch (err) {
        console.log("eror" + err);
    }
}

//var inputs = ["ClearSession","Hi","1183","make payment","1183","y","4","2","1","y","y","y", "3646"] 
//var inputs = ["ClearSession","Hi","1183","make payment","1183","y","4","2","1","y","y","3", "07/30/20", "3646"] // Duplicate payment date and enter date

// /var inputData = [
//     { "phoneNumber": "9729988092", "siteId": "PLCN_BESTBUY", "seq": ["ClearSession", "Discard all", "Hi", "1183", "make payment", "1183", "y"] } // BBY 9729988092 -1 Select ammount
//     , { "phoneNumber": "9729988092", "siteId": "PLCN_HOMEDPOT", "seq": ["ClearSession","Discard all", "Hi", "8098", "make payment", "8098", "y", "4"] }//THD  9729988092 -2 Enter ammout
//     , { "phoneNumber": "2145879176", "siteId": "PLCN_HOMEDPOT", "seq": ["ClearSession", "Discard all", "Hi", "8098", "make payment", "8098", "y", "4", "3"] } // THD 2145879176  -1 Date options
//     , { "phoneNumber": "2145879176", "siteId": "PLCN_BESTBUY", "seq": ["ClearSession", "Discard all", "Hi", "1183", "make payment", "1183", "y", "4", "3", "3"] }] //BBY  2145879176  -2   Enter date

// var inputData = [
//     { "phoneNumber": "9729988092", "siteId": "PLCN_BESTBUY", "seq": ["ClearSession", "Discard all", "Hi", "1183", "make payment", "1183", "y", "1"] } // -minimum due hold on date selcetion
//     , { "phoneNumber": "9729988092", "siteId": "PLCN_HOMEDEPOT", "seq": ["ClearSession", "Discard all", "Hi", "8098", "make payment", "8098", "y", "1", "2"] }// - minimum due, today- Holde on payment source
//     , { "phoneNumber": "2145879176", "siteId": "PLCN_HOMEDEPOT", "seq": ["ClearSession", "Discard all", "Hi", "8098", "make payment", "8098", "y", "1", "2", "y"] } //minimum due, today- payment source, hold on confimation
//     , { "phoneNumber": "2145879176", "siteId": "PLCN_BESTBUY", "seq": ["ClearSession", "Discard all", "Hi", "1183", "make payment", "1183", "y", "1", "2", "y", "n"] }
//     //minimum due, today- payment source,  confimation, hold on change options
//     , { "phoneNumber": "2144040745", "siteId": "PLCN_HOMEDEPOT", "seq": ["ClearSession", "Discard all", "Hi", "8098", "make payment", "8098", "y", "1", "2", "y", "n", "1"] } //minimum due, today- payment source, confimation, change options, hold on date selection
//     , { "phoneNumber": "2144040745", "siteId": "PLCN_BESTBUY", "seq": ["ClearSession", "Discard all", "Hi", "1183", "make payment", "1183", "y", "1", "2", "y", "n", "2"] }]
//minimum due, today- payment source,  confimation,  change options, hold on amount options


// var inputData = [
//     { "phoneNumber": "9729988092", "siteId": "PLCN_BESTBUY", "seq": ["2", "y", "n", "1"] } // -minimum due hold on date selcetion
//     , { "phoneNumber": "9729988092", "siteId": "PLCN_HOMEDEPOT", "seq": [ "y", "n", "2"] }// - minimum due, today- Holde on payment source
//     , { "phoneNumber": "2145879176", "siteId": "PLCN_HOMEDEPOT", "seq": ["n", "3"] } //minimum due, today- payment source, hold on confimation
//     , { "phoneNumber": "2145879176", "siteId": "PLCN_BESTBUY", "seq": ["1"] }
//     //minimum due, today- payment source,  confimation, hold on change options
//     , { "phoneNumber": "2144040745", "siteId": "PLCN_HOMEDEPOT", "seq": ["3", "08/7/20", "Yes"] } //minimum due, today- payment source, confimation, change options, hold on date selection
//     , { "phoneNumber": "2144040745", "siteId": "PLCN_BESTBUY", "seq": ["4", "10", "yes"] }]



//var duplicatePaymentDateMinimumAmmout = ["ClearSession","Hi","1183","make payment","1183","y","4","2","1","y","y","3", "07/31/20","Yes", "3646"] // Duplicate payment date and enter date and minimum ammout

var makePayment = {
    "happyPath": {
        "phoneNumber": "9729988092",
        "siteId": "PLCN_BESTBUY",
        "input": [
            // "ClearSession",
            "Discard all",
            // "Hi",
            //"1183",
            "make payment",
            "1183",
            "Yes",
            "4",
            "3",
            "3",
            "07/25/2020",
            "Yes",
            "Yes",
            "Yes",
            "6789"
        ],
        "output": [
            // "context",
            "discarding the task for now",
            //"*",
            // "Hi, I'm your virtual guide to ",
            // "@@@@",
            "Which account do you want to pay?",
            "Before we begin, you should know that your account information, including last statement balance, current balance and minimum payment due, will be displayed on this device and any other device where you receive text messages. Do you want to continue and allow this information to be displayed?",
            "It looks like",
            "Please enter the amount of payment greater than $1 in $xx.xx format",
            "When do you want to make a payment",
            "Please enter a valid date in MM/DD/YYYY format",
            "We have your  account information from previous payments you have made",
            "Almost done: let's confirm the payment information and get your authorization to make the payment.",
            "If you choose to pay less than the Minimum Payment Due and do not make any additional payments, your account will be past due. You will also pay more in interest and it will take you longer to pay off your balance.\n\nTo avoid a late fee, schedule your Payment Date no later than your Payment Due Date.$$$$2/2. Would you like to continue and make a payment. \nText Y to make a payment\nText N to stop the payment communication.",
            "Do I have your authorization to take this payment now?\nPlease text the last 4 digits of the primary account holder's SSN to authorize this payment.\nText N if you do not authorize this payment.",
            "Your payment was successful $$$$ Is there anything else I can help you with today?"
        ]
    }
}
var inputs = makePayment.happyPath;
function callMakePaymet() {
    //inputData.forEach(function (inputs) {
    //console.log("inputs ", JSON.stringify(inputs))
    setTimeout(() => {
        var i = 0;
        var l = inputs.input.length;
        (function iterator() {
            console.log(inputs.input[i]);
            makeAPI(inputs.phoneNumber, inputs.siteId, inputs.input[i], i, inputs.output[i])
            if (++i < l) {
                setTimeout(iterator, 6000);
            }else{
                console.log(JSON.stringify(finalResult));
            }
        })();
        //  }, 100000);
    });
}
callMakePaymet();










