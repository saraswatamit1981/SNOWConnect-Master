var request = require('request-promise');
var config = require("./config");
var _ = require('lodash');
var cuProxy = require("./cuproxy");

function getAccountDetails(uuid, mobileNumber, siteId) {
    console.log("getAccountDetails", mobileNumber, siteId, uuid);
    if (mobileNumber && mobileNumber.length) {
        mobileNumber = mobileNumber.split("@");
        mobileNumber = mobileNumber[0];
    }
    try {
        var rbody = {
            "phoneNumber": mobileNumber.replace("+1", "")
        }
        var options = {
            method: 'POST',
            body: rbody,
            url: config.accountApi.endPoint,
            json: true,
            headers: {
                'content-type': 'application/json',
                "countryCode": config.accountApi.countryCode,
                "businessCode": config.accountApi.businessCode,
                "channelId": config.accountApi.channelId,
                "client_id": config.accountApi.clientId,
                "uuid": uuid ? uuid: cuProxy.uuid(),
                "siteId": siteId,
                "authorization": cuProxy.getJWTToken().access_token,
                "accesstoken": cuProxy.getJWTToken().metadata.replace("a:", "")
            }
        };
        console.log("Fusion Account look up API Options:" + JSON.stringify(options));
        return request(options).then(function (res) {
            console.log("Fusion Account look up API Response is" + JSON.stringify(res));
            return res; // you can read response here
        }).catch(function (err) {
            console.log("###Error while calling the account details", err);
            return [];
        });
    } catch (Err) {
        console.error("###Error while calling the account details", Err);
        return [];
    }
}




function makeKoreAPICall(req, res) {
    var options = {
        method: 'POST',
        url: config.kore.api,
        body: req.body,
        json: true,
        headers: {
            'Content-Type': 'application/json',
            'Authorization': config.koreAuthToken
        }
    };
    console.log("options are ", options);
    request(options, function (error, response, body) {
        if (!error) {
            console.log('Kore response [' + response.statusCode + '] body:  ' + body);
            res.status(200).jsonp({
                "code": "ok"
            })
        } else {
            console.log('Error happened: ' + error);
            res.status(500).jsonp({
                "code": "INTERNAL SERVER ERROR",
                "message": "The request failed due to an internal error/server unavailability"
            })
        }
    });
}


function IVRSProxy(req, res) {
    console.log("IVR Request is: " + JSON.stringify(req.body) + " headers " + JSON.stringify(req.headers));
    try {
        if (!(req.body.to && req.body.to.id)) {
            return res.status(400).jsonp({
                "code": "Missing Parameters",
                "message": "Bot Id is missing"
            })
        }
        if (!(req.body.from && req.body.from.id)) {
            return res.status(400).jsonp({
                "code": "Missing Parameters",
                "message": "From mobile number is missing"
            })
        }
        if (!(req.body.from && req.body.from.id)) {
            return res.status(400).jsonp({
                "code": "Missing Parameters",
                "message": "From mobile number is missing"
            })
        }
        if (!req.body.accountNumber) {
            return res.status(400).jsonp({
                "code": "Missing Parameters",
                "message": "AccountNumber number is missing"
            })
        }
        if (req.body.from.id.includes("+1")) {
            console.log("Mobile number has the +1" + req.body.from.id);
        } else {
            req.body["from"]["id"] = "+1" + req.body.from.id;
        }

        req.body["channelId"] = "IVR"
        var siteId = req.body["siteId"];
        if (siteId && config.siteIds[siteId]) {
            req.body["siteId"] = config.siteIds[siteId];
            req.body["from"]["id"] = req.body["from"]["id"] + "@" + req.body["siteId"];
        } else {
            return res.status(400).jsonp({
                "code": "Missing Parameters",
                "message": "Invalid SiteId" + req.body["siteId"]
            })
        }

        if (!(req.body && req.body.uuid)) {
            if (req.headers && req.headers.uuid) {
                req.body.uuid = req.headers.uuid;
            } else {
                let UUID = cuProxy.uuid();
                console.log("No UUID in headers or body generating the new UUID from Kore"+ UUID)
                req.body.uuid = UUID;
            }
        }
        if (req.body.message && req.body.message.text.includes("ICCA_")) {
            getAccountDetails(req.body.uuid, req.body["from"]["id"], req.body["siteId"]).then((response) => {
                if (response && response.accountDetailsList) {
                    let accountDetailsList = response.accountDetailsList;
                    let accountObj = accountDetailsList.find(o => o.accountNumber === req.body.accountNumber);
                    console.log("account obj from fusion ", JSON.stringify(accountObj));
                    if (accountObj) {
                        req.body["ssnLast4"] = accountObj.ssnLast4;
                        return makeKoreAPICall(req, res);
                    } else {
                        console.log("SSN is empaty", req.body.accountNumber);
                        return res.status(422).jsonp({
                            "code": "Accountnumber has the SSN issue ",
                            "message": "SSN number wasn't configured"
                        })
                    }
                }else{
                    console.log("No accounts associted with this phone number");
                    return res.status(422).jsonp({
                        "code": "Invalid accountnumber",
                        "message": "No accounts associted with this phone number"
                    })
                }
            });
        } else {
            return makeKoreAPICall(req, res);
        }

    } catch (err) {
        console.log("eror" + err);
        res.status(500).jsonp({
            "code": "INTERNAL SERVER ERROR",
            "message": "The request failed due to an internal error/server unavailability"
        })
    }
}
module.exports = IVRSProxy;




