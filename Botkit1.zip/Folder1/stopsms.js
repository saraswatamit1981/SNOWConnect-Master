var sdk = require("./lib/sdk");
var config = require("./config");
var cuProxy = require("./cuproxy");

var request = require('request-promise');

var sub = require("./lib/RedisClient.js").createClient(config.redis);
var pub = require("./lib/RedisClient.js").createClient(config.redis);
pub.config("SET", "notify-keyspace-events", "KExA");

var os = require("os");
var hostname = os.hostname().replace(/\./g, '');


function updateRedisWithData(uuid, data) {
    var stopuuid = "Stop/" + uuid;
    console.log("Updating the stop  in redis: " + stopuuid);
    try {
        pub.set(stopuuid, hostname, "EX", 43200);
        sub.subscribe("__keyspace@0__:" + stopuuid);
        if (data.context.session.BotUserSession.lastMessage.messagePayload.message.body === "2") {
            if (pub.get(stopuuid)) {
                pub.del(stopuuid);
            }
        }
    } catch (Err) {
        console.log("Error in updating stop redis " + stopuuid, Err);
    }
}

sub.on('message', function (channel, msg) {
    try {
        if (msg == "expired") {
            console.log("Triggered stopsms Message event for User on " + channel + " message : " + msg);
            // if (channel && channel.split(":")[2] && hostname === channel.split(":")[2]) {
            var id = channel.split(":")[1];
            console.log("Stop user Id is: ", id)
            pub.get(id.replace("Stop/", ""), function (err, reply) {                
                var data1 = JSON.parse(reply);
                stopAPICall(data1, "From Redis");
            });
            // }
        }
    } catch (err) {
        console.log("error in stopsms", err);
    }
});



function stopAPICall(data, type) {
    try {
        if (data) {
            console.log("##########" + JSON.stringify(data) + "type: " + type)
            var ph = data.context.session.BotUserSession.lastMessage.messagePayload.from.id;
            var uuid = data.context.session.BotUserSession.lastMessage.messagePayload.uuid;
            ph = ph.split("@");
            ph = ph[0];
            var requestData = {
                "sourceApplicationId": config.connect.sourceApplicationId,
                "preferredLanguageCode": config.connect.preferredLanguageCode,
                "lineOfBusinessCode": config.connect.lineOfBusinessCode,
                "eligibilityOverrideFlag": "false",
                "campaignName": config.connect.campaignName,
                "smsMessageData": "Stop",
                "smsMessageType": "STOP_WITH_NOCONFIRM",
            }
            requestData["phone"] = {
                "phoneNumber": ph.replace("+1", "")
            }
            requestData["accountInfo"] = {
                "accountNumber": data.context.session.BotUserSession.AccountNumber
            }
            requestData["portfolio"] = data.context.session.BotUserSession.lastMessage.messagePayload.siteId
            var options = {
                method: 'POST',
                url: config.connect.api,
                body: requestData,
                json: true,
                headers: {
                    'Content-Type': 'application/json',
                    'uuid': uuid ? uuid : cuProxy.uuid(),
                    'Authorization': "Bearer " + cuProxy.getJWTToken().access_token,
                    'countryCode': config.connect.countryCode,
                    'businessCode': config.connect.businessCode,
                    'channelId': config.connect.channelId,
                    'Accept': 'application/json',
                    'client_id': config.connect.clientId,
                    'accessToken': cuProxy.getJWTToken().metadata.replace("a:", "")
                }
            };
            console.log(type + " #######options are stopsms######", options);
            try {
                request(options, function (error, response, body) {
                    if (!error) {
                        console.log('CU response for stop [' + response.statusCode + '] body:  ' + body);
                        if (response.statusCode === 422) {
                            console.log("Trying Second attempt with same request for stop");
                            request(options, function (error, response, body) {
                                if (!error) {
                                    console.log('Second attempt for Stop CU response [' + response.statusCode + '] body:  ' + JSON.stringify(body));
                                }
                            });
                        }
                    } else {
                        console.log('Error happened in stopsms ' + error);
                    }
                });
            } catch (err) {
                console.log("error in stopsms", err);
            }
        }else{
           console.log("########## Data is empty for the stop type: " + type)
        }
    } catch (err) {
        console.log("Error occured in stopsms :" + type, err);
    }
}

module.exports = {
    updateRedisWithData,
    stopAPICall
}







