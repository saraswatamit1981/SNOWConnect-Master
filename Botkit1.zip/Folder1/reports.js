


var mongoUtil = require('./mongoUtil');
var request = require("request");
var config = require("./config");



function getReports(req, res) {
    console.log("Request is: " + JSON.stringify(req.query) + " headers " + JSON.stringify(req.headers));
    try {
        var fromDate = req.query.fromDate;
        var toDate = req.query.toDate;
        var siteId = req.query.siteId;
        var channel = req.query.channel;
        var type = req.query.type;

        if (!fromDate) {
            return res.status(400).jsonp({
                "code": "Missing Parameters",
                "message": "fromDate is missing"
            })
        }
        if (!toDate) {
            return res.status(400).jsonp({
                "code": "Missing Parameters",
                "message": "toDate is missing"
            })
        }
        var db = mongoUtil.getDb();
        if (db) {
            var collection = db.collection('reports');
            var query = {
                "timestamp": {
                    "$gte": new Date(fromDate),
                    "$lt": new Date(toDate)
                }
            };

            if (channel && channel.toLowerCase() != 'all') {
                query["channel"] = channel.toLowerCase();
            }

            if (siteId) {
                query["siteId"] = siteId;
            }

            if (type && type.toLowerCase() != 'all') {
                query["type"] = type.toLowerCase();
            }
            console.log(JSON.stringify(query) + "Querry start time: " + new Date().getTime());
            collection.find(query).toArray().then((reports) => {
                console.log("size is: " + reports.length + " Querry end time: " + new Date().getTime());
                if (siteId) {
                    var counts = {};
                    for (var i = 0; i < reports.length; i++) {
                        counts[reports[i].intent] = (counts[reports[i].intent] || 0) + 1;
                    }
                    res.status(200).jsonp({
                        "status": "success",
                        "message": "successfully retrived the " + siteId + " partner records",
                        "data": counts
                    })
                    console.log(JSON.stringify(counts));
                } else {
                    var uniqueSiteIds = [...new Set(reports.map(item => item.siteId))];
                    console.log(uniqueSiteIds);
                    var counts = {};
                    var users = {};
                    var tasks = {}
                    for (k in uniqueSiteIds) {
                        if (uniqueSiteIds[k]) {
                            console.log("uniqueSiteId is:  " + uniqueSiteIds[k])
                            var count = reports.filter(function (v) {
                                return v.siteId == uniqueSiteIds[k]
                            });
                            counts[uniqueSiteIds[k]] = {};
                            users[uniqueSiteIds[k]] = [...new Set(count.map(item => item.userId))].length;
                        }
                    }
                    var taskMap = {};
                    console.log("Users parsing End time: " + new Date().getTime());
                    for (var i = 0; i < reports.length; i++) {
                        if (reports[i].siteId) {
                            counts[reports[i].siteId][reports[i].intent] = (counts[reports[i].siteId][reports[i].intent] || 0) + 1;
                            let d = reports[i].timestamp.toLocaleDateString();
                            taskMap[reports[i].siteId] = taskMap[reports[i].siteId] || {};
                            taskMap[reports[i].siteId][d] = taskMap[reports[i].siteId][d] || 0;
                            taskMap[reports[i].siteId][d]++;
                        }

                    }
                    console.log("Tasks parsing End time: " + new Date().getTime());
                    var response = {
                        "taskSequnce": taskMap,
                        "users": users,
                        "tasks": counts
                    }
                    res.status(200).jsonp({
                        "status": "success",
                        "message": "successfully retrived all the partners records",
                        "data": response
                    })
                }
            }).catch((err) => {
                console.log(err);
                res.status(500).jsonp({
                    "status": "error",
                    "message": "The request failed due to an internal error/server unavailability"
                })
            })
        } else {
            console.log("No DB connection");
            res.status(500).jsonp({
                "code": "INTERNAL SERVER ERROR",
                "message": "The request failed due to an lack of DB connection please try again after sometime"
            })
        }
    } catch (err) {
        console.log("eror" + err);
        res.status(500).jsonp({
            "code": "INTERNAL SERVER ERROR",
            "message": "The request failed due to an internal error/server unavailability"
        })
    }
}



function getFeedbackReports(req, res) {
    console.log("Request is: " + JSON.stringify(req.query) + " headers " + JSON.stringify(req.headers));
    try {
        var fromDate = req.query.fromDate;
        var toDate = req.query.toDate;
        var siteId = req.query.siteId;
        var channel = req.query.channel;
        var type = req.query.type;

        if (!fromDate) {
            return res.status(400).jsonp({
                "code": "Missing Parameters",
                "message": "fromDate is missing"
            })
        }
        if (!toDate) {
            return res.status(400).jsonp({
                "code": "Missing Parameters",
                "message": "toDate is missing"
            })
        }
        var db = mongoUtil.getDb();
        if (db) {
            var collection = db.collection('feedback');
            var query = {};
            let timestamp = {
                "$gte": new Date(fromDate),
                "$lt": new Date(toDate)
            };

            query["timestamp"]= timestamp;
            if (channel && channel.toLowerCase() != 'all') {
                query["channel"] = channel.toLowerCase();
            }

            if (siteId) {
                query["siteId"] = siteId;
            }

            if (type && type.toLowerCase() != 'all') {
                query["type"] = type.toLowerCase();
            }
            console.log(JSON.stringify(query) + "Querry start time: " + new Date().getTime());
            collection.find({"timestamp":{"$gte": new Date(fromDate),"$lt": new Date(toDate)}}).toArray().then((reports) => {
                console.log("size is: " + reports.length);
                var summary = {
                    "all": {
                        "feedback": {},
                        "experience": {},
                    }
                };
                var uniqueSiteIds = [...new Set(reports.map(item => item.siteId))];

                for (k in uniqueSiteIds) {
                    if (uniqueSiteIds[k]) {
                        console.log("uniqueSiteId is:  " + uniqueSiteIds[k])
                        summary[uniqueSiteIds[k]] = {
                            "feedback": {},
                            "experience": {},
                            "comments": []
                        };
                    }

                }
                for (var i = 0; i < reports.length; i++) {
                    if (reports[i].siteId) {
                        if (reports[i].feedbackId) {
                            summary[reports[i].siteId]["feedback"][reports[i].feedbackId] = (summary[reports[i].siteId]["feedback"][reports[i].feedbackId] || 0) + 1;
                            summary["all"]["feedback"][reports[i].feedbackId] = (summary["all"]["feedback"][reports[i].feedbackId] || 0) + 1;
                        }
                        if (reports[i].experienceId) {
                            summary[reports[i].siteId]["experience"][reports[i].experienceId] = (summary[reports[i].siteId]["experience"][reports[i].experienceId] || 0) + 1;
                            summary["all"]["experience"][reports[i].experienceId] = (summary["all"]["experience"][reports[i].experienceId] || 0) + 1;
                        }
                        if (reports[i].comments) {
                            summary[reports[i].siteId]["comments"].push(reports[i]);
                        }
                    }
                }

                res.status(200).jsonp({
                    "status": "success",
                    "message": "successfully retrived all the partner feedback records",
                    "data": summary
                })
            }).catch((err) => {
                console.log(err);
                res.status(500).jsonp({
                    "status": "error",
                    "message": "The request failed due to an internal error/server unavailability"
                })
            })
        } else {
            console.log("No DB connection");
            res.status(500).jsonp({
                "code": "INTERNAL SERVER ERROR",
                "message": "The request failed due to an lack of DB connection please try again after sometime"
            })
        }
    } catch (err) {
        console.log("eror" + err);
        res.status(500).jsonp({
            "code": "INTERNAL SERVER ERROR",
            "message": "The request failed due to an internal error/server unavailability"
        })
    }
}


function addFeedback(req, res) {
    console.log("Request is: " + JSON.stringify(req.body) + " headers " + JSON.stringify(req.headers));
    try {
        var db = mongoUtil.getDb();
        if (db) {
            db.collection('feedback').insertOne(req.body, (err, result) => {
                if (err) {
                    console.log("Unable to save the data" + err)
                    res.status(500).jsonp({
                        "status": "error",
                        "message": "The request failed due to an internal error/server unavailability"
                    })
                } else {
                    console.log('saved to database')
                    res.status(200).jsonp({
                        "status": "success",
                        "message": "successfully inserted the feedback"
                    })
                }
            })
        } else {
            console.log("No DB connection");
            res.status(500).jsonp({
                "code": "INTERNAL SERVER ERROR",
                "message": "The request failed due to an lack of DB connection please try again after sometime"
            })
        }
    } catch (err) {
        console.log("eror" + err);
        res.status(500).jsonp({
            "code": "INTERNAL SERVER ERROR",
            "message": "The request failed due to an internal error/server unavailability"
        })
    }
}

module.exports = {
    getReports,
    getFeedbackReports,
    addFeedback
};




