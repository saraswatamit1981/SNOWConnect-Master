var _ = require('lodash');
var request = require('request-promise');
var errors = require('request-promise/errors')

function validationErrorsAPI(req, response) {
    // console.log(req.headers.uuid + " :: Proxy API: " + JSON.stringify(req.body) + " headers " + JSON.stringify(req.headers));
    console.log("Validation Error from request headers :: " + JSON.stringify(req.headers.validationerror))
    try {
        var validation_error = req.headers.validationerror;
        var makePayApiResponse = {
            "accountSummary": {
                "billingDetails": {
                    "firstName": "SMITH",
                    "middleName": null,
                    "lastName": "TEST",
                    "suffix": null,
                    "billingAddress": {
                        "addressLine1": "1656 152ND ST S",
                        "addressLine2": null,
                        "city": "SPANAWAY",
                        "state": "WA",
                        "postalCode": "*****-****",
                        "countryCode": null
                    }
                },
                "minimumPaymentDueAmount": 27,
                "paymentDueDate": "2020-05-13",
                "pastDueAmount": 0,
                "currentBalanceAmount": 227,
                "lastStatementBalanceAmount": 200,
                "nextStatementDate": "2020-05-17",
                "availableCreditAmount": 13073,
                "creditLimitAmount": 13300,
                "financeChargeAmount": 200,
                "forbearanceFlag": false,
                "disputeAmount": 0
            },
            "addPaymentDetails": [
                {
                    "paymentDetails": {
                        "paymentDate": "2020-05-13",
                        "paymentAmount": {
                            "amountPaymentOption": null,
                            "paymentAmount": 3,
                            "paymentOptionDisplayName": null,
                            "paymentOptionValueFlag": null,
                            "paymentOptionAmountAdjustmentText": null,
                            "allowedPromotionalBalanceIds": null
                        },
                        "bankAccount": {
                            "confirmationNumber": "240116142084479",
                            "accountHolder": null,
                            "accountNickname": "",
                            "defaultAccountFlag": true,
                            "accountType": "CHECKING",
                            "accountTypeDisplayName": null,
                            "bankName": "U.S. BANK NATIONAL ASSOCIATION",
                            "routingNumber": "*****0453",
                            "accountNumber": "******3210"
                        },
                        "debitCard": null,
                        "savePaymentInfo": null,
                        "promotionalBalanceAllocations": null
                    },
                    "confirmationNumber": null,
                    "validationErrors": [
                        {
                            "fieldName": validation_error,
                            "message": "The date you have selected has already past. Please select the current date or a future date.",
                            "wcagMessage": "commonwealth.payment.date.behavioralDateOptions"
                        }
                    ],
                    "paymentWarnings": []
                }
            ],
            "paymentHistory": {
                "pendingPayments": [],
                "pastPayments": [],
                "promiseToPays": null
            },
            "bankName": null,
            "partnerName": "Sears",
            "productName": "Sears Mastercard card",
            "emailAddress": "",
            "validPaymentDates": [
                "2020-05-14",
                "2020-05-15",
                "2020-05-16",
                "2020-05-17",
                "2020-05-18",
                "2020-05-19",
                "2020-05-20",
                "2020-05-21",
                "2020-05-22",
                "2020-05-23",
                "2020-05-24",
                "2020-05-25",
                "2020-05-26",
                "2020-05-27",
                "2020-05-28",
                "2020-05-29",
                "2020-05-30",
                "2020-05-31",
                "2020-06-01",
                "2020-06-02",
                "2020-06-03",
                "2020-06-04",
                "2020-06-05",
                "2020-06-06",
                "2020-06-07",
                "2020-06-08",
                "2020-06-09",
                "2020-06-10",
                "2020-06-11",
                "2020-06-12",
                "2020-06-13",
                "2020-06-14",
                "2020-06-15",
                "2020-06-16",
                "2020-06-17",
                "2020-06-18",
                "2020-06-19",
                "2020-06-20",
                "2020-06-21",
                "2020-06-22",
                "2020-06-23",
                "2020-06-24",
                "2020-06-25",
                "2020-06-26",
                "2020-06-27",
                "2020-06-28"
            ],
            "validPromoPaymentDates": null,
            "uuid": "782be2fe-1a1e-4070-8876-2de5eb48b334",
            "validPaymentMethods": [
                {
                    "type": "CHECKING",
                    "displayName": "Checking"
                },
                {
                    "type": "SAVINGS",
                    "displayName": "Savings/Money Market"
                }
            ],
            "validPaymentAmounts": [
                {
                    "amountPaymentOption": "MIN_PAYMENT_DUE",
                    "paymentAmount": 27,
                    "paymentOptionDisplayName": "Minimum Payment Due",
                    "paymentOptionValueFlag": false,
                    "paymentOptionAmountAdjustmentText": "",
                    "allowedPromotionalBalanceIds": null
                },
                {
                    "amountPaymentOption": "CURRENT_BALANCE",
                    "paymentAmount": 227,
                    "paymentOptionDisplayName": "Current Balance",
                    "paymentOptionValueFlag": false,
                    "paymentOptionAmountAdjustmentText": "",
                    "allowedPromotionalBalanceIds": null
                },
                {
                    "amountPaymentOption": "TOTAL_AMOUNT_DUE",
                    "paymentAmount": 0,
                    "paymentOptionDisplayName": "Past Due",
                    "paymentOptionValueFlag": false,
                    "paymentOptionAmountAdjustmentText": "",
                    "allowedPromotionalBalanceIds": null
                },
                {
                    "amountPaymentOption": "FULL_BALANCE_PLUS_AUTHORIZATIONS",
                    "paymentAmount": 227,
                    "paymentOptionDisplayName": "Full Balance + Authorizations",
                    "paymentOptionValueFlag": false,
                    "paymentOptionAmountAdjustmentText": "",
                    "allowedPromotionalBalanceIds": null
                },
                {
                    "amountPaymentOption": "OTHER",
                    "paymentAmount": 0,
                    "paymentOptionDisplayName": "Different Amount",
                    "paymentOptionValueFlag": true,
                    "paymentOptionAmountAdjustmentText": "",
                    "allowedPromotionalBalanceIds": null
                }
            ],
            "validAutopayOptions": [
                {
                    "amountPaymentOption": "MIN_PAYMENT_DUE",
                    "paymentOptionDisplayName": "Minimum Payment Due",
                    "paymentOptionValueFlag": false
                },
                {
                    "amountPaymentOption": "LAST_STMT_BALANCE",
                    "paymentOptionDisplayName": "Statement Balance in Full",
                    "paymentOptionValueFlag": false
                },
                {
                    "amountPaymentOption": "MIN_PAYMENT_DUE_PLUS_OTHER",
                    "paymentOptionDisplayName": "Minimum  Payment Due + Extra Amount",
                    "paymentOptionValueFlag": true
                },
                {
                    "amountPaymentOption": "OTHER_AMOUNT_OR_MIN_DUE",
                    "paymentOptionDisplayName": "Other Amount",
                    "paymentOptionValueFlag": true
                }
            ],
            "autopayEnrolledFlag": false,
            "autopayEligibleFlag": false,
            "validBankAccounts": [
                {
                    "confirmationNumber": "240116142084479",
                    "accountHolder": {
                        "firstName": "SMITH",
                        "middleName": null,
                        "lastName": "TEST",
                        "suffix": null,
                        "billingAddress": {
                            "addressLine1": "1656 152ND ST S",
                            "addressLine2": null,
                            "city": "SPANAWAY",
                            "state": "WA",
                            "postalCode": "*****-****",
                            "countryCode": null
                        }
                    },
                    "accountNickname": "",
                    "defaultAccountFlag": false,
                    "accountType": "CHECKING",
                    "accountTypeDisplayName": "Checking",
                    "bankName": "U.S. BANK NATIONAL ASSOCIATION",
                    "routingNumber": "*****0453",
                    "accountNumber": "******3210"
                }
            ],
            "validDebitCards": [],
            "validAutoPayBankAccounts": [
                {
                    "confirmationNumber": "240116142084479",
                    "accountHolder": {
                        "firstName": "SMITH",
                        "middleName": null,
                        "lastName": "TEST",
                        "suffix": null,
                        "billingAddress": {
                            "addressLine1": "1656 152ND ST S",
                            "addressLine2": null,
                            "city": "SPANAWAY",
                            "state": "WA",
                            "postalCode": "*****-****",
                            "countryCode": null
                        }
                    },
                    "accountNickname": "",
                    "defaultAccountFlag": false,
                    "accountType": "CHECKING",
                    "accountTypeDisplayName": "Checking",
                    "bankName": "U.S. BANK NATIONAL ASSOCIATION",
                    "routingNumber": "*****0453",
                    "accountNumber": "******3210"
                }
            ],
            "validAutoPayDebitCards": null,
            "paymentSourceSaveEligibleFlag": false,
            "verificationTextOption": null,
            "uiPermissions": [
                "SUBMIT_PAYMENT",
                "EDIT_PAYMENT",
                "DELETE_PAYMENT",
                "ADD_PAYMENT_SOURCE",
                "EDIT_PAYMENT_SOURCE",
                "DELETE_PAYMENT_SOURCE"
            ],
            "paymentFlag": false,
            "pastDueFlag": false,
            "authorizationMessage": {
                "messageId": "commonwealth.payments.PaymentVerificationScript",
                "messageText": "Just to confirm, today is 05/14/2020 and you are agreeing to a one-time payment of $3.00 towards your Sears Mastercard card ending in 73, from your bank account ending in 3210, posting on 05/13/2020.<br /><br />You may cancel or change this payment online or by calling us back at this number before 5:00 p.m. Eastern time on the payment date. <br /><br />Do I have your authorization to make this payment in accordance with the Pay by Phone terms in your statement?",
                "wcagMessageText": ""
            },
            "confirmationMessage": null,
            "offerMessage": null,
            "dynamicCopies": null
        }
	if(validation_error == "nothing")
                delete makePayApiResponse.addPaymentDetails[0].validationErrors
        return response.status(200).jsonp(makePayApiResponse);
    } catch (Err) {
        console.log(" :: Err while making validation error  Proxy API", Err);
        return response.status(500).jsonp({ "code": "INTERNAL SERVER ERROR", "message": "The request failed due to an internal error/server unavailability" });
    }
}


module.exports = {
    validationErrorsAPI
}

