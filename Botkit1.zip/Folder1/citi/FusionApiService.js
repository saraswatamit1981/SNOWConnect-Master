
var config = require("./../config");
var _ = require('lodash');
var cuProxy = require("./../cuproxy");
var request = require('request-promise');
var errors = require('request-promise/errors')

function proxyAPI(req, response) {
    console.log(req.headers.uuid + " :: Proxy API: " + JSON.stringify(req.body) + " headers " + JSON.stringify(req.headers));
    try {
        var options = {
            method: 'POST',
            body: req.body,
            url: req.headers.url,
            json: true,
            headers: {
                'content-type': 'application/json',
                "countryCode": config.accountApi.countryCode,
                "businessCode": config.accountApi.businessCode,
                "channelId": config.accountApi.channelId,
                "client_id": config.accountApi.clientId,
                "uuid": req.headers.uuid,
                "siteId": req.headers.siteid,
                "authorization": "Bearer " + cuProxy.getJWTToken().access_token,
                "accesstoken": cuProxy.getJWTToken().metadata.replace("a:", ""),
                "Accept-Language": "en_US",
                "Accept": "application/json",
                "resolveWithFullResponse": true,
                "simple": false
            }
        };
        console.log(req.headers.uuid + " :: Proxy API Options:" + JSON.stringify(options));
        return request(options).then(function (res) {
            console.log(req.headers.uuid + " ::  Proxy API Response is" + JSON.stringify(res));
           return response.status(200).jsonp(res); // you can read response here
//          return response.status(500).jsonp(res);
	}).catch(errors.StatusCodeError, function (reason) {
            // The server responded with a status codes other than 2xx.
            console.log(req.headers.uuid + " ::  Proxy API Responded with a status codes other than 2xx " + JSON.stringify(reason));
            if (reason.response) {
                return response.status(reason.response.statusCode).jsonp(reason.response.body);
            } else {
                return response.status(reason.statusCode).jsonp(reason.message);
            }
        }).catch(function (err) {
            console.log(req.headers.uuid + " :: Error while calling  Proxy API", err);
            return response.status(500).jsonp({ "code": "INTERNAL SERVER ERROR", "message": "The request failed due to an internal error/server unavailability" });
        });
    } catch (Err) {
        console.log(req.headers.uuid + " :: Err while calling  Proxy API", Err);
        return response.status(500).jsonp({ "code": "INTERNAL SERVER ERROR", "message": "The request failed due to an internal error/server unavailability" });
    }
}


module.exports = {
    proxyAPI
}



