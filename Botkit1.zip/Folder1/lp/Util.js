
var sdk = require("./../lib/sdk");
var config = require("./../config");
var redisClient = require("./../lib/RedisClient.js").createClient(config.redis);
const AgentService = require('./AgentService')
var _ = require('lodash');
var Promise = sdk.Promise;



function IsJsonString(str) {
    try {
        JSON.parse(str);
    } catch (e) {
        return false;
    }
    return true;
}

function getNotificationConversationId(notification) {
    var noConversationId = "";
    try {
        if (notification.body.changes[0].hasOwnProperty("conversationId")) {
            return notification.body.changes[0].conversationId;
        } else if (
            notification.body.changes[0].hasOwnProperty("result") &&
            notification.body.changes[0].result.hasOwnProperty("convId")
        ) {
            return notification.body.changes[0].result.convId;
        }
    } catch (err) {
        console.log(" ERROR parsing notification JSON, the conversation ID cannot be found " + err);
    }
    return noConversationId;
}


function roleExists(arr, role) {
    return arr.some(function (el) {
        return el.role === role;
    });
}


function clearAgentRedisData(visitorId, convId) {
    console.log("clearing the Agent data of visitorId: " + visitorId + " convId: " + convId);
    try {
        redisClient.hdel("LIVEPERSON", convId, function (err, res) {
            console.log("agent data deleted success: ", convId)
        });
        redisClient.hdel("LIVEPERSON", visitorId, function (err, res) {
            console.log("bot data deleted success: ", visitorId)
        });
        redisClient.hdel("LIVEPERSON_TOKENS", convId, function (err, res) {
            console.log("tokens data deleted success: ", convId)
        });
    } catch (err) {
        console.log("Error occured while clearing the data from redis", err);
    }
}


function sendCustomUserMessage(data, message) {
    data.toJSON = function () {
        return {
            __payloadClass: "OnMessagePayload",
            requestId: data.requestId,
            botId: data.botId,
            componentId: data.componentId,
            sendUserMessageUrl: data.sendUserMessageUrl,
            sendBotMessageUrl: data.sendBotMessageUrl,
            context: data.context,
            channel: data.channel,
            message: message
        };
    };
    console.log("Bot requestId is: " + data.requestId);
    return sdk.sendUserMessage(data);
}


function gethistory(data) {
    try {
        if (data) {
            console.info("getUserHistory UserId: ", data.context.session.UserContext._id);
            var _data = {
                baseUrl: data.baseUrl,
                userId: data.context.session.UserContext._id,
                limit: 50
            };
            console.log(JSON.stringify(_data));
            return sdk.getMessages(_data, function (err, resp) {
                if (err) {
                    console.log(err);
                }
                var messages = resp.messages;
                return messages;
            });
        } else {
            console.log("Data is empty")
        }
    } catch (err) {
        console.log("Error while getting the history.")
    }
}
function lpNotification(notification) {
    try {
        var convId = getNotificationConversationId(notification);
        console.log("conversationId is: " + convId);
        redisClient.hget("LIVEPERSON", convId, function (err, data) {
            data = JSON.parse(data);
            if (data) {
                var visitorId = _.get(data, "channel.channelInfos.from");
                if (!visitorId) {
                    visitorId = _.get(data, "channel.from");
                }
                if (notification.body.changes[0].event && notification.body.changes[0].event.type && notification.body.changes[0].event.type === "ChatStateEvent") {
                    if (notification.body.changes[0].event.chatState == "COMPOSING") {
                        console.log("LP Agent COMPOSING Notification: " + convId + " UserId: " + visitorId);
                        return;
                    } else if (notification.body.changes[0].event.chatState == "ACTIVE") {
                        console.log("LP Agent ACTIVE  Notification: " + convId + " UserId: " + visitorId);
                        return;
                    }
                } else if (notification.body.changes[0].event && notification.body.changes[0].event.type && notification.body.changes[0].event.type === "AcceptStatusEvent" && notification.body.changes[0].event.status == "READ") {
                    console.log("LP Agent READ  Notification:  " + convId + " UserId: " + visitorId);
                    return;
                } else if (notification.type === "cqm.ExConversationChangeNotification" && notification.body.changes[0].result && notification.body.changes[0].result.conversationDetails.state ===
                    "OPEN" && notification.body.changes[0].result.conversationDetails.participants && roleExists(notification.body.changes[0].result.conversationDetails.participants, "ASSIGNED_AGENT") && roleExists(notification.body.changes[0].result.conversationDetails.participants, "CONSUMER")) {
                    return;
                } else if (notification.body.changes && notification.body.changes[0].originatorMetadata && notification.body.changes[0].originatorMetadata.role != "CONSUMER") {
                    console.log("conversationId is: " + convId + " visitorId " + visitorId + "Agent Message is: " + notification.body.changes[0].event.message);
                    if (notification.body.changes[0].event && notification.body.changes[0].event.contentType) {
                        if (notification.body.changes[0].event.contentType === "text/plain" && notification.body.changes[0].event.message) {
                            return sendCustomUserMessage(data, notification.body.changes[0].event.message);
                        } else if (notification.body.changes[0].event.contentType === "forms/secure-invitation") {
                            console.log("secure form");
                            data.toJSON = function () {
                                return {
                                    __payloadClass: 'OnMessagePayload',
                                    requestId: data.requestId,
                                    botId: data.botId,
                                    componentId: data.componentId,
                                    sendUserMessageUrl: data.sendUserMessageUrl,
                                    sendBotMessageUrl: data.sendBotMessageUrl,
                                    context: data.context,
                                    channel: data.channel,
                                    metaInfo: {
                                        isTemplate: true,
                                        'nlMeta': {
                                            'noPause': true
                                        }
                                    },
                                    overrideMessagePayload: {
                                        body: JSON.stringify({
                                            "type": "template",
                                            "AlwaysShowGlobalButtons": true,
                                            "payload": {
                                                "template_type": "list",
                                                "elements": [
                                                    {
                                                        "title": notification.body.changes[0].event.message.title,
                                                        "image_url": "https://edelivery.citi.com/CitiImages/images/b.LostCard.png",
                                                        "subtitle": "This is secure form, Information entered here protected and can not be accessed once submitted"                                                        
                                                    }
                                                ],
                                                "buttons": [
                                                    {
                                                        "title": "Fill form",
                                                        "type": "web_url",
                                                        "url": "https://google.com?formId=" + notification.body.changes[0].event.message.formId + "&invitationId=" + notification.body.changes[0].event.message.invitationId
                                                    }
                                                ]
                                            }
                                        }),
                                        isTemplate: true
                                    }
                                };
                            }
                            return;
                            //return sdk.sendUserMessage(data);
                        } else {
                            return;
                        }
                    } else if (notification.body.changes[0].sequence == 1) {
                        return sendCustomUserMessage(data, "You are now connected to an Agent.");
                    } else {
                        return;
                    }
                } else if (
                    notification.body.changes[0].result &&
                    notification.type === "cqm.ExConversationChangeNotification" && notification.body.changes[0].result.conversationDetails &&
                    notification.body.changes[0].result.conversationDetails.state && notification.body.changes[0].result.conversationDetails.state ===
                    "CLOSE" && notification.body.changes[0].result.convId === convId
                ) {
                    console.log("Agent ended the chat  Conversation Id " + convId + "  visitorId " + visitorId);
                    clearAgentRedisData(visitorId, convId);
                    data.toJSON = function () {
                        return {
                            __payloadClass: 'OnMessagePayload',
                            requestId: data.requestId,
                            botId: data.botId,
                            componentId: data.componentId,
                            sendUserMessageUrl: data.sendUserMessageUrl,
                            sendBotMessageUrl: data.sendBotMessageUrl,
                            context: data.context,
                            channel: data.channel,
                            message: "Agent ended the chat, Now you are connected to Bot again"
                        };
                    };
                    data.context.session.BotUserSession.isConnectedToAgent = false;
                    sdk.clearAgentSession(data).then(function () {
                        return sdk.sendUserMessage(data);
                    });
                }
            } else {
                console.log("data is not avilible for convestationId: " + convId)
                return
            }
        });
    } catch (err) {
        console.log("Error occured while parsing the agent message ", err);
    }
}

function connectToAgent(requestId, data, cb) {
    var conversation = {};
    try {
        conversation.brandId = config.liveperson.accountId;
        if (data.context.session.UserContext.secureCustomData) {
            var secureCustomData = JSON.parse(data.context.session.UserContext.secureCustomData);
            conversation.firstname = secureCustomData.customerFirstName;
            conversation.lastname = secureCustomData.customerLastName;
        }
        var lastMsg = data.context.session.BotUserSession.lastMessage.messagePayload.botInfo;
        if(lastMsg && lastMsg.customData && lastMsg.customData.lpAttributes){
            conversation.lpAttributes= lastMsg.customData.lpAttributes;
        }
        var visitorId = _.get(data, 'channel.channelInfos.from');
        if (!visitorId) {
            visitorId = _.get(data, 'channel.from');
        }
        data.context.session.BotUserSession.isConnectedToAgent = true;
        setTimeout(function () { sendCustomUserMessage(data, "Sounds like you need a representative. I will connect you."); }, 1000);
        conversation.visitorId = visitorId;
        conversation.skillId = config.liveperson.skillId;
        var _data = _.cloneDeep(data);
        return AgentService.openConversation(conversation)
            .then(function (res) {
                console.log("Open covesation response is: " + JSON.stringify(res) + " convId: " + res.conversationId);
                let info = {
                    secured_session_id: res.conversationId,
                    visitorId: visitorId,
                    last_message_id: -1
                };
                redisClient.hset("LIVEPERSON", visitorId, JSON.stringify(info), function (err, res) {
                    console.log("LIVEPERSON agent data " + visitorId + " saved");
                });

                redisClient.hset("LIVEPERSON", info.secured_session_id, JSON.stringify(_data), function (err, res) {
                    console.log("LIVEPERSON bot data " + info.secured_session_id + " saved")
                });
                gethistory(data).then(function (history) {
                    var parse_cht = history;
                    var chat_message = "";
                    var msg_type = "";
                    var count = parse_cht.total;
                    for (i = 0; i < count; i++) {
                        var temp = parse_cht.messages[i].components[0].data.text;
                        var msg_type = parse_cht.messages[i].type;
                        if (msg_type == "incoming") {
                            msg_type = "Customer";
                        } else {
                            msg_type = "Bot"
                        }
                        if (!temp.includes("template")) {
                            if (IsJsonString(temp)) {
                                chat_message = chat_message + msg_type + ": " + JSON.parse(temp).text + "\n\n";
                            } else {
                                chat_message = chat_message + msg_type + ": " + temp + "\n\n";
                            }
                        } else {
                            var temp = JSON.parse(parse_cht.messages[i].components[0].data.text);
                            chat_message = chat_message + msg_type + ": " + temp.payload.text + "\n\n";
                        }
                    }
                    console.log(chat_message);
                    if (chat_message) {
                        let messageObj = {
                            "kind": "req",
                            "id": "1",
                            "type": "ms.PublishEvent",
                            "body": {
                                "dialogId": res.conversationId, // this is converstionId/dialogId
                                "event": {
                                    "type": "ContentEvent",
                                    "contentType": "text/plain",
                                    "message": chat_message
                                }
                            }
                        }
                        return AgentService.sendMessage(messageObj)
                            .catch(function (e) {
                                console.log(e);
                                clearAgentRedisData(visitorId, res.conversationId);
                                data.context.session.BotUserSession.isConnectedToAgent = false;
                                sdk.clearAgentSession(data);
                                return sdk.sendBotMessage(data, cb);
                            });
                    }
                });
            });
    } catch (err) {
        console.log("Error occured while connecting to agent", e);
        data.message = "Hmm...Something went wrong and we are looking into it, please try later";
        sdk.clearAgentSession(data);
        data.context.session.BotUserSession.isConnectedToAgent = false;
        return sdk.sendUserMessage(data, cb);
    }
}


function onUserMessage(requestId, data, cb) {
    var visitorId = _.get(data, 'channel.channelInfos.from');
    if (!visitorId) {
        visitorId = _.get(data, 'channel.from');
    }
    console.log("visitorId: " + visitorId);
    redisClient.hget("LIVEPERSON", visitorId, function (err, reply) {
        var entry = JSON.parse(reply);
        if (data.message == "endAgentChat") {
            if (entry) {
                console.log('to agent clearsession');
                let closeMessageObj = {
                    "kind": "req",
                    "id": "1",
                    "type": "cm.UpdateConversationField",
                    "body": {
                        "dialogId": entry.secured_session_id, // this is converstionId/dialogId
                        "conversationField": {
                            "field": "ConversationStateField",
                            "conversationState": "CLOSE"
                        }
                    }
                }
                AgentService.closeConversation(closeMessageObj).then(function () {
                    clearAgentRedisData(visitorId, entry.secured_session_id);
                    data.message = "Thank you for contacting us";
                    sdk.clearAgentSession(data);
                    data.context.session.BotUserSession.isConnectedToAgent = false;
                    sdk.sendUserMessage(data, cb);
                })
            } else {
                data.message = "Thank you for contacting us";
                sdk.clearAgentSession(data);
                data.context.session.BotUserSession.isConnectedToAgent = false;
                sdk.sendUserMessage(data, cb);
            }
        } else {
            if (entry) {//check for live agent
                let messageObj = {
                    "kind": "req",
                    "id": "1",
                    "type": "ms.PublishEvent",
                    "body": {
                        "dialogId": entry.secured_session_id, // this is converstionId/dialogId
                        "event": {
                            "type": "ContentEvent",
                            "contentType": "text/plain",
                            "message": data.message // User message
                        }
                    }
                }
                return AgentService.sendMessage(messageObj)
                    .catch(function (e) {
                        console.error(e);
                        sdk.clearAgentSession(data);
                        clearAgentRedisData(visitorId, entry.secured_session_id);
                        data.context.session.BotUserSession.isConnectedToAgent = false;
                        return sdk.sendBotMessage(data, cb);
                    });
            } else {
                return sdk.sendBotMessage(data, cb);
            }
        }
    });
}


module.exports = {
    getNotificationConversationId,
    lpNotification,
    clearAgentRedisData,
    connectToAgent,
    onUserMessage
}



