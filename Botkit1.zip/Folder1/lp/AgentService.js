const HttpRequest = require('./HttpRequest')
const DomainService = require('./DomainService');
const ConsumerRequestConversation = require("./model/ConsumerRequestConversation");
const SetUserProfile = require("./model/SetUserProfile");
const Request = require("./model/Request");
const config = require("../config");
var _ = require('lodash');
const asyncForEach = require('async-foreach').forEach;

var redisClient = require("./../lib/RedisClient.js").createClient(config.redis);

//var _userTokenMap = {};


function authenticate(conversation) {
    return new Promise(function (resolve, reject) {
        return getAppJWT(conversation)
            .then((res) => {
                conversation.appJWT = res['access_token'];
                console.log("tes: " + JSON.stringify(res));
                return getConsumerJWS(conversation)
                    .then((res) => {
                        conversation.consumerJWS = res['token'];
                        resolve(conversation);
                    })
            });
    });
}

function getAppJWT(conversation) {
    return new Promise(function (resolve, reject) {
        const options = {
            headers: {
                'content-type': 'application/x-www-form-urlencoded'
            }
        };
        DomainService.getDomainByServiceName("sentinel", conversation.brandId).then((host) => {
            let url = `https://${host}/sentinel/api/account/${conversation.brandId}/app/token?v=1.0&grant_type=client_credentials&client_id=${config.liveperson.clientId}&client_secret=${config.liveperson.clientSecret}`
            HttpRequest.post(url, options, undefined).then(function (response) {
                resolve(response);
            })
        });
    });
}

function getConsumerJWS(conversation) {
    return new Promise(function (resolve, reject) {
        let options = {
            "headers": {
                'content-type': 'application/json',
                'Authorization': conversation.appJWT
            }
        };
        DomainService.getDomainByServiceName("idp", conversation.brandId).then((host) => {
            var body;
            if (conversation.lpAttributes && conversation.lpAttributes.customerId) {
                body = { "ext_consumer_id": conversation.lpAttributes.customerId }
            } else {
                body = { "ext_consumer_id": conversation.visitorId }
            }
            let url = `https://${host}/api/account/${conversation.brandId}/consumer?v=1.0`
            HttpRequest.post(url, options, body).then(function (response) {
                resolve(response);
            })
        });
    });
}

function openConverstionHeaders(appJWT, consumerJWS) {
    console.log("appJWT: " + appJWT)
    return {
        'headers': {
            'content-type': 'application/json',
            'Authorization': appJWT,
            'x-lp-on-behalf': consumerJWS
        }
    };
}


async function getConversationId(response) {
    return new Promise(function (resolve, reject) {
        asyncForEach(response, async (res) => {
            try {
                if (res.body.hasOwnProperty("conversationId")) {
                    console.log("conversationId: " + res.body.conversationId)
                    resolve(res.body.conversationId);
                } else if (res.body.hasOwnProperty("result") && res.body.hasOwnProperty("convId")) {
                    resolve(res.body.result.convId);
                }
            } catch (err) {
                console.error("ERROR parsing notification JSON, the conversation ID cannot be found ", err);
            }
        });
    });
}

function getOpenConvRequestBody(conversation) {
    let requestBody = new ConsumerRequestConversation(
        "CUSTOM",
        "MESSAGING",
        conversation.brandId,
        conversation.skillId
    );
    let requestConversationPayload = new Request("req", "2,", "cm.ConsumerRequestConversation", requestBody);

    let setUserProfileBody = new SetUserProfile(
        conversation.firstName || "Web",
        conversation.lastName || "User"
    );

    var payload = {
        "authenticatedData": {
            "lp_sdes": [
                {
                    "type": "personal",
                    "personal": setUserProfileBody
                }
            ]
        }
    }

    if (conversation.lpAttributes) {
        let attributes = {
            "ctype": conversation.lpAttributes.customerType || "",
            "cstatus": conversation.lpAttributes.customerStatus || "",
            "customerId": conversation.lpAttributes.customerId || ""
        }
        if (conversation.lpAttributes.lastPaymentDate) {
            let lpd = conversation.lpAttributes.lastPaymentDate.split("-"); // "2019-10-29",
            attributes.lastPaymentDate = {
                "day": lpd[2],
                "month": lpd[1],
                "year": lpd[0]
            }
        }

        if (conversation.lpAttributes.accountRegistrationDate) {
            let lrd = conversation.lpAttributes.accountRegistrationDate.split(" ")[0].split("-"); //"10-APR-2020 05:47:44",
            attributes.registrationDate = {
                "day": lrd[0],
                "month": lrd[1],
                "year": lrd[2]
            }
        }

        payload.authenticatedData.lp_sdes.unshift({
            "type": "ctmrinfo",
            "info": attributes
        })
    }

    let setUserProfilePayload = new Request("req", "1,", "userprofile.SetUserProfile", payload);

    return [setUserProfilePayload, requestConversationPayload];
}

function openConversationRequest(conversation) {
    return new Promise(function (resolve, reject) {
        DomainService.getDomainByServiceName("asyncMessagingEnt", conversation.brandId).then((host) => {
            const options = openConverstionHeaders(conversation.appJWT, conversation.consumerJWS, conversation.features);
            const body = getOpenConvRequestBody(conversation);
            let url = `https://${host}/api/account/${conversation.brandId}/messaging/consumer/conversation?v=3`
            HttpRequest.post(url, options, body).then(function (response) {
                resolve(response);
            })
        });
    });
}

function sendMessageRequest(message) {
    return new Promise(function (resolve, reject) {
        DomainService.getDomainByServiceName("asyncMessagingEnt", config.liveperson.accountId).then((host) => {
            redisClient.hget("LIVEPERSON_TOKENS", message.body.dialogId, function (err, conversation) {
                console.log("sendMessageRequest conversation is: " + conversation);
                if (conversation) {
                    const options = openConverstionHeaders(JSON.parse(conversation).appJWT, JSON.parse(conversation).consumerJWS);
                    let url = `https://${host}/api/account/${config.liveperson.accountId}/messaging/consumer/conversation/send?v=3`
                    HttpRequest.post(url, options, message).then(function (response) {
                        resolve(response);
                    })
                } else {
                    console.log("there no tokens for this dailog: " + message.body.dialogId)
                }
            });
        });
    });
}



function closeConversationRequest(message) {
    return new Promise(function (resolve, reject) {
        DomainService.getDomainByServiceName("asyncMessagingEnt", config.liveperson.accountId).then((host) => {
            redisClient.hget("LIVEPERSON_TOKENS", message.body.conversationId, function (err, conversation) {
                console.log("conversation is: " + conversation);
                if (conversation) {
                    const options = openConverstionHeaders(JSON.parse(conversation).appJWT, JSON.parse(conversation).consumerJWS);
                    let url = `https://${host}/api/account/${config.liveperson.accountId}/messaging/consumer/conversation/send?v=3`
                    HttpRequest.post(url, options, message).then(function (response) {
                        resolve(response);
                    })
                } else {
                    console.log("no tokens for this dialogId: " + message.body.dialogId)
                }
            })
        });
    });
}

module.exports = {
    openConversation: function (conversation) {
        try {
            return authenticate(conversation).then((res) => {
                return openConversationRequest(conversation).then((res) => {
                    console.log("Response is: " + JSON.stringify(res))
                    return getConversationId(res).then((conversationId) => {
                        console.log("conv: " + conversationId)
                        conversation.conversationId = conversationId;
                        conversation.isConvStarted = true;
                        console.log("conv: " + JSON.stringify(conversation))
                        redisClient.hset("LIVEPERSON_TOKENS", conversationId, JSON.stringify(conversation))
                        return conversation;
                    });

                });
            })
        } catch (err) {
            console.log("Error while opening connection");
            return "";
        }
    },
    sendMessage: function (message) {
        return sendMessageRequest(message).then(res => {
            console.log("response is: " + JSON.stringify(res))
            return res;
        });
    },

    closeConversation: function (message) {
        return closeConversationRequest(message).then(res => {
            console.log("response is: " + JSON.stringify(res))
            return res;
        });
    }
}





