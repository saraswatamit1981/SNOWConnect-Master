const HttpRequest = require('./HttpRequest')
const config = require('../config')
const NodeCache = require("node-cache");
const cache = new NodeCache();



module.exports = {
    getDomainByServiceName: function (serviceName, brandId) {
        return new Promise(function (resolve, reject) {
            cache.get("domains", function (err, value) {
                if (!err) {
                    if (value == undefined) {
                        console.log("getting the domains for :" + brandId)
                        var opts = { "accountId": brandId, headers: { "Content-Type": "application/json" } }
                        HttpRequest.getWithOptions(`${config.liveperson.host}/api/account/${brandId}/service/baseURI.json?version=1.0`, opts).then(function (data) {
                            //console.log(" response: " + JSON.stringify(data));
                            let length = data.baseURIs.length;
                            var domains = [];
                            for (let i = 0; i < length; i++) {
                                domains[data.baseURIs[i].service] = data.baseURIs[i].baseURI;
                            }
                            //console.log("Domains are : " + domains);
                            cache.set("domains", domains, function (err, success) {
                                if (!err && success) {
                                    console.log(success);
                                }
                                resolve(domains[serviceName]);
                            });                            
                        }, error => {
                            console.log(error);
                            reject(this.errorResponse(error));
                        });
                    } else {
                        //console.log(value);
                        resolve(value[serviceName]);
                    }
                }
            });
        });
    }
}