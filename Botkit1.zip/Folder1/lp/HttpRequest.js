const request = require('request');
var Promise = require("bluebird");
var config = require("./../config").ssgConfig;
var nodeurl = require("url");
var cuProxy = require("./../cuproxy");
var fs = require('fs');

function addCerts() {
    var opts = {};
    if (config.certFile)
        opts.cert = fs.readFileSync(config.certFile);

    if (config.keyFile)
        opts.key = fs.readFileSync(config.keyFile);

    if (config.caFile)
        opts.ca = fs.readFileSync(config.caFile);

    if (config.passphrase)
        opts.passphrase = config.passphrase;

    if (config.securityOptions)
        opts.securityOptions = opts.securityOptions;

    return opts;
}

function makeRequest(url, method, body, opts) {

    var headers;
    var reqOptions = {};
    opts = opts || {};
    headers = opts.headers || {};
    console.log(nodeurl.parse(url).origin)
    headers.ssgHeader = nodeurl.parse(url).protocol + "//" + nodeurl.parse(url).host;
    headers.uuid= cuProxy.uuid();
    reqOptions.headers = headers;

    var certs = addCerts();
    reqOptions = Object.assign(opts, certs);
    reqOptions.url = config.domain + url.replace(nodeurl.parse(url).protocol + "//" + nodeurl.parse(url).host, "");
    reqOptions.method = method;

    if (body) {
        reqOptions.body = body;
    }
    reqOptions.json = true;

   console.log("SSG request is: " + JSON.stringify(reqOptions.body))
    return new Promise(function (resolve, reject) {
        request(reqOptions, function (err, res) {
            if (err) {
                console.log("Error in making the call: " + err);
                return reject(err);
            }
            console.log(JSON.stringify(res));
            return resolve(res.body);
        });
    });
}

module.exports = {
    post: function (url, opts, body, callback) {
        return makeRequest(url, 'post', body, opts)
            .nodeify(callback);
    },
    get: function (url, callback) {
        return makeRequest(url, 'get')
            .nodeify(callback);
    },
    getWithOptions: function (url, opts, callback) {
        return makeRequest(url, 'get', undefined, opts)
            .nodeify(callback);
    }

};



