function PrivateData(mobileNum, mail, pushNotificationData) {
  this.mobileNum = mobileNum;
  this.mail = mail;
  this.pushNotificationData = pushNotificationData || {};
}

module.exports = PrivateData;

