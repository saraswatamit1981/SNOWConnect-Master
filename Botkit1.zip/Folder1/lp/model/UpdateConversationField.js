function UpdateConversationField(conversationId, conversationField) {
    this.conversationId = conversationId;
    this.conversationField = conversationField;
}

module.exports = UpdateConversationField;
