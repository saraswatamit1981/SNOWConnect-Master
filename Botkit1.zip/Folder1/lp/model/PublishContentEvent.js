function PublishContentEvent(dialogId, event) {
  this.dialogId = dialogId;
  this.event = event;
}
module.exports = PublishContentEvent;

