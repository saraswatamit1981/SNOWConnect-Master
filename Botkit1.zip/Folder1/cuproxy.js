

var sdk = require("./lib/sdk");
var request = require('request-promise');
var config = require("./config");
var schedular = require('node-schedule');
const NodeCache = require("node-cache");
const cache = new NodeCache();
const ObjectType = require("./lib/sdk/ObjectTypes/OnMessagePayload");
var redisClient = require("./lib/RedisClient.js").createClient(config.redis);

function uuid() {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
        var r = Math.random() * 16 | 0,
            v = c == 'x' ? r : (r & 0x3 | 0x8);
        return v.toString(16);
    });
}
schedular.scheduleJob('*/4 * * * *', function () {
    callOAuthApi();
});

function IsJsonString(str) {
    try {
        JSON.parse(str);
    } catch (e) {
        return false;
    }
    return true;
}

function clearContext(data) {
    console.log("Inside clearContext data : " + data.requestId);
    try {
        var request = new ObjectType(data.requestId, data.botId, "", data);
        var _data = request;
        _data.metaInfo = {};
        _data.metaInfo.nlMeta = {};
        _data.metaInfo.nlMeta.isRefresh = true;
        console.log("Context is cleared.................");
        return sdk.sendBotMessage(_data);
    }
    catch (e) {
        console.log("Error while clearing the context", e);
    }
}


function callOAuthApi() {
    console.log('CallIng the OAuth Token');
    var data = {
        "grant_type": config.Oauth.grantType,
        "scope": config.Oauth.scope,
        "username": "korai",
        "password": "koreaitoken"
    }
    var options = {
        method: 'POST',
        form: data,
        uri: config.Oauth.accessTokenUri,
        headers: {
            'content-type': 'application/x-www-form-urlencoded',
            'Authorization': 'Basic ' + new Buffer(config.Oauth.clientId + ':' + config.Oauth.clientSecret).toString('base64'),
            'uuid': uuid()
        }
    };
    console.log("Oauth API request :" + JSON.stringify(options));
    return request(options).then(function (res) {
        cache.set("token", res);
        console.log("Access Token from cache" + cache.get("token"));
        return JSON.parse(res); // you can read response here
    }).catch(function (err) {
        console.log("Error in Oauth API request :" + err);
        return Promise.reject(err);
    });
}

function getJWTToken() {
    if (cache.get("token")) {
        return JSON.parse(cache.get("token"));
    } else {
        return callOAuthApi();
    }
}

function cuProxyApi(req) {
    try {
        console.log("Bot response is: " + JSON.stringify(req.body));
        if (req.body && !req.body.text) {
            console.log("Ignore the message");
            return;
        }
        var userMobileNumber;
        if (req.body.to && req.body.to.includes("st-")) {
            userMobileNumber = req.body.from;
        } else {
            userMobileNumber = req.body.to.replace("+1", "");
        }
        if (userMobileNumber && userMobileNumber.includes("@")) {
            userMobileNumber = userMobileNumber.split("@");
            userMobileNumber = userMobileNumber[0];
        }

        let _text = req.body.text;
        if (!_text.textmessage || !_text.siteId || _text.textmessage.includes("I am discarding the")) {
            console.log("Ignore the message");
            return;
        }
        var uniqueId = "ivr/" + userMobileNumber + "/" + _text.siteId;
        var data = {
            "sourceApplicationId": config.connect.sourceApplicationId,
            "preferredLanguageCode": config.connect.preferredLanguageCode,
            "lineOfBusinessCode": config.connect.lineOfBusinessCode,
            "eligibilityOverrideFlag": _text.eligibilityOverrideFlag ? _text.eligibilityOverrideFlag : false,
            "campaignName": config.connect.campaignName,
            "smsMessageData": _text.textmessage,
            "smsMessageType": _text.smsMessageType ? _text.smsMessageType : "",
            "portfolio": _text.siteId,
            "phone": {
                "phoneNumber": userMobileNumber,
            },
        }
        if (_text.accountNumber) {
            data["accountInfo"] = {
                "accountNumber": _text.accountNumber
            }
        }
        var options = {
            method: 'POST',
            url: config.connect.api,
            body: data,
            json: true,
            headers: {
                'Content-Type': 'application/json',
                'uuid': _text.uuid ? _text.uuid : uuid(),
                'Authorization': "Bearer " + getJWTToken().access_token,
                'countryCode': config.connect.countryCode,
                'businessCode': config.connect.businessCode,
                'channelId': config.connect.channelId,
                'Accept': 'application/json',
                'client_id': config.connect.clientId,
                'accessToken': getJWTToken().metadata.replace("a:", "")
            }
        };
        console.log(options.headers.uuid + " ::CU outbound request: ", options);
        request(options, function (error, response, body) {
            if (!error) {
                console.log(options.headers.uuid + ' :: CU response status code [' + response.statusCode + '] and body:  [' + body.code + ']');
                if (response.statusCode === 422) {
                    console.log(options.headers.uuid + " :: CU Responned with 422 Second attempt with same request");
                    request(options, function (error, response, body) {
                        if (!error) {
                            console.log(options.headers.uuid + ' :: Second attempt CU response [' + response.statusCode + '] body:  ' + JSON.stringify(body));
                            if (response.statusCode === 422) {
                                console.log("Getting uniqueId : ", uniqueId);
                                redisClient.get(uniqueId, function (err, redisdata) {
                                    if (redisdata) {
                                        var parsedData = JSON.parse(redisdata);
                                        clearContext(parsedData);
                                    }
                                });
                                console.log(options.headers.uuid + " :: CU Responned with 422 error code Inside Failure attempt");
                                if (body && body.code === "ELG_RJT_TCPA" && body.moreInfo && body.moreInfo.toUpperCase() === "CAN_OVERRIDE") {
                                    console.log(options.headers.uuid + " :: Express consent " + JSON.stringify(body))
                                    expressConcent(data.phone.phoneNumber, data.portfolio, config.credentials.botId, options.headers.uuid)
                                } else {
                                    failureAttempt(data, body, uniqueId, _text.uuid);
                                }
                            }
                        }
                    });
                }
            } else {
                console.log('Error happened in CU outbound API ' + error);
                return;
            }
        });
    } catch (err) {
        console.log("Error happened in CU outbound API", err);
        return;
    }
}


function expressConcent(phoneNumber, siteId, botId, uuid) {
    var body = {
        "from": {
            "id": "+1"+phoneNumber+"@"+siteId // this is how it need to be in UAT
	   //  "id": "+1"+phoneNumber  // this is how it need to be in DIT
        },
        "to": {
            "id": botId
        },
        "message": {
            "text": "ExpressConsent"
        },
        "session": {
            "new": true
        },
        "siteId": siteId,
        "channelId": "EXPRESSCONSENT",
        "uuid": uuid
    };
    var options = {
        method: 'POST',
        url: config.kore.api,
        body: body,
        json: true,
        headers: {
            'Content-Type': 'application/json',
            'Authorization': config.koreAuthToken
        }
    };
    console.log("Express consent options are ", options);
    request(options, function (error, response, body) {
        if (!error) {
            console.log('Kore response [' + response.statusCode + '] body:  ' + body);
        } else {
            console.log('Error happened: ' + error);
        }
    });
}

function failureAttempt(data, responsebody, uniqueId, requestUUID) {
    console.log("Inside Failure attempt of uniqueId " + uniqueId + "and uuid" + requestUUID);
    try {
        redisClient.get(uniqueId + "/" + requestUUID, function (err, redisdata) {
            if (redisdata) {
                console.log("Ignore the error message already responed once" + uniqueId + "/" + requestUUID)
            } else {
                redisClient.set(uniqueId + "/" + requestUUID, true, "EX", 3000)
                let mes = getErrorMessages(responsebody, data);
                if (mes) {
                    data["smsMessageData"] = mes;
                    data["eligibilityOverrideFlag"] = true;
                    var options = {
                        method: 'POST',
                        url: config.connect.api,
                        body: data,
                        json: true,
                        headers: {
                            'Content-Type': 'application/json',
                            'uuid': requestUUID ? requestUUID : uuid(),
                            'Authorization': "Bearer " + getJWTToken().access_token,
                            'countryCode': config.connect.countryCode,
                            'businessCode': config.connect.businessCode,
                            'channelId': config.connect.channelId,
                            'Accept': 'application/json',
                            'client_id': config.connect.clientId,
                            'accessToken': getJWTToken().metadata.replace("a:", "")
                        }
                    };
                    console.log("Failure attmept request", options);
                    request(options, function (error, response, body) {
                        if (!error) {
                            console.log('Failure Attempt CU response [' + response.statusCode + '] body:  ' + body);
                        } else {
                            console.log('Error happened in cuproxy Failure Attempt ' + error);
                        }
                    });
                } else {
                    console.log("We dont't have second failure attempt for this error code ignore the message");
                }
            }
        });
    } catch (Err) {
        console.log("Error occurred failureAttempt ", err)
    }
}
function getErrorMessages(body, data) {
    let error = body.code;
    var siteId = data.portfolio;
    console.log(error);
    let message = "";
    switch (error) {
        case "ELG_RJT_CDC":
            message = "Hello, please log in to your account via the attached link, or call the phone number on the back of your card so that we can help you " + config.deeplinks[siteId.toUpperCase()];
            break;
        case "ELG_RJT_IDC":
            message = "Hello, please log in to your account via the attached link, or call the phone number on the back of your card so that we can help you " + config.deeplinks[siteId.toUpperCase()];
            break;
        case "ELG_RJT_TCPA":
            message = "Hello, please log in to your account via the attached link, or call the phone number on the back of your card so that we can help you " + config.deeplinks[siteId.toUpperCase()];
            break;
        //case "PORT_INV":
        //   message = "Hello, we can't verify your account with this phone number. Please log in to your account via the attached link to update your phone number or call the phone number on the back of your card";
        //  break;
        case "ACNT_READ_ERR":
            message = "Hello, we can't verify your account with this phone number. Please log in to your account via the attached link to update your phone number or call the phone number on the back of your card " + config.deeplinks[siteId.toUpperCase()];
            break;

        case "PHN_INV":
            message = "Hello, we can't verify your account with this phone number. Please log in to your account via the attached link to update your phone number or call the phone number on the back of your card " + config.deeplinks[siteId.toUpperCase()];
            break;
    }
    return message;
}

module.exports = {
    cuProxyApi,
    callOAuthApi,
    getJWTToken,
    failureAttempt,
    uuid,
    clearContext
}



