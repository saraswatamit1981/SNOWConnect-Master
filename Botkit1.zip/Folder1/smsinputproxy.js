
var request = require("request");
var config = require("./config");
var cuProxy = require("./cuproxy");
var cbolProxy = require("./cbolproxy");

function SMSInputProxy(req, res) {
    console.log("Request is: " + JSON.stringify(req.body) + " headers " + JSON.stringify(req.headers));
    try {
        if (!(req.body && req.body.uuid)) {
            if (req.headers && req.headers.uuid) {
                req.body.uuid = req.headers.uuid;
            } else {
                let UUID = cuProxy.uuid();
                console.log("No UUID in headers or body generating the new UUID from Kore " + UUID)
                req.body.uuid = UUID;
            }
        }
        if (!(req.body.to && req.body.to.id)) {
            return res.status(400).jsonp({
                "code": "Missing Parameters",
                "message": "Bot Id is missing"
            })
        }
        if (!(req.body.from && req.body.from.id)) {
            return res.status(400).jsonp({
                "code": "Missing Parameters",
                "message": "From mobile number is missing"
            })
        }

        if (req.body.from.id.includes("+1")) {
            console.log("Mobile number has the +1" + req.body.from.id);
        }
        else {
            req.body["from"]["id"] = "+1" + req.body.from.id;
        }

        if (req.body["siteId"]) {
            if (req.body["siteId"].toUpperCase() === "BRANDED_CARDS") {
                console.log(req.body.uuid+ "reques from branded cards");
                var mobileNumber = req.body["from"]["id"].replace("+1", "");
                req.body["from"]["id"] = req.body["from"]["id"] + "@" + req.body["siteId"];
                res.status(200).jsonp({
                    "code": "ok"
                })
		return cbolProxy.cmsInputProxy(req.body, mobileNumber);
            } else {
                req.body["from"]["id"] = req.body["from"]["id"] + "@" + req.body["siteId"];
            }
        } else {
            return res.status(400).jsonp({
                "code": "Missing Parameters",
                "message": "SiteId is missing"
            })
        }

        var options = {
            method: 'POST',
            url: config.kore.api,
            body: req.body,
            json: true,
            headers: {
                'Content-Type': 'application/json',
                'Authorization': config.koreAuthToken
            }
        };
        console.log("options are ", options);
        request(options, function (error, response, body) {
            if (!error) {
                console.log('Kore response [' + response.statusCode + '] body:  ' + body);
                res.status(200).jsonp({
                    "code": "ok"
                })
            } else {
                console.log('Error happened: ' + error);
                res.status(500).jsonp({
                    "code": "INTERNAL SERVER ERROR",
                    "message": "The request failed due to an internal error/server unavailability"
                })
            }
        });
    } catch (err) {
        console.log("eror" + err);
        res.status(500).jsonp({
            "code": "INTERNAL SERVER ERROR",
            "message": "The request failed due to an internal error/server unavailability"
        })
    }
}
module.exports = SMSInputProxy;




