var request = require('request-promise');
var schedular = require('node-schedule');
const NodeCache = require("node-cache");
const cache = new NodeCache();
schedular.scheduleJob('*/59 * * * *', function () {
  actionPromptsApi();
});
function actionPromptsApi(apId) {
  try {
    let businessIds = ['THD', 'BB', 'SRS', 'SYW', 'LLBEAN']
    console.log("making action prompt requests ::")
    let requests = businessIds.map(businessId => {
      return new Promise((resolve, reject) => {
        request({
          uri: 'https://sit.api.citigroup.net/gcgapi/dev1/v1/content/subBusinessID/' + businessId + '/applicationID/CARDS/contentType/cmcomponent/viewID/cmpnt_svc_cw_cova_emergency_message?isStaticRequired=true&langId=en_US',
          method: 'GET',
          headers: {
            businesscode: 'CRS',
            uuid: '122222222',
            countrycode: 'US',
            channelId: 'DESKTOP',
            client_id: '4bd54ee8-f447-44a2-bc72-26f8f705a8f6'
          }
        }, (err, res, body) => {
          if (err) {
            reject(err)
          }
          resolve(body)
        })
      })
    })
    return Promise.all(requests).then((body) => {
      var finalResult = {}
      body.forEach(res => {
        res = JSON.parse(res)
        //        console.log("res :", typeof res, res.content)
        if (res && res.content && res.content.CARDS && res.content.CARDS.cmcomponent$$cmpnt_svc_cw_cova_emergency_message && res.content.CARDS.cmcomponent$$cmpnt_svc_cw_cova_emergency_message.BUSINESS_ID) {
          var businessId = res.content.CARDS.cmcomponent$$cmpnt_svc_cw_cova_emergency_message.BUSINESS_ID;
          var firstImageUrl, firstImageLink, secondImageUrl, secondImageLink, firstEmergencyMsg, secondEmergencyMsg, isImageTemplate;
          var apiRes = res;
          var message = ""
          if (Object.keys(apiRes).length > 0 && apiRes.content && Object.keys(apiRes.content).length > 0) {
            //context.contentKeys = Object.keys(apiRes.content);
            //context.yes = true;
            var cards = apiRes.content.CARDS;
            var cardKeys = Object.keys(cards);
            //context.cardKeys = Object.keys(cards);
            for (i = 0; i < cardKeys.length; i++) {
              if (cardKeys[i] === "copy$$cova_em_show_image_template") {
                isImageTemplate = cards.copy$$cova_em_show_image_template.TEXT;
              }
              if (cardKeys[i] === "cmlink$$link_cova_em_image_one_signon") {
                firstImageUrl = cards.cmlink$$link_cova_em_image_one_signon.URL.FULL_URL;
                //firstImageLink = cards.cmlink$$link_cova_em_image_one_signon.CONTENT_ID;
              }
              else if (cardKeys[i] === "cmlink$$link_cova_em_image_two_signon") {
                secondImageUrl = cards.cmlink$$link_cova_em_image_two_signon.URL.FULL_URL;
                //secondImageLink = cards.cmlink$$link_cova_em_image_one_signon.CONTENT_ID;
              }
              else if (cardKeys[i] === "copy$$cova_emergency_message_signon") {
                firstEmergencyMsg = cards.copy$$cova_emergency_message_signon.TEXT;
              }
              else if (cardKeys[i] === "copy$$cova_em_text_link") {
                secondEmergencyMsg = cards.copy$$cova_em_text_link.TEXT;
              }
            }
            if (isImageTemplate === "true" || isImageTemplate === true) {
              message = {
                "type": 'template',
                "payload": {
                  "template_type": 'text_image',
                  "elements": {
                    "text1": firstEmergencyMsg,
                    "image_info": [
                      {
                        "image_url": firstImageUrl,
                        /*"default_action": {
                            "type": "web_url",
                            "url": "https://peterssendreceiveapp.ngrok.io/view?item=103"
                        }*/
                      },
                      {
                        "image_url": secondImageUrl,
                        /*"default_action": {
                            "type": "web_url",
                            "url": "https://peterssendreceiveapp.ngrok.io/view?item=103"
                        }*/
                      }
                    ],
                    "text2": secondEmergencyMsg
                  }
                }
              };
            }
            else {
              message = {
                payload: {
                  "template_type": "textTemplate",
                  "text": firstEmergencyMsg
                }
              };
            }
          }
          else {
            message = {
              payload: {
                "template_type": "textTemplate",
                "text": "Sorry, we are not able to fetch any info."
              }
            };
          }
        }
        else {
          message = {
            payload: {
              "template_type": "textTemplate",
              "text": "Sorry, we are not able to fetch any info."
            }
          };
        }
        finalResult[businessId] = message;
      })
      cache.set("response", finalResult);
      console.log("ActionPrompt response:",finalResult)
	 return finalResult[apId]
    }).catch(err => console.log(err))
  } catch (err) {
    console.log("Error happened in ActionPrompts API: ", err);
  }
}
var businessIdList = {
  "PLCN_GOODYEAR": "GDYR",
  "GOODYEAR": "GDYR",
  "PLCN_MACYS": "MACY",
  "PLCN_BLOOMINGDALES": "BLMD",
  "SEARS": "SRS",
  "PLOC_SHELL": "SHLL",
  "PLCN_BESTBUY": "BB",
  "PLCN_HOMEDEPOT": "THD",
  "CACN_HOMEDEPOT": "THD_CA",
  "PLOC_SUNOCO": "SUN",
  "PLOC_EXXONMOBIL": "EXMB",
  "PLCN_BROOKSBROTHERS": "BROOKS",
  "PLCN_LINCOLNSERVICES": "LINC",
  "PLCN_SERVICE": "FRD",
  "PLCN_AMERICAN": "AA",
  "PLCN_BRANDSOURCE": "BRND",
  "PLCN_JEWELRY": "JWL",
  "PLCN_OFFICEDEPOT": "OFDPT",
  "PLCN_STAPLES": "STPL",
  "PLCN_TRACTORSUPPLY": "TS",
  "PLCN_DRIVECARD": "DRV",
  "PLOC_WAWA": "WAWA",
  "PLCN_BRP": "BMBDR",
  "PLCN_SERVICECENTRAL": "TBC",
  "PLCN_TORO": "TORO",
  "PLCN_COSTCO": "COSTCO",
  "PLCN_HNPE": "HONDA_PE",
  "PLCN_KAWA": "KAWA",
  "PLCN_HOME": "HMF",
  "PLCN_ELECAPPL": "CENA",
  "PLCN_LLBEAN": "LLBEAN",
  "PLCN_CAT": "CAT",
  "PLCN_MEIJER": "MJ",
  "PLCN_SYW": "SYW",
  "PLCN_HNPS": "HONDA_PS",
  "PLCN_WFCC": "WF"
};

function getSiteId(siteId) {
  return businessIdList[siteId];
}

function getPromptsResponse(siteId) {
  let apId = getSiteId(siteId);
  if (cache.get("response")) {
	let apRes = cache.get("response");
    console.log("prepared response :::",apRes[apId])
    return apRes[apId];
  } else {
    console.log("dont have action prompt api response in cache, triggering now")
    return actionPromptsApi(apId);
  }
}
module.exports = {
  getPromptsResponse,
  actionPromptsApi
}

//actionPromptsApi()

