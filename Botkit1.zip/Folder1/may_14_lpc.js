

var sdk = require("./lib/sdk");
var Promise = sdk.Promise;
var config = require("./config");
var MakePaymentScheduler = require("./MakePayment.js");
const AgentService = require('./lp/AgentService')
const feedback = require('./feedback')
var redisClient = require("./lib/RedisClient.js").createClient(config.redis);
var _ = require('lodash');
var cuProxy = require("./cuproxy");
var request = require('request-promise');
var stopsms = require("./stopsms");
var botId = config.credentials.botId;
var botName = config.credentials.botName;
redisClient.config("SET", "notify-keyspace-events", "KExA");
var mongoUtil = require('./mongoUtil');
var reports = require("./reports");
var lpUtils = require('./lp/Util.js')

function IsJsonString(str) {
    try {
        JSON.parse(str);
    } catch (e) {
        return false;
    }
    return true;
}


function getTimeStamp() {
    var date = new Date();
    var now_utc = Date.UTC(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate(),
        date.getUTCHours(), date.getUTCMinutes(), date.getUTCSeconds());
    return new Date(now_utc);
}
async function shutdown(e) {
    let err = e;
    console.log('Shutting down application');
    try {
        console.log('Closing database module');
    } catch (e) {
        console.error(e);
        err = err || e;
    }
    console.log('Exiting process');
    if (err) {
        process.exit(1);
    }
}

async function startup() {
    console.log('Starting application');
    try {
        mongoUtil.connectToServer(function (err) {
            if (err) {
                console.log("Unable to establish connection");
            } else {
                console.log('connected to DB');
            }
        });
        console.log('Initializing OAuth API module');
        cuProxy.callOAuthApi();
    } catch (err) {
        console.error(err);
        process.exit(1);
    }
}

startup();

process.on('SIGTERM', () => {
    console.log('Received SIGTERM');
    shutdown();
});
process.on('SIGINT', () => {
    console.log('Received SIGINT');
    shutdown();
});
process.on('uncaughtException', err => {
    console.log('Uncaught exception');
    console.error(err);
    shutdown(err);
});

function gethistory(req, res) {
    console.log("history API is called");
}

function isEmpty(str) {
    return (!str || 0 === str.length || !str.trim());
}



function getAccountDetails(data) {
    console.log("phoneNumber", data.context.session.BotUserSession.lastMessage.messagePayload.from.id);
    var mobileNumber = data.context.session.BotUserSession.lastMessage.messagePayload.from.id;
    if (mobileNumber && mobileNumber.length) {
        mobileNumber = mobileNumber.split("@");
        mobileNumber = mobileNumber[0];
    }
    try {
        var rbody = {
            "phoneNumber": mobileNumber.replace("+1", "")
        }
        var options = {
            method: 'POST',
            body: rbody,
            url: config.accountApi.endPoint,
            json: true,
            headers: {
                'content-type': 'application/json',
                "countryCode": config.accountApi.countryCode,
                "businessCode": config.accountApi.businessCode,
                "channelId": config.accountApi.channelId,
                "client_id": config.accountApi.clientId,
                "uuid": data.context.session.BotUserSession.lastMessage.messagePayload.uuid,
                "siteId": data.context.session.BotUserSession.lastMessage.messagePayload.siteId.toUpperCase(),
                "authorization": cuProxy.getJWTToken().access_token,
                "accesstoken": cuProxy.getJWTToken().metadata.replace("a:", "")
            }
        };
        console.log("Fusion Account look up API Options:" + JSON.stringify(options));
        return request(options).then(function (res) {
            console.log(data.context.session.BotUserSession.lastMessage.messagePayload.uuid +": Fusion Account look up API Response is" + JSON.stringify(res));
            return res; // you can read response here
        }).catch(function (err) {
            console.log(data.context.session.BotUserSession.lastMessage.messagePayload.uuid + "###Error while calling the account details", err);
            return [];
        });
    } catch (Err) {
        console.error(data.context.session.BotUserSession.lastMessage.messagePayload.uuid +"###Error while calling the account details", Err);
        return [];
    }
}

function changePaylod(data, message, uuid) {
    var accountNumber, overrideMessagePayload;
    if (data && data.context.session && data.context.session.BotUserSession) {
        if (data.context.session.BotUserSession.AccountNumber) {
            accountNumber = data.context.session.BotUserSession.AccountNumber;
        }
    }
    if (accountNumber) {
        overrideMessagePayload = {
            body: JSON.stringify({
                "textmessage": message,
                "accountNumber": accountNumber,
                "siteId": data.context.session.BotUserSession.lastMessage.messagePayload.siteId,
                "uuid": data.context.session.BotUserSession.lastMessage.messagePayload.uuid
            }),
            isTemplate: true
        };
    } else {
        overrideMessagePayload = {
            body: JSON.stringify({
                "textmessage": message,
                "siteId": data.context.session.BotUserSession.lastMessage.messagePayload.siteId,
                "uuid": data.context.session.BotUserSession.lastMessage.messagePayload.uuid
            }),
            isTemplate: true
        };
    }
    return overrideMessagePayload;
}




function getErrorPaylod(data, isError) {
    var overrideMessagePayload;
    if (isError) {
        overrideMessagePayload = {
            body: JSON.stringify({
                "textmessage": "Hmm...Something went wrong and we are looking into it, please try later or may click this link to contact us, send a secure message, or access your account.\n" + config.deeplinks[data.context.session.BotUserSession.lastMessage.messagePayload.siteId.toUpperCase()],
                "siteId": data.context.session.BotUserSession.lastMessage.messagePayload.siteId,
                "uuid": data.context.session.BotUserSession.lastMessage.messagePayload.uuid
            }),
            isTemplate: true
        };
    } else {
        overrideMessagePayload = {
            body: JSON.stringify({
                "textmessage": "Hello, we can't verify your account with this phone number. Please log in to your account via the attached link to update your phone number or call the phone number on the back of your card\n" + config.deeplinks[data.context.session.BotUserSession.lastMessage.messagePayload.siteId.toUpperCase()],
                "siteId": data.context.session.BotUserSession.lastMessage.messagePayload.siteId,
                "uuid": data.context.session.BotUserSession.lastMessage.messagePayload.uuid
            }),
            isTemplate: true
        };
    }
    return overrideMessagePayload;
}

module.exports = {
    botId: botId,
    botName: botName,
    on_user_message: function (requestId, data, callback) {
        console.log('Bot input request: ' + JSON.stringify(data.context.session.BotUserSession.lastMessage));
        if (data.context.session.BotUserSession.lastMessage.channel === "rtm") {
            let uuid = data.channel.type + "/" + data.channel.from;
            redisClient.set(uuid + ":data", JSON.stringify(data), "EX", 14400);
            if (redisClient.get(uuid)) {
                redisClient.del(uuid);
            }
            return lpUtils.onUserMessage(requestId, data, callback);
        }
        if (data.context.session.BotUserSession.lastMessage.channel === "ivr" && data.context.session.BotUserSession.lastMessage.messagePayload.channelId == "SMSAG") {
            data.context.session.BotContext.token = cuProxy.getJWTToken();
            if (data.context.session.BotUserSession.lastMessage && data.context.session.BotUserSession.lastMessage.messagePayload) {
                let messagePayload = data.context.session.BotUserSession.lastMessage.messagePayload;
                let uniqueId = "ivr/" + messagePayload.from.id + "/" + messagePayload.siteId;
                redisClient.set(uniqueId, JSON.stringify(data), "EX", 14440);
                console.log("UniqueId is set : ", uniqueId);
                if (redisClient.get("MakePaymet/" + uniqueId)) {
                    console.log("Deleted the makepayment schedular reqobjs: " + "MakePaymet/" + uniqueId);
                    redisClient.del("MakePaymet/" + uniqueId);
                }
            }
            if (data.context.session.BotUserSession.accountDetailsList && data.context.session.BotUserSession.accountDetailsList.length > 0) {
                console.log("AccountDetails list Already Exist " + data.context.session.BotUserSession.accountDetailsList);
                return sdk.sendBotMessage(data, callback);
            } else {
                console.log("Get AccountDetials from API " + data.context.session.BotUserSession.accountDetailsList);
                getAccountDetails(data).then((response) => {
                    if (response && response.accountDetailsList) {
                        data.context.session.BotUserSession.accountDetailsList = response.accountDetailsList;
                        if (data.context.session.BotUserSession.accountDetailsList.length && data.context.session.BotUserSession.accountDetailsList.length > 0) {
                            if (data.context.session.BotUserSession.accountDetailsList.length == 1) {
                                console.log("user has the sinagle account and adding to context and the accountNumber is: ", data.context.session.BotUserSession.accountDetailsList[0].accountNumber)
                                data.context.session.BotUserSession.AccountNumber = data.context.session.BotUserSession.accountDetailsList[0].accountNumber;
                                var _data = _.cloneDeep(data);
                                _data.metaInfo = {};
                                _data.metaInfo.nlMeta = {};
                                _data.metaInfo.nlMeta.isRefresh = true;
                                sdk.sendBotMessage(_data).then(function () {
                                    return sdk.sendBotMessage(data, callback);;
                                });
                                return callback;
                            } else {
                                console.log("user has the multiples accounts context updated with multiple accounts");
                                data.context.session.BotUserSession.initMsg = data.context.session.BotUserSession.lastMessage.messagePayload.message.text;
                                var _data = _.cloneDeep(data);
                                _data.metaInfo = {};
                                _data.metaInfo.nlMeta = {};
                                _data.metaInfo.nlMeta.isRefresh = true;
                                sdk.sendBotMessage(_data).then(function () {
                                    data.message = "TCPA CHECK";
                                    return sdk.sendBotMessage(data, callback);;
                                });
                                return callback;
                            }
                        } else {
                            console.log("No accounts associted with this phone number", data.context.session.BotUserSession.lastMessage.messagePayload);
                            data.overrideMessagePayload = getErrorPaylod(data, false);
                            return sdk.sendUserMessage(data, callback);
                        }
                    } else {
                        console.log("Something went wrong with Fusion ", data.context.session.BotUserSession.lastMessage.messagePayload);
                        data.overrideMessagePayload = getErrorPaylod(data, true);
                        return sdk.sendUserMessage(data, callback);
                    }
                });
            }
        } else {
            return sdk.sendBotMessage(data, callback);
        }
    },
    on_webhook: function (requestId, data, componentId, callback) {
        console.log('make api call here' + componentId)
        var ph = data.context.session.BotUserSession.lastMessage.messagePayload.from.id
        ph = ph.split("@");
        ph = ph[0];
        var account = data.context.session.BotUserSession.AccountNumber
        console.log("####Account number selected###" + data.context.session.BotUserSession.AccountNumber)
        console.log("####Phone number selected###" + data.context.session.BotUserSession.lastMessage.messagePayload.from.id)
        console.log("Webhook invoked" + JSON.stringify(data))
        var siteId = data.context.session.BotUserSession.lastMessage.messagePayload.siteId
        if (componentId === "StopSMSHook") {
            console.log("####Inside stopSMSHook")
            stopsms.stopAPICall(data, "FromWebhook");
	    callback(null,data);
            cuProxy.clearContext(data);
        }
        else if(componentId === "StopSMSOptionOne"){
            console.log("#####Inside StopSMSOptionOne#####");
            callback(null,data);
            cuProxy.clearContext(data);
        }
    },
    on_bot_message: function (requestId, data, callback) {
        console.log("Bot Respponse from Platform: " + JSON.stringify(data.message));
        try {
            if (data.context.session.BotUserSession && !(data.metaInfo.matchedIntentType && data.metaInfo.matchedIntentType !== 'dialog') && data.context.session.BotUserSession.lastIntent && data.context.session.BotUserSession.lastIntent === data.context.intent) {
                console.log("same intent");
            } else {
                var report = {
                    "channel": data.context.session.BotUserSession.lastMessage.channel,
                    "timestamp": getTimeStamp()
                };
                if (data.context.session.BotUserSession.channels) {
                    report.userId = data.context.session.BotUserSession.channels[0].userId;
                }
                if (data.metaInfo.matchedIntentType && data.metaInfo.matchedIntentType !== 'dialog') {
                    report.intent = data.metaInfo.matchedIntentType;
                } else {
                    report.intent = data.context.intent;
                    data.context.session.BotUserSession.lastIntent = data.context.intent;
                }
                if (!report.intent) {
                    report.intent = "smalltalk";
                }
                if (data.context.session.BotUserSession.lastMessage.channel === "ivr") {
                    report.siteId = data.context.session.BotUserSession.lastMessage.messagePayload.siteId;
                    report.type = "consumer";
                } else {
                    if (data.context.session.UserContext.secureCustomData) {
                        var secureCustomData = JSON.parse(data.context.session.UserContext.secureCustomData);
                        console.log("SecureCustomData" + JSON.stringify(secureCustomData));
                        report.siteId = secureCustomData.siteId;
                        if (data.context.session.UserContext.secureCustomData.includes("consumer")) {
                            report.type = "consumer";
                        } else {
                            report.type = "commercial";
                        }
                    } else {
                        report.type = "botbuilder";
                    }
                }
                console.log("Report Data: " + JSON.stringify(report));
                var db = mongoUtil.getDb();
                if (db) {
                    db.collection('reports').insertOne(report, (err, result) => {
                        if (err) {
                            console.log("Unable to save the data" + err)
                        } else {
                            console.log('saved to database')
                        }
                    });
                }
            }
        } catch (e) {
            console.log(e)
        }
        if (!isEmpty(data.message)) {
            if (data._originalPayload.channel.type == "ivr") {
                if (data.message.includes("Callback seen")) {
                    return sdk.sendUserMessage(data, callback);
                }
                if (data.context && data.context.intent && data.context.intent.includes("Stop")) {
                    let uuid = data.channel.type + "/" + data.channel.from;
                    stopsms.updateRedisWithData(uuid, data, null);
                    console.log('Inside stop uuid to be added to redis' + uuid);
                }
                if (data.context && data.context.intent && (data.context.intent.includes("MakePayment") || data.context.intent.includes("Get Transactions") || data.context.intent.includes("AccountBalance"))) {
                    console.log('flow context: ' + JSON.stringify(data))
                    if (data.context.intent === "MakePayment") {
                        let messagePayload = data.context.session.BotUserSession.lastMessage.messagePayload;
                        let paymentuuid = "MakePayment/ivr/" + messagePayload.from.id + "/" + messagePayload.siteId
                        if (data.message && data.message.includes("NOSCHEDULER:")) {
                            data.message = data.message.replace("NOSCHEDULER:", "");
                            console.log("Make payment schedular is disabling for uuid: " + paymentuuid);
                            if (redisClient.get(paymentuuid)) {
                                console.log("Deleted the makepayment schedular reqobjs: " + paymentuuid);
                                redisClient.del(paymentuuid);
                            }
                        } else {
                            console.log("Make payment schedular is enabling on: " + paymentuuid)
                            MakePaymentScheduler(paymentuuid, data, null);
                        }
                    }
                }
                if (data && data.context.session && data.context.session.BotUserSession && data.context.session.BotUserSession.AccountNumber) {
                    console.log("Account number is set in the session###" + data.context.session.BotUserSession.AccountNumber + "##Message" + data.message)
                    if (IsJsonString(data.message)) {
                        var mesObj = JSON.parse(data.message);
                        if ("isTemplate" in mesObj) {
                            console.info("It is template type" + mesObj.text);
                            if (mesObj.text.includes('Select an option')) {
                                let text = mesObj.text;
                                var a = "";
                                var res = text.split("\n");
                                for (var i = 0; i < res.length; i++) {
                                    if (res[i]) {
                                        if (res[i].match(/^[a-z]/)) {
                                            var x = res[i].match(/^[a-z]/);
                                            console.log(x);
                                            a = a + res[i].replace(x, x[0].charCodeAt() - 96) + "\n";
                                        } else {
                                            a = a + res[i] + "\n";
                                        }
                                    }
                                }
                                data.overrideMessagePayload = changePaylod(data, a);
                            } else {
                                data.overrideMessagePayload = changePaylod(data, mesObj.text);
                            }
                        } else {
                            console.info("###1It is object type" + JSON.parse(data.message).textmessage);
                            if (JSON.parse(data.message).textmessage) {
                                if (!JSON.parse(data.message).uuid) {
                                    data.overrideMessagePayload = changePaylod(data, JSON.parse(data.message).textmessage);
                                }
                            }
                        }
                        return sdk.sendUserMessage(data, callback);
                    } else {
                        console.info("It is string type" + data._originalPayload.channel.message);
                        if (data.message.includes("TCPA Replace Init")) {
                            console.log("Inside the TCPA", data.context.session.BotUserSession.initMsg);
                            sdk.sendUserMessage(data).then(function () {
                                console.log("Updating the message with init message");
                                data.message = data.context.session.BotUserSession.initMsg;
                                return sdk.sendBotMessage(data, callback);
                            })
                            return callback;
                        } else if (data.message.includes("Error occured:") || data.message.includes("Are you sure.?")) {
                            var uniqueId = "ivr/" + data.context.session.BotUserSession.lastMessage.messagePayload.siteId + "/" + data.context.session.BotUserSession.lastMessage.messagePayload.uuid;
                            console.log("Error occured: #### Uniqe message and uniquId: ", uniqueId);
                            cuProxy.clearContext(data);
                            redisClient.get(uniqueId, function (err, redisdata) {
                                if (redisdata) {
                                    data.overrideMessagePayload = {
                                        body: JSON.stringify({
                                            "textmessage": "Hmm...Something went wrong and we are looking into it, please try later or may click this link to contact us, send a secure message, or access your account.\n" + config.deeplinks[data.context.session.BotUserSession.lastMessage.messagePayload.siteId.toUpperCase()],
                                            "uuid": data.context.session.BotUserSession.lastMessage.messagePayload.uuid
                                        }),
                                        isTemplate: true
                                    };
                                    return sdk.sendUserMessage(data, callback);
                                } else {
                                    redisClient.set(uniqueId, true, "EX", 200);
                                    data.overrideMessagePayload = getErrorPaylod(data, true);
                                    return sdk.sendUserMessage(data, callback);
                                }
                            })
                        } else {
                            data.overrideMessagePayload = changePaylod(data, data.message);
                            return sdk.sendUserMessage(data, callback);
                        }
                    }
                } else {
                    if (data.message.includes("TCPA Allowed Text:")) {
                        data.overrideMessagePayload = {
                            body: JSON.stringify({
                                "textmessage": data.message.replace("TCPA Allowed Text:", ""),
                                "siteId": data.context.session.BotUserSession.lastMessage.messagePayload.siteId,
                                "uuid": data.context.session.BotUserSession.lastMessage.messagePayload.uuid
                            }),
                            isTemplate: true
                        };
                        if (!(data.context.session.BotUserSession.accountDetailsList && data.context.session.BotUserSession.accountDetailsList.length)) {
                            data.context.session.BotUserSession.accountDetailsList = data.context.session.BotUserSession.unUsedAccountDetailsList;
                        }
                        return sdk.sendUserMessage(data, callback);
                    } else if (data.message.includes("Error occured:") || data.message.includes("Are you sure")) {
                        console.log("Platform defalut error message")
                        var uniqueId = "ivr/" + data.context.session.BotUserSession.lastMessage.messagePayload.siteId + "/" + data.context.session.BotUserSession.lastMessage.messagePayload.uuid;
                        console.log("#### Uniqe message and uniquId: ", uniqueId);
                        cuProxy.clearContext(data);
                        redisClient.get(uniqueId, function (err, redisdata) {
                            if (redisdata) {
                                data.overrideMessagePayload = {
                                    body: JSON.stringify({
                                        "textmessage": "Hmm...Something went wrong and we are looking into it, please try later or may click this link to contact us, send a secure message, or access your account.\n" + config.deeplinks[data.context.session.BotUserSession.lastMessage.messagePayload.siteId.toUpperCase()],
                                        "uuid": data.context.session.BotUserSession.lastMessage.messagePayload.uuid
                                    }),
                                    isTemplate: true
                                };
                                return sdk.sendUserMessage(data, callback);
                            } else {
                                redisClient.set(uniqueId, true, "EX", 200);
                                data.overrideMessagePayload = getErrorPaylod(data, true);
                                return sdk.sendUserMessage(data, callback);
                            }
                        })
                    } else {
                        console.log("Discarding the text", data.message);
                        if (data.context.session.BotUserSession && data.context.session.BotUserSession.accountDetailsList && data.context.session.BotUserSession.accountDetailsList === undefined && data.context.session.BotUserSession.accountDetailsList.length) {
                            console.log("###1Ignoring the message");
                            data.overrideMessagePayload = {
                                body: JSON.stringify({
                                    "textmessage": "Hello, we can't verify your account with this phone number. Please log in to your account via the attached link to update your phone number or call the phone number on the back of your card\n" + config.deeplinks[data.context.session.BotUserSession.lastMessage.messagePayload.siteId.toUpperCase()],
                                    "uuid": data.context.session.BotUserSession.lastMessage.messagePayload.uuid
                                }),
                                isTemplate: true
                            };
                            return sdk.sendUserMessage(data, callback);
                        } else {
                            var uniqueId = "ivr/" + data.context.session.BotUserSession.lastMessage.messagePayload.siteId + "/" + data.context.session.BotUserSession.lastMessage.messagePayload.uuid;
                            console.log("#### Uniqe message and uniquId: ", uniqueId);
                            data.context.session.BotUserSession.accountDetailsList = [];
                            redisClient.get(uniqueId, function (err, redisdata) {
                                if (redisdata) {
                                    data.overrideMessagePayload = {
                                        body: JSON.stringify({
                                            "textmessage": "Hello, we can't verify your account with this phone number. Please log in to your account via the attached link to update your phone number or call the phone number on the back of your card\n" + config.deeplinks[data.context.session.BotUserSession.lastMessage.messagePayload.siteId.toUpperCase()],
                                            "uuid": data.context.session.BotUserSession.lastMessage.messagePayload.uuid
                                        }),
                                        isTemplate: true
                                    };
                                    return sdk.sendUserMessage(data, callback);
                                } else {
                                    console.log("Inside the redisclient and setting up uuid", uniqueId)
                                    redisClient.set(uniqueId, true, "EX", 300);
                                    data.overrideMessagePayload = getErrorPaylod(data, false);
                                    return sdk.sendUserMessage(data, callback);
                                }
                            });
                        }
                    }
                }
            } else {
                return sdk.sendUserMessage(data, callback);
            }
        } else {
            console.log("***********Empty speech bubble ***************");
            return callback;
        }
    },
    on_agent_transfer: function (requestId, data, callback) {
        console.log("Agent chat initaited requestId: " + requestId);
        let uuid = data.channel.channelInfos.type + "/" + data.channel.channelInfos.from;
        console.log("uuid is: " + uuid);
        redisClient.get(uuid + ":data", function (err, reply) {
            if (reply) {
                let _data = JSON.parse(reply);
                console.log("OnUser message requestId : " + _data.requestId + " Agent transfer requestId: " + requestId);
                lpUtils.connectToAgent(requestId, _data, callback);
            } else {
                lpUtils.connectToAgent(requestId, data, callback);
            }
        })
    },
    lp_notification_event: function (notification) {
        lpUtils.lpNotification(notification);
    },
    get_history: function (req, res) {
        gethistory(req, res);
    },
    on_event: function (requestId, data, callback) {
        if (data.channel.type === 'rtm') {
            if (data.event.eventType === 'endFAQ') {
                console.log("End of dialog reached!!!!");
                let uuid = data.channel.type + "/" + data.channel.from;
                feedback(uuid, data, null);
                if (data.context.session.BotUserSession.rephraseCount) {
                    data.context.session.BotUserSession.rephraseCount = undefined;
                }
            }
            console.log("Displaying repharse count: ", data.context.session.BotUserSession.rephraseCount)
            var ignoreIntentsArray = config.ignoreIntents;
            if (data.event.eventType === 'endDialog') {
                if (data.context.intent && !ignoreIntentsArray.includes(data.context.intent)) {
                    console.log("Found Intent is :", data.context.intent, "!!!!Ignore intent is not matched : End of dialog reached!!!!");
                    let uuid = data.channel.type + "/" + data.channel.from;
                    feedback(uuid, data, null);
                }
            }
            console.log("on_event --> Event : ", data.event, data.context.intent);
            return callback(null, data);
        } else if (data.channel.type === 'ivr' && data.event.eventType === 'endDialog') {
            console.log("End of event for SMS", data.event, data.context.intent)
            try {
                let messagePayload = data.context.session.BotUserSession.lastMessage.messagePayload;
                let paymentuuid = "MakePayment/ivr/" + messagePayload.from.id + "/" + messagePayload.siteId;
                console.log("End of event for SMS UniqueId is  : ", paymentuuid);
                if (redisClient.get(paymentuuid)) {
                    console.log("End of event for SMS Deleted the makepayment flow reqobjs: " + paymentuuid);
                    redisClient.del(paymentuuid);
                }
            } catch (Err) {
                console.log("End of event Error occured in deleting the object : ", Err);
            }
        } else {
            console.log("Ignore the event", data.event, data.context.intent)
        }
    }
};





