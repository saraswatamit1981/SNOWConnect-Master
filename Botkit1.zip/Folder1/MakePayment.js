

var sdk = require("./lib/sdk");
var config = require("./config");
var sub = require("./lib/RedisClient.js").createClient(config.redis);
var pub = require("./lib/RedisClient.js").createClient(config.redis);
var request = require('request-promise');
var cuProxy = require("./cuproxy");
pub.config("SET", "notify-keyspace-events", "KExA");
var _ = require('lodash');
var os = require("os");
var hostname = os.hostname().replace(/\./g, '');

function updateRedisWithData(paymentuuid, data) {
    var paymentuuid = paymentuuid + ":" + hostname;
    console.log("updating the make payment redis: " + paymentuuid); 
    try {
        pub.set(paymentuuid, hostname, "EX", 3480);
        // pub.expire(paymentuuid, ,data.context.session.BotUserSession.makePaymentTime);
        sub.subscribe("__keyspace@0__:" + paymentuuid);
    } catch (Err) {
        console.log("Error in updating make payment redis "+paymentuuid, Err);
    }
}
sub.on('message', function (channel, msg) {
    try {
        if (msg == "expired") {
            console.log("Triggering make payment after 1 hours " + channel + " message : " + msg);
            if (channel && channel.split(":")[2] && hostname === channel.split(":")[2]) {
                var id = channel.split(":")[1];
                console.log("id", id)
                pub.get(id.replace("MakePayment/", ""), function (err, reply) {
                    var data = JSON.parse(reply);
                    console.log("clearing context after 1 hour" + JSON.stringify(data));
                    return cuProxy.clearContext(data);
                });
            }
            else {
                console.log("Ignoring Other host need to handle this");
            }
        }
    } catch (err) {
        console.log("error in make payment", err);
    }

});
module.exports = updateRedisWithData;







