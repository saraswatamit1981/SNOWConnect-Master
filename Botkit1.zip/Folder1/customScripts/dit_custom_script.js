function formatDate(date) {
    var dd = date.getDate();
    var mm = date.getMonth() + 1;
    var yyyy = date.getFullYear();
    if (dd < 10) {
        dd = '0' + dd;
    }
    if (mm < 10) {
        mm = '0' + mm;
    }
    return mm + '/' + dd + '/' + yyyy;
}
var formatter = new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 2
});

function getFaqResponse(faqRes) {
    var type = "consumer";
    switch (type) {
        case "consumer":
            return faqRes.consumer;
        case "commercialFleet":
            return faqRes.commercialFleet;
        case "commercialProx":
            return faqRes.commercialProx;
        default:
            return faqRes.normal;
    }
}
var all_urls = {
    disputes: {
        consumer: {
            "sears": "/RSnextgen/svc/launch/index.action?langId=en_US&siteId=SEARS&pagename=authenticate#disputeCharge",
            "shop your way": "/RSnextgen/svc/launch/index.action?langId=en_US&siteId=PLCN_SYW&pagename=authenticate#disputeCharge",
            "thd": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HOMEDEPOT&langId=en_US&pagename=authenticate#disputeCharge",
            "best buy": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BESTBUY&langId=en_US&pagename=authenticate#disputeCharge",
            "good year": "/RSnextgen/svc/launch/index.action?siteId=PLCN_GOODYEAR&langId=en_US&pagename=authenticate#disputeCharge",
            "brooks brothers": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BROOKSBROTHERS&langId=en_US&pagename=authenticate#disputeCharge",
            "ford": "/RSnextgen/svc/launch/index.action?siteId=PLCN_SERVICE&langId=en_US&pagename=authenticate#disputeCharge",
            "quick lane": "/RSnextgen/svc/launch/index.action?siteId=PLCN_SERVICE&langId=en_US&pagename=authenticate#disputeCharge",
            "lincoln": "/RSnextgen/svc/launch/index.action?siteId=PLCN_LINCOLNSERVICES&langId=en_US&pagename=authenticate#disputeCharge",
            "shell": "/RSnextgen/svc/launch/index.action?siteId=PLOC_SHELL&langId=en_US&pagename=authenticate#disputeCharge",
            "sunoco": "/RSnextgen/svc/launch/index.action?siteId=PLOC_SUNOCO&langId=en_US&pagename=authenticate#disputeCharge",
            "exxonmobil": "/RSnextgen/svc/launch/index.action?siteId=PLOC_EXXONMOBIL&langId=en_US&pagename=authenticate#disputeCharge",
            "american airlines": "/RSnextgen/svc/launch/index.action?siteId=PLCN_AMERICAN&langId=en_US&pagename=authenticate#disputeCharge",
            "brand source": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BRANDSOURCE&langId=en_US&pagename=authenticate#disputeCharge",
            "tractor supply": "/RSnextgen/svc/launch/index.action?siteId=PLCN_TRACTORSUPPLY&langId=en_US&pagename=authenticate#disputeCharge",
            "ross simons-sidney thomas": "/RSnextgen/svc/launch/index.action?siteId=PLCN_JEWELRY&langId=en_US&pagename=authenticate#disputeCharge",
            "jewelers reserve": "/RSnextgen/svc/launch/index.action?siteId=PLCN_JEWELRY&langId=en_US&pagename=authenticate#disputeCharge",
            "staples": "/RSnextgen/svc/launch/index.action?siteId=PLCN_STAPLES&langId=en_US&pagename=authenticate#disputeCharge",
            "office depot": "/RSnextgen/svc/launch/index.action?siteId=PLCN_OFFICEDEPOT&langId=en_US&pagename=authenticate#disputeCharge",
            "wawa": "/RSnextgen/svc/launch/index.action?siteId=PLOC_WAWA&langId=en_US&pagename=authenticate#disputeCharge",
            "volkswagen drive card": "/RSnextgen/svc/launch/index.action?siteId=PLCN_DRIVECARD&langId=en_US&pagename=authenticate#disputeCharge",
            "service central": "/RSnextgen/svc/launch/index.action?siteId=PLCN_SERVICECENTRAL&langId=en_US&pagename=authenticate#disputeCharge",
            "brp": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BRP&langId=en_US&pagename=authenticate#disputeCharge",
            "toro": "/RSnextgen/svc/launch/index.action?siteId=PLCN_TORO&langId=en_US&pagename=authenticate#disputeCharge",
            "honda power equipment": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HNPE&langId=en_US&pagename=authenticate#disputeCharge",
            "kawasaki": "/RSnextgen/svc/launch/index.action?siteId=PLCN_KAWA&langId=en_US&pagename=authenticate#disputeCharge",
            "honda power sports": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HNPS&langId=en_US&pagename=authenticate#disputeCharge",
            "macys": "/RSnextgen/svc/launch/index.action?siteId=PLCN_MACYS&langId=en_US&pagename=authenticate#disputeCharge",
            "bloomingdales": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BLOOMINGDALES&langId=en_US&pagename=authenticate#disputeCharge",
            "costco": "/RSnextgen/svc/launch/index.action?siteId=PLCN_COSTCO&langId=en_US&pagename=authenticate#disputeCharge",
            "home furnishings": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HOME&langId=en_US&pagename=authenticate#disputeCharge",
            "consumer electronics and appliances": "/RSnextgen/svc/launch/index.action?siteId=PLCN_ELECAPPL&langId=en_US&pagename=authenticate#disputeCharge",
            "llbean": "/RSnextgen/svc/launch/index.action?siteId=PLCN_LLBEAN&langId=en_US&pagename=authenticate#disputeCharge",
            "cat": "/RSnextgen/svc/launch/index.action?siteId=PLCN_CAT&langId=en_US&pagename=authenticate#disputeCharge",
            "meijer": "/RSnextgen/svc/launch/index.action?siteId=PLCN_Meijer&langId=en_US&pagename=authenticate#disputeCharge"
        },
        commercial: {
            crc: {
                toro: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_TORO#servc/disputecharge",
                cnhi: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_CNHI#servc/disputecharge",
                "tractor supply": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_TRACTORSUPPLY#servc/disputecharge",
                thd: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_HOMEDEPOT#servc/disputecharge",
                staples: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_STAPLES#servc/disputecharge",
                "honda power equipment": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_HNPE#servc/disputecharge",
                cat: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_Cat#servc/disputecharge",
                "office depot": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_OFFICEDEPOT#servc/disputecharge"
            },
            prox: {
                thd: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_HOMEDEPOT#servc/disputecharge",
                staples: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_Staples#servc/disputecharge",
                cat: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_CAT#servc/disputecharge",
                "office depot": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_Officedepot#servc/disputecharge"
            },
            fleet: {
                exxon: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLOF_EXXONMOBIL#servc/disputecharge",
                sunoco: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLOF_SUNOCO#servc/disputecharge"
            }
        }
    },
    lostcard: {
        consumer: {
            "sears": "/RSnextgen/svc/launch/index.action?siteId=SEARS&langId=en_US&pagename=authenticate#reportlostorstolen",
            "shop your way": "/RSnextgen/svc/launch/index.action?siteId=PLCN_SYW&langId=en_US&pagename=authenticate#reportlostorstolen",
            "thd": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HOMEDEPOT&langId=en_US&pagename=authenticate#reportlostorstolen",
            "best buy": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BESTBUY&langId=en_US&pagename=authenticate#reportlostorstolen",
            "good year": "/RSnextgen/svc/launch/index.action?siteId=PLCN_GOODYEAR&langId=en_US&pagename=authenticate#reportlostorstolen",
            "brooks brothers": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BROOKSBROTHERS&langId=en_US&pagename=authenticate#reportlostorstolen",
            "ford": "/RSnextgen/svc/launch/index.action?siteId=PLCN_SERVICE&langId=en_US&pagename=authenticate#reportlostorstolen",
            "quick lane": "/RSnextgen/svc/launch/index.action?siteId=PLCN_SERVICE&langId=en_US&pagename=authenticate#reportlostorstolen",
            "lincoln": "/RSnextgen/svc/launch/index.action?siteId=PLCN_LINCOLNSERVICES&langId=en_US&pagename=authenticate#reportlostorstolen",
            "shell": "/RSnextgen/svc/launch/index.action?siteId=PLOC_SHELL&langId=en_US&pagename=authenticate#reportlostorstolen",
            "sunoco": "/RSnextgen/svc/launch/index.action?siteId=PLOC_SUNOCO&langId=en_US&pagename=authenticate#reportlostorstolen",
            "exxonmobil": "/RSnextgen/svc/launch/index.action?siteId=PLOC_EXXONMOBIL&langId=en_US&pagename=authenticate#reportlostorstolen",
            "american airlines": "/RSnextgen/svc/launch/index.action?siteId=PLCN_AMERICAN&langId=en_US&pagename=authenticate#reportlostorstolen",
            "brand source": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BRANDSOURCE&langId=en_US&pagename=authenticate#reportlostorstolen",
            "tractor supply": "/RSnextgen/svc/launch/index.action?siteId=PLCN_TRACTORSUPPLY&langId=en_US&pagename=authenticate#reportlostorstolen",
            "ross simons-sidney thomas": "/RSnextgen/svc/launch/index.action?siteId=PLCN_JEWELRY&langId=en_US&pagename=authenticate#reportlostorstolen",
            "jewelers reserve": "/RSnextgen/svc/launch/index.action?siteId=PLCN_JEWELRY&langId=en_US&pagename=authenticate#reportlostorstolen",
            "staples": "/RSnextgen/svc/launch/index.action?siteId=PLCN_STAPLES&langId=en_US&pagename=authenticate#reportlostorstolen",
            "office depot": "/RSnextgen/svc/launch/index.action?siteId=PLCN_OFFICEDEPOT&langId=en_US&pagename=authenticate#reportlostorstolen",
            "wawa": "/RSnextgen/svc/launch/index.action?siteId=PLOC_WAWA&langId=en_US&pagename=authenticate#reportlostorstolen",
            "volkswagen drive card": "/RSnextgen/svc/launch/index.action?siteId=PLCN_DRIVECARD&langId=en_US&pagename=authenticate#reportlostorstolen",
            "service central": "/RSnextgen/svc/launch/index.action?siteId=PLCN_SERVICECENTRAL&langId=en_US&pagename=authenticate#reportlostorstolen",
            "brp": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BRP&langId=en_US&pagename=authenticate#reportlostorstolen",
            "toro": "/RSnextgen/svc/launch/index.action?siteId=PLCN_TORO&langId=en_US&pagename=authenticate#reportlostorstolen",
            "honda power equipment": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HNPE&langId=en_US&pagename=authenticate#reportlostorstolen",
            "kawasaki": "/RSnextgen/svc/launch/index.action?siteId=PLCN_KAWA&langId=en_US&pagename=authenticate#reportlostorstolen",
            "honda power sports": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HNPS&langId=en_US&pagename=authenticate#reportlostorstolen",
            "macys": "/RSnextgen/svc/launch/index.action?siteId=PLCN_MACYS&langId=en_US&pagename=authenticate#reportlostorstolen",
            "bloomingdales": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BLOOMINGDALES&langId=en_US&pagename=authenticate#reportlostorstolen",
            "costco": "/RSnextgen/svc/launch/index.action?siteId=PLCN_COSTCO&langId=en_US&pagename=authenticate#reportlostorstolen",
            "home furnishings": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HOME&langId=en_US&pagename=authenticate#reportlostorstolen",
            "consumer electronics and appliances": "/RSnextgen/svc/launch/index.action?siteId=PLCN_ELECAPPL&langId=en_US&pagename=authenticate#reportlostorstolen",
            "llbean": "/RSnextgen/svc/launch/index.action?siteId=PLCN_LLBEAN&langId=en_US&pagename=authenticate#reportlostorstolen",
            "cat": "/RSnextgen/svc/launch/index.action?siteId=PLCN_CAT&langId=en_US&pagename=authenticate#reportlostorstolen",
            "meijer": "/RSnextgen/svc/launch/index.action?siteId=PLCN_Meijer&langId=en_US&pagename=authenticate#reportlostorstolen"
        },
        commercial: {
            crc: {
                toro: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_TORO#servc/lostcard",
                cnhi: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_CNHI#servc/lostcard",
                "tractor supply": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_TRACTORSUPPLY#servc/lostcard",
                thd: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_HOMEDEPOT#servc/lostcard",
                staples: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_STAPLES#servc/lostcard",
                "honda power equipment": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_HNPE#servc/lostcard",
                cat: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_Cat#servc/lostcard",
                "office depot": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_OFFICEDEPOT#servc/lostcard"
            },
            prox: {
                thd: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_HOMEDEPOT#servc/lostcard",
                staples: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_Staples#servc/lostcard",
                cat: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_CAT#servc/lostcard",
                "office depot": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_Officedepot#servc/lostcard"
            },
            fleet: {
                exxon: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLOF_EXXONMOBIL#servc/lostcard",
                sunoco: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLOF_SUNOCO#servc/lostcard"
            }
        }
    },
    addAuthUser: {
        consumer: {
            "sears": "/RSnextgen/svc/launch/index.action?langId=en_US&siteId=SEARS&pagename=authenticate#addauthusers",
            "shop your way": "/RSnextgen/svc/launch/index.action?langId=en_US&siteId=PLCN_SYW&pagename=authenticate#addauthusers",
            "thd": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HOMEDEPOT&langId=en_US&pagename=authenticate#addauthusers",
            "best buy": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BESTBUY&langId=en_US&pagename=authenticate#addauthusers",
            "good year": "/RSnextgen/svc/launch/index.action?siteId=PLCN_GOODYEAR&langId=en_US&pagename=authenticate#addauthusers",
            "brooks brothers": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BROOKSBROTHERS&langId=en_US&pagename=authenticate#addauthusers",
            "ford": "/RSnextgen/svc/launch/index.action?siteId=PLCN_SERVICE&langId=en_US&pagename=authenticate#addauthusers",
            "quick lane": "/RSnextgen/svc/launch/index.action?siteId=PLCN_SERVICE&langId=en_US&pagename=authenticate#addauthusers",
            "lincoln": "/RSnextgen/svc/launch/index.action?siteId=PLCN_LINCOLNSERVICES&langId=en_US&pagename=authenticate#addauthusers",
            "shell": "/RSnextgen/svc/launch/index.action?siteId=PLOC_SHELL&langId=en_US&pagename=authenticate#addauthusers",
            "sunoco": "/RSnextgen/svc/launch/index.action?siteId=PLOC_SUNOCO&langId=en_US&pagename=authenticate#addauthusers",
            "exxonmobil": "/RSnextgen/svc/launch/index.action?siteId=PLOC_EXXONMOBIL&langId=en_US&pagename=authenticate#addauthusers",
            "american airlines": "/RSnextgen/svc/launch/index.action?siteId=PLCN_AMERICAN&langId=en_US&pagename=authenticate#addauthusers",
            "brand source": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BRANDSOURCE&langId=en_US&pagename=authenticate#addauthusers",
            "tractor supply": "/RSnextgen/svc/launch/index.action?siteId=PLCN_TRACTORSUPPLY&langId=en_US&pagename=authenticate#addauthusers",
            "ross simons-sidney thomas": "/RSnextgen/svc/launch/index.action?siteId=PLCN_JEWELRY&langId=en_US&pagename=authenticate#addauthusers",
            "jewelers reserve": "/RSnextgen/svc/launch/index.action?siteId=PLCN_JEWELRY&langId=en_US&pagename=authenticate#addauthusers",
            "staples": "/RSnextgen/svc/launch/index.action?siteId=PLCN_STAPLES&langId=en_US&pagename=authenticate#addauthusers",
            "office depot": "/RSnextgen/svc/launch/index.action?siteId=PLCN_OFFICEDEPOT&langId=en_US&pagename=authenticate#addauthusers",
            "wawa": "/RSnextgen/svc/launch/index.action?siteId=PLOC_WAWA&langId=en_US&pagename=authenticate#addauthusers",
            "volkswagen drive card": "/RSnextgen/svc/launch/index.action?siteId=PLCN_DRIVECARD&langId=en_US&pagename=authenticate#addauthusers",
            "service central": "/RSnextgen/svc/launch/index.action?siteId=PLCN_SERVICECENTRAL&langId=en_US&pagename=authenticate#addauthusers",
            "brp": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BRP&langId=en_US&pagename=authenticate#addauthusers",
            "toro": "/RSnextgen/svc/launch/index.action?siteId=PLCN_TORO&langId=en_US&pagename=authenticate#addauthusers",
            "honda power equipment": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HNPE&langId=en_US&pagename=authenticate#addauthusers",
            "kawasaki": "/RSnextgen/svc/launch/index.action?siteId=PLCN_KAWA&langId=en_US&pagename=authenticate#addauthusers",
            "honda power sports": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HNPS&langId=en_US&pagename=authenticate#addauthusers",
            "macys": "/RSnextgen/svc/launch/index.action?siteId=PLCN_MACYS&langId=en_US&pagename=authenticate#addauthusers",
            "bloomingdales": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BLOOMINGDALES&langId=en_US&pagename=authenticate#addauthusers",
            "costco": "/RSnextgen/svc/launch/index.action?siteId=PLCN_COSTCO&langId=en_US&pagename=authenticate#addauthusers",
            "home furnishings": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HOME&langId=en_US&pagename=authenticate#addauthusers",
            "consumer electronics and appliances": "/RSnextgen/svc/launch/index.action?siteId=PLCN_ELECAPPL&langId=en_US&pagename=authenticate#addauthusers",
            "llbean": "/RSnextgen/svc/launch/index.action?siteId=PLCN_LLBEAN&langId=en_US&pagename=authenticate#addauthusers",
            "cat": "/RSnextgen/svc/launch/index.action?siteId=PLCN_CAT&langId=en_US&pagename=authenticate#addauthusers",
            "meijer": "/RSnextgen/svc/launch/index.action?siteId=PLCN_meijer&langId=en_US&pagename=authenticate#addauthusers"
        },
        commercial: {
            crc: {
                toro: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_TORO#pro/adduser",
                cnhi: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_CNHI#pro/adduser",
                "tractor supply": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_TRACTORSUPPLY#pro/adduser",
                thd: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_HOMEDEPOT#pro/adduser",
                staples: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_STAPLES#pro/adduser",
                "honda power equipment": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_HNPE#pro/adduser",
                cat: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_Cat#pro/adduser",
                "office depot": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_OFFICEDEPOT#pro/adduser"
            },
            prox: {
                thd: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_HOMEDEPOT#pro/adduser",
                staples: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_Staples#pro/adduser",
                cat: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_CAT#pro/adduser",
                "office depot": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_Officedepot#pro/adduser"
            },
            fleet: {
                exxon: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLOF_EXXONMOBIL#pro/adduser",
                sunoco: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLOF_SUNOCO#pro/adduser"
            }
        }
    },
    creditHome: {
        consumer: {
            "sears": "/RSnextgen/svc/launch/index.action?siteId=SEARS&pagename=authenticate#dashboard",
            "shop your way": "/RSnextgen/svc/launch/index.action?siteId=PLCN_SYW&pagename=authenticate#dashboard",
            "thd": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HOMEDEPOT&pagename=authenticate#dashboard",
            "best buy": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BESTBUY&pagename=authenticate#dashboard",
            "good year": "/RSnextgen/svc/launch/index.action?siteId=PLCN_GOODYEAR&pagename=authenticate#dashboard",
            "brooks brothers": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BROOKSBROTHERS&pagename=authenticate#dashboard",
            "ford": "/RSnextgen/svc/launch/index.action?siteId=PLCN_SERVICE&pagename=authenticate#dashboard",
            "quick lane": "/RSnextgen/svc/launch/index.action?siteId=PLCN_SERVICE&pagename=authenticate#dashboard",
            "lincoln": "/RSnextgen/svc/launch/index.action?siteId=PLCN_LINCOLNSERVICES&pagename=authenticate#dashboard",
            "shell": "/RSnextgen/svc/launch/index.action?siteId=PLOC_SHELL&pagename=authenticate#dashboard",
            "sunoco": "/RSnextgen/svc/launch/index.action?siteId=PLOC_SUNOCO&pagename=authenticate#dashboard",
            "exxonmobil": "/RSnextgen/svc/launch/index.action?siteId=PLOC_EXXONMOBIL&pagename=authenticate#dashboard",
            "american airlines": "/RSnextgen/svc/launch/index.action?siteId=PLCN_AMERICAN&pagename=authenticate#dashboard",
            "brand source": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BRANDSOURCE&pagename=authenticate#dashboard",
            "tractor supply": "/RSnextgen/svc/launch/index.action?siteId=PLCN_TRACTORSUPPLY&pagename=authenticate#dashboard",
            "ross simons-sidney thomas": "/RSnextgen/svc/launch/index.action?siteId=PLCN_JEWELRY&pagename=authenticate#dashboard",
            "jewelers reserve": "/RSnextgen/svc/launch/index.action?siteId=PLCN_JEWELRY&pagename=authenticate#dashboard",
            "staples": "/RSnextgen/svc/launch/index.action?siteId=PLCN_STAPLES&pagename=authenticate#dashboard",
            "office depot": "/RSnextgen/svc/launch/index.action?siteId=PLCN_OFFICEDEPOT&pagename=authenticate#dashboard",
            "wawa": "/RSnextgen/svc/launch/index.action?siteId=PLOC_WAWA&pagename=authenticate#dashboard",
            "volkswagen drive card": "/RSnextgen/svc/launch/index.action?siteId=PLCN_DRIVECARD&pagename=authenticate#dashboard",
            "service central": "/RSnextgen/svc/launch/index.action?siteId=PLCN_SERVICECENTRAL&pagename=authenticate#dashboard",
            "brp": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BRP&pagename=authenticate#dashboard",
            "toro": "/RSnextgen/svc/launch/index.action?siteId=PLCN_TORO&pagename=authenticate#dashboard",
            "honda power equipment": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HNPE&pagename=authenticate#dashboard",
            "kawasaki": "/RSnextgen/svc/launch/index.action?siteId=PLCN_KAWA&pagename=authenticate#dashboard",
            "honda power sports": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HNPS&pagename=authenticate#dashboard",
            "macys": "/RSnextgen/svc/launch/index.action?siteId=PLCN_MACYS&pagename=authenticate#dashboard",
            "bloomingdales": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BLOOMINGDALES&pagename=authenticate#dashboard",
            "costco": "/RSnextgen/svc/launch/index.action?siteId=PLCN_COSTCO&pagename=authenticate#dashboard",
            "home furnishings": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HOME&pagename=authenticate#dashboard",
            "consumer electronics and appliances": "/RSnextgen/svc/launch/index.action?siteId=PLCN_ELECAPPL&pagename=authenticate#dashboard",
            "llbean": "/RSnextgen/svc/launch/index.action?siteId=PLCN_LLBEAN&langId=en_US&pagename=authenticate#rewards",
            "cat": "/RSnextgen/svc/launch/index.action?siteId=PLCN_CAT&pagename=authenticate#dashboard",
            "meijer": "/RSnextgen/svc/launch/index.action?siteId=PLCN_meijer&pagename=authenticate#dashboard"
        },
        commercial: {
            crc: {
                toro: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_TORO#dash/lan",
                cnhi: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_CNHI#dash/lan",
                "tractor supply": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_TRACTORSUPPLY#dash/lan",
                thd: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_HOMEDEPOT#dash/lan",
                staples: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_STAPLES#dash/lan",
                "honda power equipment": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_HNPE#dash/lan",
                cat: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_Cat#dash/lan",
                "office depot": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_OFFICEDEPOT#dash/lan"
            },
            prox: {
                thd: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_HOMEDEPOT#dash/lan",
                staples: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_Staples#dash/lan",
                cat: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_CAT#dash/lan",
                "office depot": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_Officedepot#dash/lan"
            },
            fleet: {
                exxon: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLOF_EXXONMOBIL#dash/lan",
                sunoco: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLOF_SUNOCO#dash/lan"
            }
        }
    },
    helpContact: {
        consumer: {
            "sears": "/RSnextgen/svc/launch/index.action?langId=en_US&siteId=SEARS&pagename=authenticate#helpcontact",
            "shop your way": "/RSnextgen/svc/launch/index.action?langId=en_US&siteId=PLCN_SYW&pagename=authenticate#helpcontact",
            "thd": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HOMEDEPOT&langId=en_US&pagename=authenticate#helpcontact",
            "best buy": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BESTBUY&langId=en_US&pagename=authenticate#helpcontact",
            "good year": "/RSnextgen/svc/launch/index.action?siteId=PLCN_GOODYEAR&langId=en_US&pagename=authenticate#helpcontact",
            "brooks brothers": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BROOKSBROTHERS&langId=en_US&pagename=authenticate#helpcontact",
            "ford": "/RSnextgen/svc/launch/index.action?siteId=PLCN_SERVICE&langId=en_US&pagename=authenticate#helpcontact",
            "quick lane": "/RSnextgen/svc/launch/index.action?siteId=PLCN_SERVICE&langId=en_US&pagename=authenticate#helpcontact",
            "lincoln": "/RSnextgen/svc/launch/index.action?siteId=PLCN_LINCOLNSERVICES&langId=en_US&pagename=authenticate#helpcontact",
            "shell": "/RSnextgen/svc/launch/index.action?siteId=PLOC_SHELL&langId=en_US&pagename=authenticate#helpcontact",
            "sunoco": "/RSnextgen/svc/launch/index.action?siteId=PLOC_SUNOCO&langId=en_US&pagename=authenticate#helpcontact",
            "exxonmobil": "/RSnextgen/svc/launch/index.action?siteId=PLOC_EXXONMOBIL&langId=en_US&pagename=authenticate#helpcontact",
            "american airlines": "/RSnextgen/svc/launch/index.action?siteId=PLCN_AMERICAN&langId=en_US&pagename=authenticate#helpcontact",
            "brand source": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BRANDSOURCE&langId=en_US&pagename=authenticate#helpcontact",
            "tractor supply": "/RSnextgen/svc/launch/index.action?siteId=PLCN_TRACTORSUPPLY&langId=en_US&pagename=authenticate#helpcontact",
            "ross simons-sidney thomas": "/RSnextgen/svc/launch/index.action?siteId=PLCN_JEWELRY&langId=en_US&pagename=authenticate#helpcontact",
            "jewelers reserve": "/RSnextgen/svc/launch/index.action?siteId=PLCN_JEWELRY&langId=en_US&pagename=authenticate#helpcontact",
            "staples": "/RSnextgen/svc/launch/index.action?siteId=PLCN_STAPLES&langId=en_US&pagename=authenticate#helpcontact",
            "office depot": "/RSnextgen/svc/launch/index.action?siteId=PLCN_OFFICEDEPOT&langId=en_US&pagename=authenticate#helpcontact",
            "wawa": "/RSnextgen/svc/launch/index.action?siteId=PLOC_WAWA&langId=en_US&pagename=authenticate#helpcontact",
            "volkswagen drive card": "/RSnextgen/svc/launch/index.action?siteId=PLCN_DRIVECARD&langId=en_US&pagename=authenticate#helpcontact",
            "service central": "/RSnextgen/svc/launch/index.action?siteId=PLCN_SERVICECENTRAL&langId=en_US&pagename=authenticate#helpcontact",
            "brp": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BRP&langId=en_US&pagename=authenticate#helpcontact",
            "toro": "/RSnextgen/svc/launch/index.action?siteId=PLCN_TORO&langId=en_US&pagename=authenticate#helpcontact",
            "honda power equipment": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HNPE&langId=en_US&pagename=authenticate#helpcontact",
            "kawasaki": "/RSnextgen/svc/launch/index.action?siteId=PLCN_KAWA&langId=en_US&pagename=authenticate#helpcontact",
            "honda power sports": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HNPS&langId=en_US&pagename=authenticate#helpcontact",
            "macys": "/RSnextgen/svc/launch/index.action?siteId=PLCN_MACYS&langId=en_US&pagename=authenticate#helpcontact",
            "bloomingdales": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BLOOMINGDALES&langId=en_US&pagename=authenticate#helpcontact",
            "costco": "/RSnextgen/svc/launch/index.action?siteId=PLCN_COSTCO&langId=en_US&pagename=authenticate#helpcontact",
            "home furnishings": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HOME&langId=en_US&pagename=authenticate#helpcontact",
            "consumer electronics and appliances": "/RSnextgen/svc/launch/index.action?siteId=PLCN_ELECAPPL&langId=en_US&pagename=authenticate#helpcontact",
            "llbean": "/RSnextgen/svc/launch/index.action?siteId=PLCN_LLBEAN&langId=en_US&pagename=authenticate#helpcontact",
            "cat": "/RSnextgen/svc/launch/index.action?siteId=PLCN_CAT&langId=en_US&pagename=authenticate#helpcontact",
            "meijer": "/RSnextgen/svc/launch/index.action?siteId=PLCN_meijer&langId=en_US&pagename=authenticate#helpcontact"
        },
        commercial: {
            crc: {
                toro: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_TORO#help/contact",
                cnhi: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_CNHI#help/contact",
                "tractor supply": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_TRACTORSUPPLY#help/contact",
                thd: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_HOMEDEPOT#help/contact",
                staples: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_STAPLES#help/contact",
                "honda power equipment": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_HNPE#help/contact",
                cat: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_Cat#help/contact",
                "office depot": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_OFFICEDEPOT#help/contact"
            },
            prox: {
                thd: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_HOMEDEPOT#help/contact",
                staples: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_Staples#help/contact",
                cat: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_CAT#help/contact",
                "office depot": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_Officedepot#help/contact"
            },
            fleet: {
                exxon: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLOF_EXXONMOBIL#help/contact",
                sunoco: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLOF_SUNOCO#help/contact"
            }
        }
    },
    payments: {
        consumer: {
            "sears": "/RSnextgen/svc/launch/index.action?langId=en_US&siteId=SEARS&pagename=authenticate#payments",
            "shop your way": "/RSnextgen/svc/launch/index.action?langId=en_US&siteId=PLCN_SYW&pagename=authenticate#payments",
            "thd": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HOMEDEPOT&langId=en_US&pagename=authenticate#payments",
            "best buy": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BESTBUY&langId=en_US&pagename=authenticate#payments",
            "good year": "/RSnextgen/svc/launch/index.action?siteId=PLCN_GOODYEAR&langId=en_US&pagename=authenticate#payments",
            "brooks brothers": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BROOKSBROTHERS&langId=en_US&pagename=authenticate#payments",
            "ford": "/RSnextgen/svc/launch/index.action?siteId=PLCN_SERVICE&langId=en_US&pagename=authenticate#payments",
            "quick lane": "/RSnextgen/svc/launch/index.action?siteId=PLCN_SERVICE&langId=en_US&pagename=authenticate#payments",
            "lincoln": "/RSnextgen/svc/launch/index.action?siteId=PLCN_LINCOLNSERVICES&langId=en_US&pagename=authenticate#payments",
            "shell": "/RSnextgen/svc/launch/index.action?siteId=PLOC_SHELL&langId=en_US&pagename=authenticate#payments",
            "sunoco": "/RSnextgen/svc/launch/index.action?siteId=PLOC_SUNOCO&langId=en_US&pagename=authenticate#payments",
            "exxonmobil": "/RSnextgen/svc/launch/index.action?siteId=PLOC_EXXONMOBIL&langId=en_US&pagename=authenticate#payments",
            "american airlines": "/RSnextgen/svc/launch/index.action?siteId=PLCN_AMERICAN&langId=en_US&pagename=authenticate#payments",
            "brand source": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BRANDSOURCE&langId=en_US&pagename=authenticate#payments",
            "tractor supply": "/RSnextgen/svc/launch/index.action?siteId=PLCN_TRACTORSUPPLY&langId=en_US&pagename=authenticate#payments",
            "ross simons-sidney thomas": "/RSnextgen/svc/launch/index.action?siteId=PLCN_JEWELRY&langId=en_US&pagename=authenticate#payments",
            "jewelers reserve": "/RSnextgen/svc/launch/index.action?siteId=PLCN_JEWELRY&langId=en_US&pagename=authenticate#payments",
            "staples": "/RSnextgen/svc/launch/index.action?siteId=PLCN_STAPLES&langId=en_US&pagename=authenticate#payments",
            "office depot": "/RSnextgen/svc/launch/index.action?siteId=PLCN_OFFICEDEPOT&langId=en_US&pagename=authenticate#payments",
            "wawa": "/RSnextgen/svc/launch/index.action?siteId=PLOC_WAWA&langId=en_US&pagename=authenticate#payments",
            "volkswagen drive card": "/RSnextgen/svc/launch/index.action?siteId=PLCN_DRIVECARD&langId=en_US&pagename=authenticate#payments",
            "service central": "/RSnextgen/svc/launch/index.action?siteId=PLCN_SERVICECENTRAL&langId=en_US&pagename=authenticate#payments",
            "brp": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BRP&langId=en_US&pagename=authenticate#payments",
            "toro": "/RSnextgen/svc/launch/index.action?siteId=PLCN_TORO&langId=en_US&pagename=authenticate#payments",
            "honda power equipment": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HNPE&langId=en_US&pagename=authenticate#payments",
            "kawasaki": "/RSnextgen/svc/launch/index.action?siteId=PLCN_KAWA&langId=en_US&pagename=authenticate#payments",
            "honda power sports": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HNPS&langId=en_US&pagename=authenticate#payments",
            "macys": "/RSnextgen/svc/launch/index.action?siteId=PLCN_MACYS&langId=en_US&pagename=authenticate#payments",
            "bloomingdales": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BLOOMINGDALES&langId=en_US&pagename=authenticate#payments",
            "costco": "/RSnextgen/svc/launch/index.action?siteId=PLCN_COSTCO&langId=en_US&pagename=authenticate#payments",
            "home furnishings": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HOME&langId=en_US&pagename=authenticate#payments",
            "consumer electronics and appliances": "/RSnextgen/svc/launch/index.action?siteId=PLCN_ELECAPPL&langId=en_US&pagename=authenticate#payments",
            "llbean": "/RSnextgen/svc/launch/index.action?siteId=PLCN_LLBEAN&langId=en_US&pagename=authenticate#payments",
            "cat": "/RSnextgen/svc/launch/index.action?siteId=PLCN_CAT&langId=en_US&pagename=authenticate#payments",
            "meijer": "/RSnextgen/svc/launch/index.action?siteId=PLCN_meijer&langId=en_US&pagename=authenticate#payments"
        },
        commercial: {
            crc: {
                toro: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_TORO#paym/payments",
                cnhi: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_CNHI#paym/payments",
                "tractor supply": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_TRACTORSUPPLY#paym/payments",
                thd: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_HOMEDEPOT#paym/payments",
                staples: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_STAPLES#paym/payments",
                "honda power equipment": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_HNPE#paym/payments",
                cat: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_Cat#paym/payments",
                "office depot": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_OFFICEDEPOT#paym/payments"
            },
            prox: {
                thd: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_HOMEDEPOT#paym/payments",
                staples: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_Staples#paym/payments",
                cat: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_CAT#paym/payments",
                "office depot": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_Officedepot#paym/payments"
            },
            fleet: {
                exxon: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLOF_EXXONMOBIL#paym/payments",
                sunoco: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLOF_SUNOCO#paym/payments"
            }
        }
    },
    autopay: {
        consumer: {
            "sears": "/RSnextgen/svc/launch/index.action?langId=en_US&siteId=SEARS&pagename=authenticate#autopay",
            "shop your way": "/RSnextgen/svc/launch/index.action?langId=en_US&siteId=PLCN_SYW&pagename=authenticate#autopay",
            "thd": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HOMEDEPOT&langId=en_US&pagename=authenticate#autopay",
            "best buy": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BESTBUY&langId=en_US&pagename=authenticate#autopay",
            "good year": "/RSnextgen/svc/launch/index.action?siteId=PLCN_GOODYEAR&langId=en_US&pagename=authenticate#autopay",
            "brooks brothers": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BROOKSBROTHERS&langId=en_US&pagename=authenticate#autopay",
            "ford": "/RSnextgen/svc/launch/index.action?siteId=PLCN_SERVICE&langId=en_US&pagename=authenticate#autopay",
            "quick lane": "/RSnextgen/svc/launch/index.action?siteId=PLCN_SERVICE&langId=en_US&pagename=authenticate#autopay",
            "lincoln": "/RSnextgen/svc/launch/index.action?siteId=PLCN_LINCOLNSERVICES&langId=en_US&pagename=authenticate#autopay",
            "shell": "/RSnextgen/svc/launch/index.action?siteId=PLOC_SHELL&langId=en_US&pagename=authenticate#autopay",
            "sunoco": "/RSnextgen/svc/launch/index.action?siteId=PLOC_SUNOCO&langId=en_US&pagename=authenticate#autopay",
            "exxonmobil": "/RSnextgen/svc/launch/index.action?siteId=PLOC_EXXONMOBIL&langId=en_US&pagename=authenticate#autopay",
            "american airlines": "/RSnextgen/svc/launch/index.action?siteId=PLCN_AMERICAN&langId=en_US&pagename=authenticate#autopay",
            "brand source": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BRANDSOURCE&langId=en_US&pagename=authenticate#autopay",
            "tractor supply": "/RSnextgen/svc/launch/index.action?siteId=PLCN_TRACTORSUPPLY&langId=en_US&pagename=authenticate#autopay",
            "ross simons-sidney thomas": "/RSnextgen/svc/launch/index.action?siteId=PLCN_JEWELRY&langId=en_US&pagename=authenticate#autopay",
            "jewelers reserve": "/RSnextgen/svc/launch/index.action?siteId=PLCN_JEWELRY&langId=en_US&pagename=authenticate#autopay",
            "staples": "/RSnextgen/svc/launch/index.action?siteId=PLCN_STAPLES&langId=en_US&pagename=authenticate#autopay",
            "office depot": "/RSnextgen/svc/launch/index.action?siteId=PLCN_OFFICEDEPOT&langId=en_US&pagename=authenticate#autopay",
            "wawa": "/RSnextgen/svc/launch/index.action?siteId=PLOC_WAWA&langId=en_US&pagename=authenticate#autopay",
            "volkswagen drive card": "/RSnextgen/svc/launch/index.action?siteId=PLCN_DRIVECARD&langId=en_US&pagename=authenticate#autopay",
            "service central": "/RSnextgen/svc/launch/index.action?siteId=PLCN_SERVICECENTRAL&langId=en_US&pagename=authenticate#autopay",
            "brp": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BRP&langId=en_US&pagename=authenticate#autopay",
            "toro": "/RSnextgen/svc/launch/index.action?siteId=PLCN_TORO&langId=en_US&pagename=authenticate#autopay",
            "honda power equipment": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HNPE&langId=en_US&pagename=authenticate#autopay",
            "kawasaki": "/RSnextgen/svc/launch/index.action?siteId=PLCN_KAWA&langId=en_US&pagename=authenticate#autopay",
            "honda power sports": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HNPS&langId=en_US&pagename=authenticate#autopay",
            "macys": "/RSnextgen/svc/launch/index.action?siteId=PLCN_MACYS&langId=en_US&pagename=authenticate#autopay",
            "bloomingdales": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BLOOMINGDALES&langId=en_US&pagename=authenticate#autopay",
            "costco": "/RSnextgen/svc/launch/index.action?siteId=PLCN_COSTCO&langId=en_US&pagename=authenticate#autopay",
            "home furnishings": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HOME&langId=en_US&pagename=authenticate#autopay",
            "consumer electronics and appliances": "/RSnextgen/svc/launch/index.action?siteId=PLCN_ELECAPPL&langId=en_US&pagename=authenticate#autopay",
            "llbean": "/RSnextgen/svc/launch/index.action?siteId=PLCN_LLBEAN&langId=en_US&pagename=authenticate#autopay",
            "cat": "/RSnextgen/svc/launch/index.action?siteId=PLCN_CAT&langId=en_US&pagename=authenticate#autopay",
            "meijer": "/RSnextgen/svc/launch/index.action?siteId=PLCN_meijer&langId=en_US&pagename=authenticate#autopay"
        },
        commercial: {
            crc: {
                toro: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_TORO#paym/setautopay",
                cnhi: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_CNHI#paym/setautopay",
                "tractor supply": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_TRACTORSUPPLY#paym/setautopay",
                thd: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_HOMEDEPOT#paym/setautopay",
                staples: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_STAPLES#paym/setautopay",
                "honda power equipment": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_HNPE#paym/setautopay",
                cat: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_Cat#paym/setautopay",
                "office depot": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_OFFICEDEPOT#paym/setautopay"
            },
            /* prox:{

                thd : "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_HOMEDEPOT#paym/setautopay",

                staples : "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_Staples#paym/setautopay",

                cat : "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_CAT#paym/setautopay",

                "office depot"  : "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_Officedepot#paym/setautopay"

            }, */
            fleet: {
                exxon: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLOF_EXXONMOBIL#paym/setautopay",
                sunoco: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLOF_SUNOCO#paym/setautopay"
            }
        }
    },
    PaymentSrc: {
        consumer: {
            "sears": "/RSnextgen/svc/launch/index.action?langId=en_US&siteId=SEARS&pagename=authenticate#addpaymentsrc",
            "shop your way": "/RSnextgen/svc/launch/index.action?langId=en_US&siteId=PLCN_SYW&pagename=authenticate#addpaymentsrc",
            "thd": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HOMEDEPOT&langId=en_US&pagename=authenticate#addpaymentsrc",
            "best buy": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BESTBUY&langId=en_US&pagename=authenticate#addpaymentsrc",
            "good year": "/RSnextgen/svc/launch/index.action?siteId=PLCN_GOODYEAR&langId=en_US&pagename=authenticate#addpaymentsrc",
            "brooks brothers": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BROOKSBROTHERS&langId=en_US&pagename=authenticate#addpaymentsrc",
            "ford": "/RSnextgen/svc/launch/index.action?siteId=PLCN_SERVICE&langId=en_US&pagename=authenticate#addpaymentsrc",
            "quick lane": "/RSnextgen/svc/launch/index.action?siteId=PLCN_SERVICE&langId=en_US&pagename=authenticate#addpaymentsrc",
            "lincoln": "/RSnextgen/svc/launch/index.action?siteId=PLCN_LINCOLNSERVICES&langId=en_US&pagename=authenticate#addpaymentsrc",
            "shell": "/RSnextgen/svc/launch/index.action?siteId=PLOC_SHELL&langId=en_US&pagename=authenticate#addpaymentsrc",
            "sunoco": "/RSnextgen/svc/launch/index.action?siteId=PLOC_SUNOCO&langId=en_US&pagename=authenticate#addpaymentsrc",
            "exxonmobil": "/RSnextgen/svc/launch/index.action?siteId=PLOC_EXXONMOBIL&langId=en_US&pagename=authenticate#addpaymentsrc",
            "american airlines": "/RSnextgen/svc/launch/index.action?siteId=PLCN_AMERICAN&langId=en_US&pagename=authenticate#addpaymentsrc",
            "brand source": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BRANDSOURCE&langId=en_US&pagename=authenticate#addpaymentsrc",
            "tractor supply": "/RSnextgen/svc/launch/index.action?siteId=PLCN_TRACTORSUPPLY&langId=en_US&pagename=authenticate#addpaymentsrc",
            "ross simons-sidney thomas": "/RSnextgen/svc/launch/index.action?siteId=PLCN_JEWELRY&langId=en_US&pagename=authenticate#addpaymentsrc",
            "jewelers reserve": "/RSnextgen/svc/launch/index.action?siteId=PLCN_JEWELRY&langId=en_US&pagename=authenticate#addpaymentsrc",
            "staples": "/RSnextgen/svc/launch/index.action?siteId=PLCN_STAPLES&langId=en_US&pagename=authenticate#addpaymentsrc",
            "office depot": "/RSnextgen/svc/launch/index.action?siteId=PLCN_OFFICEDEPOT&langId=en_US&pagename=authenticate#addpaymentsrc",
            "wawa": "/RSnextgen/svc/launch/index.action?siteId=PLOC_WAWA&langId=en_US&pagename=authenticate#addpaymentsrc",
            "volkswagen drive card": "/RSnextgen/svc/launch/index.action?siteId=PLCN_DRIVECARD&langId=en_US&pagename=authenticate#addpaymentsrc",
            "service central": "/RSnextgen/svc/launch/index.action?siteId=PLCN_SERVICECENTRAL&langId=en_US&pagename=authenticate#addpaymentsrc",
            "brp": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BRP&langId=en_US&pagename=authenticate#addpaymentsrc",
            "toro": "/RSnextgen/svc/launch/index.action?siteId=PLCN_TORO&langId=en_US&pagename=authenticate#addpaymentsrc",
            "honda power equipment": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HNPE&langId=en_US&pagename=authenticate#addpaymentsrc",
            "kawasaki": "/RSnextgen/svc/launch/index.action?siteId=PLCN_KAWA&langId=en_US&pagename=authenticate#addpaymentsrc",
            "honda power sports": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HNPS&langId=en_US&pagename=authenticate#addpaymentsrc",
            "macys": "/RSnextgen/svc/launch/index.action?siteId=PLCN_MACYS&langId=en_US&pagename=authenticate#addpaymentsrc",
            "bloomingdales": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BLOOMINGDALES&langId=en_US&pagename=authenticate#addpaymentsrc",
            "costco": "/RSnextgen/svc/launch/index.action?siteId=PLCN_COSTCO&langId=en_US&pagename=authenticate#addpaymentsrc",
            "home furnishings": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HOME&langId=en_US&pagename=authenticate#addpaymentsrc",
            "consumer electronics and appliances": "/RSnextgen/svc/launch/index.action?siteId=PLCN_ELECAPPL&langId=en_US&pagename=authenticate#addpaymentsrc",
            "llbean": "/RSnextgen/svc/launch/index.action?siteId=PLCN_LLBEAN&langId=en_US&pagename=authenticate#addpaymentsrc",
            "cat": "/RSnextgen/svc/launch/index.action?siteId=PLCN_CAT&langId=en_US&pagename=authenticate#addpaymentsrc",
            "meijer": "/RSnextgen/svc/launch/index.action?siteId=PLCN_meijer&langId=en_US&pagename=authenticate#addpaymentsrc"
        },
        commercial: {
            crc: {
                toro: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_TORO#paym/addpymntsrc",
                cnhi: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_CNHI#paym/addpymntsrc",
                "tractor supply": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_TRACTORSUPPLY#paym/addpymntsrc",
                thd: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_HOMEDEPOT#paym/addpymntsrc",
                staples: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_STAPLES#paym/addpymntsrc",
                "honda power equipment": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_HNPE#paym/addpymntsrc",
                cat: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_Cat#paym/addpymntsrc",
                "office depot": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_OFFICEDEPOT#paym/addpymntsrc"
            },
            prox: {
                thd: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_HOMEDEPOT#paym/addpymntsrc",
                staples: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_Staples#paym/addpymntsrc",
                cat: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_CAT#paym/addpymntsrc",
                "office depot": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_Officedepot#paym/addpymntsrc"
            },
            fleet: {
                exxon: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLOF_EXXONMOBIL#paym/addpymntsrc",
                sunoco: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLOF_SUNOCO#paym/addpymntsrc"
            }
        }
    },
    manageaccount: {
        consumer: {
            "sears": "/RSnextgen/svc/launch/index.action?langId=en_US&siteId=SEARS&pagename=authenticate#manageaccount",
            "shop your way": "/RSnextgen/svc/launch/index.action?langId=en_US&siteId=PLCN_SYW&pagename=authenticate#manageaccount",
            "thd": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HOMEDEPOT&langId=en_US&pagename=authenticate#manageaccount",
            "best buy": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BESTBUY&langId=en_US&pagename=authenticate#manageaccount",
            "good year": "/RSnextgen/svc/launch/index.action?siteId=PLCN_GOODYEAR&langId=en_US&pagename=authenticate#manageaccount",
            "brooks brothers": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BROOKSBROTHERS&langId=en_US&pagename=authenticate#manageaccount",
            "ford": "/RSnextgen/svc/launch/index.action?siteId=PLCN_SERVICE&langId=en_US&pagename=authenticate#manageaccount",
            "quick lane": "/RSnextgen/svc/launch/index.action?siteId=PLCN_SERVICE&langId=en_US&pagename=authenticate#manageaccount",
            "lincoln": "/RSnextgen/svc/launch/index.action?siteId=PLCN_LINCOLNSERVICES&langId=en_US&pagename=authenticate#manageaccount",
            "shell": "/RSnextgen/svc/launch/index.action?siteId=PLOC_SHELL&langId=en_US&pagename=authenticate#manageaccount",
            "sunoco": "/RSnextgen/svc/launch/index.action?siteId=PLOC_SUNOCO&langId=en_US&pagename=authenticate#manageaccount",
            "exxonmobil": "/RSnextgen/svc/launch/index.action?siteId=PLOC_EXXONMOBIL&langId=en_US&pagename=authenticate#manageaccount",
            "american airlines": "/RSnextgen/svc/launch/index.action?siteId=PLCN_AMERICAN&langId=en_US&pagename=authenticate#manageaccount",
            "brand source": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BRANDSOURCE&langId=en_US&pagename=authenticate#manageaccount",
            "tractor supply": "/RSnextgen/svc/launch/index.action?siteId=PLCN_TRACTORSUPPLY&langId=en_US&pagename=authenticate#manageaccount",
            "ross simons-sidney thomas": "/RSnextgen/svc/launch/index.action?siteId=PLCN_JEWELRY&langId=en_US&pagename=authenticate#manageaccount",
            "jewelers reserve": "/RSnextgen/svc/launch/index.action?siteId=PLCN_JEWELRY&langId=en_US&pagename=authenticate#manageaccount",
            "staples": "/RSnextgen/svc/launch/index.action?siteId=PLCN_STAPLES&langId=en_US&pagename=authenticate#manageaccount",
            "office depot": "/RSnextgen/svc/launch/index.action?siteId=PLCN_OFFICEDEPOT&langId=en_US&pagename=authenticate#manageaccount",
            "wawa": "/RSnextgen/svc/launch/index.action?siteId=PLOC_WAWA&langId=en_US&pagename=authenticate#manageaccount",
            "volkswagen drive card": "/RSnextgen/svc/launch/index.action?siteId=PLCN_DRIVECARD&langId=en_US&pagename=authenticate#manageaccount",
            "service central": "/RSnextgen/svc/launch/index.action?siteId=PLCN_SERVICECENTRAL&langId=en_US&pagename=authenticate#manageaccount",
            "brp": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BRP&langId=en_US&pagename=authenticate#manageaccount",
            "toro": "/RSnextgen/svc/launch/index.action?siteId=PLCN_TORO&langId=en_US&pagename=authenticate#manageaccount",
            "honda power equipment": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HNPE&langId=en_US&pagename=authenticate#manageaccount",
            "kawasaki": "/RSnextgen/svc/launch/index.action?siteId=PLCN_KAWA&langId=en_US&pagename=authenticate#manageaccount",
            "honda power sports": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HNPS&langId=en_US&pagename=authenticate#manageaccount",
            "macys": "/RSnextgen/svc/launch/index.action?siteId=PLCN_MACYS&langId=en_US&pagename=authenticate#manageaccount",
            "bloomingdales": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BLOOMINGDALES&langId=en_US&pagename=authenticate#manageaccount",
            "costco": "/RSnextgen/svc/launch/index.action?siteId=PLCN_COSTCO&langId=en_US&pagename=authenticate#manageaccount",
            "home furnishings": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HOME&langId=en_US&pagename=authenticate#manageaccount",
            "consumer electronics and appliances": "/RSnextgen/svc/launch/index.action?siteId=PLCN_ELECAPPL&langId=en_US&pagename=authenticate#manageaccount",
            "llbean": "/RSnextgen/svc/launch/index.action?siteId=PLCN_LLBEAN&langId=en_US&pagename=authenticate#manageaccount",
            "cat": "/RSnextgen/svc/launch/index.action?siteId=PLCN_CAT&langId=en_US&pagename=authenticate#manageaccount",
            "meijer": "/RSnextgen/svc/launch/index.action?siteId=PLCN_meijer&langId=en_US&pagename=authenticate#manageaccount"
        },
        commercial: {
            crc: {
                toro: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_TORO#pro/manageacct",
                cnhi: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_CNHI#pro/manageacct",
                "tractor supply": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_TRACTORSUPPLY#pro/manageacct",
                thd: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_HOMEDEPOT#pro/manageacct",
                staples: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_STAPLES#pro/manageacct",
                "honda power equipment": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_HNPE#pro/manageacct",
                cat: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_Cat#pro/manageacct",
                "office depot": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_OFFICEDEPOT#pro/manageacct"
            },
            prox: {
                thd: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_HOMEDEPOT#pro/manageacct",
                staples: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_Staples#pro/manageacct",
                cat: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_CAT#pro/manageacct",
                "office depot": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_Officedepot#pro/manageacct"
            },
            fleet: {
                exxon: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLOF_EXXONMOBIL#pro/manageacct",
                sunoco: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLOF_SUNOCO#pro/manageacct"
            }
        }
    },
    alert: {
        consumer: {
            "sears": "/RSnextgen/svc/launch/index.action?langId=en_US&siteId=SEARS&pagename=authenticate#citialert",
            "shop your way": "/RSnextgen/svc/launch/index.action?langId=en_US&siteId=PLCN_SYW&pagename=authenticate#citialert",
            "thd": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HOMEDEPOT&langId=en_US&pagename=authenticate#citialert",
            "best buy": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BESTBUY&langId=en_US&pagename=authenticate#citialert",
            "good year": "/RSnextgen/svc/launch/index.action?siteId=PLCN_GOODYEAR&langId=en_US&pagename=authenticate#citialert",
            "brooks brothers": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BROOKSBROTHERS&langId=en_US&pagename=authenticate#citialert",
            "ford": "/RSnextgen/svc/launch/index.action?siteId=PLCN_SERVICE&langId=en_US&pagename=authenticate#citialert",
            "quick lane": "/RSnextgen/svc/launch/index.action?siteId=PLCN_SERVICE&langId=en_US&pagename=authenticate#citialert",
            "lincoln": "/RSnextgen/svc/launch/index.action?siteId=PLCN_LINCOLNSERVICES&langId=en_US&pagename=authenticate#citialert",
            "shell": "/RSnextgen/svc/launch/index.action?siteId=PLOC_SHELL&langId=en_US&pagename=authenticate#citialert",
            "sunoco": "/RSnextgen/svc/launch/index.action?siteId=PLOC_SUNOCO&langId=en_US&pagename=authenticate#citialert",
            "exxonmobil": "/RSnextgen/svc/launch/index.action?siteId=PLOC_EXXONMOBIL&langId=en_US&pagename=authenticate#citialert",
            "american airlines": "/RSnextgen/svc/launch/index.action?siteId=PLCN_AMERICAN&langId=en_US&pagename=authenticate#citialert",
            "brand source": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BRANDSOURCE&langId=en_US&pagename=authenticate#citialert",
            "tractor supply": "/RSnextgen/svc/launch/index.action?siteId=PLCN_TRACTORSUPPLY&langId=en_US&pagename=authenticate#citialert",
            "ross simons-sidney thomas": "/RSnextgen/svc/launch/index.action?siteId=PLCN_JEWELRY&langId=en_US&pagename=authenticate#citialert",
            "jewelers reserve": "/RSnextgen/svc/launch/index.action?siteId=PLCN_JEWELRY&langId=en_US&pagename=authenticate#citialert",
            "staples": "/RSnextgen/svc/launch/index.action?siteId=PLCN_STAPLES&langId=en_US&pagename=authenticate#citialert",
            "office depot": "/RSnextgen/svc/launch/index.action?siteId=PLCN_OFFICEDEPOT&langId=en_US&pagename=authenticate#citialert",
            "wawa": "/RSnextgen/svc/launch/index.action?siteId=PLOC_WAWA&langId=en_US&pagename=authenticate#citialert",
            "volkswagen drive card": "/RSnextgen/svc/launch/index.action?siteId=PLCN_DRIVECARD&langId=en_US&pagename=authenticate#citialert",
            "service central": "/RSnextgen/svc/launch/index.action?siteId=PLCN_SERVICECENTRAL&langId=en_US&pagename=authenticate#citialert",
            "brp": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BRP&langId=en_US&pagename=authenticate#citialert",
            "toro": "/RSnextgen/svc/launch/index.action?siteId=PLCN_TORO&langId=en_US&pagename=authenticate#citialert",
            "honda power equipment": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HNPE&langId=en_US&pagename=authenticate#citialert",
            "kawasaki": "/RSnextgen/svc/launch/index.action?siteId=PLCN_KAWA&langId=en_US&pagename=authenticate#citialert",
            "honda power sports": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HNPS&langId=en_US&pagename=authenticate#citialert",
            "macys": "/RSnextgen/svc/launch/index.action?siteId=PLCN_MACYS&langId=en_US&pagename=authenticate#citialert",
            "bloomingdales": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BLOOMINGDALES&langId=en_US&pagename=authenticate#citialert",
            "costco": "/RSnextgen/svc/launch/index.action?siteId=PLCN_COSTCO&langId=en_US&pagename=authenticate#citialert",
            "home furnishings": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HOME&langId=en_US&pagename=authenticate#citialert",
            "consumer electronics and appliances": "/RSnextgen/svc/launch/index.action?siteId=PLCN_ELECAPPL&langId=en_US&pagename=authenticate#citialert",
            "llbean": "/RSnextgen/svc/launch/index.action?siteId=PLCN_LLBEAN&langId=en_US&pagename=authenticate#citialert",
            "cat": "/RSnextgen/svc/launch/index.action?siteId=PLCN_CAT&langId=en_US&pagename=authenticate#citialert",
            "meijer": "/RSnextgen/svc/launch/index.action?siteId=PLCN_meijer&langId=en_US&pagename=authenticate#citialert"
        },
        commercial: {
            crc: {
                toro: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_TORO#pro/managealert",
                cnhi: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_CNHI#pro/managealert",
                "tractor supply": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_TRACTORSUPPLY#pro/managealert",
                thd: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_HOMEDEPOT#pro/managealert",
                staples: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_STAPLES#pro/managealert",
                "honda power equipment": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_HNPE#pro/managealert",
                cat: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_Cat#pro/managealert",
                "office depot": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_OFFICEDEPOT#pro/managealert"
            },
            prox: {
                thd: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_HOMEDEPOT#pro/managealert",
                staples: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_Staples#pro/managealert",
                cat: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_CAT#pro/managealert",
                "office depot": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_Officedepot#pro/managealert"
            },
            fleet: {
                exxon: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLOF_EXXONMOBIL#pro/managealert",
                sunoco: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLOF_SUNOCO#pro/managealert"
            }
        }
    },
    makePaymentOptions: {
        consumer: {
            "sears": "/RSnextgen/svc/launch/index.action?langId=en_US&siteId=SEARS&pagename=authenticate#makepaymentoptions",
            "shop your way": "/RSnextgen/svc/launch/index.action?langId=en_US&siteId=PLCN_SYW&pagename=authenticate#makepaymentoptions",
            "thd": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HOMEDEPOT&langId=en_US&pagename=authenticate#makepaymentoptions",
            "best buy": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BESTBUY&langId=en_US&pagename=authenticate#makepaymentoptions",
            "good year": "/RSnextgen/svc/launch/index.action?siteId=PLCN_GOODYEAR&langId=en_US&pagename=authenticate#makepaymentoptions",
            "brooks brothers": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BROOKSBROTHERS&langId=en_US&pagename=authenticate#makepaymentoptions",
            "ford": "/RSnextgen/svc/launch/index.action?siteId=PLCN_SERVICE&langId=en_US&pagename=authenticate#makepaymentoptions",
            "quick lane": "/RSnextgen/svc/launch/index.action?siteId=PLCN_SERVICE&langId=en_US&pagename=authenticate#makepaymentoptions",
            "lincoln": "/RSnextgen/svc/launch/index.action?siteId=PLCN_LINCOLNSERVICES&langId=en_US&pagename=authenticate#makepaymentoptions",
            "shell": "/RSnextgen/svc/launch/index.action?siteId=PLOC_SHELL&langId=en_US&pagename=authenticate#makepaymentoptions",
            "sunoco": "/RSnextgen/svc/launch/index.action?siteId=PLOC_SUNOCO&langId=en_US&pagename=authenticate#makepaymentoptions",
            "exxonmobil": "/RSnextgen/svc/launch/index.action?siteId=PLOC_EXXONMOBIL&langId=en_US&pagename=authenticate#makepaymentoptions",
            "american airlines": "/RSnextgen/svc/launch/index.action?siteId=PLCN_AMERICAN&langId=en_US&pagename=authenticate#makepaymentoptions",
            "brand source": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BRANDSOURCE&langId=en_US&pagename=authenticate#makepaymentoptions",
            "tractor supply": "/RSnextgen/svc/launch/index.action?siteId=PLCN_TRACTORSUPPLY&langId=en_US&pagename=authenticate#makepaymentoptions",
            "ross simons-sidney thomas": "/RSnextgen/svc/launch/index.action?siteId=PLCN_JEWELRY&langId=en_US&pagename=authenticate#makepaymentoptions",
            "jewelers reserve": "/RSnextgen/svc/launch/index.action?siteId=PLCN_JEWELRY&langId=en_US&pagename=authenticate#makepaymentoptions",
            "staples": "/RSnextgen/svc/launch/index.action?siteId=PLCN_STAPLES&langId=en_US&pagename=authenticate#makepaymentoptions",
            "office depot": "/RSnextgen/svc/launch/index.action?siteId=PLCN_OFFICEDEPOT&langId=en_US&pagename=authenticate#makepaymentoptions",
            "wawa": "/RSnextgen/svc/launch/index.action?siteId=PLOC_WAWA&langId=en_US&pagename=authenticate#makepaymentoptions",
            "volkswagen drive card": "/RSnextgen/svc/launch/index.action?siteId=PLCN_DRIVECARD&langId=en_US&pagename=authenticate#makepaymentoptions",
            "service central": "/RSnextgen/svc/launch/index.action?siteId=PLCN_SERVICECENTRAL&langId=en_US&pagename=authenticate#makepaymentoptions",
            "brp": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BRP&langId=en_US&pagename=authenticate#makepaymentoptions",
            "toro": "/RSnextgen/svc/launch/index.action?siteId=PLCN_TORO&langId=en_US&pagename=authenticate#makepaymentoptions",
            "honda power equipment": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HNPE&langId=en_US&pagename=authenticate#makepaymentoptions",
            "kawasaki": "/RSnextgen/svc/launch/index.action?siteId=PLCN_KAWA&langId=en_US&pagename=authenticate#makepaymentoptions",
            "honda power sports": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HNPS&langId=en_US&pagename=authenticate#makepaymentoptions",
            "macys": "/RSnextgen/svc/launch/index.action?siteId=PLCN_MACYS&langId=en_US&pagename=authenticate#makepaymentoptions",
            "bloomingdales": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BLOOMINGDALES&langId=en_US&pagename=authenticate#makepaymentoptions",
            "costco": "/RSnextgen/svc/launch/index.action?siteId=PLCN_COSTCO&langId=en_US&pagename=authenticate#makepaymentoptions",
            "home furnishings": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HOME&langId=en_US&pagename=authenticate#makepaymentoptions",
            "consumer electronics and appliances": "/RSnextgen/svc/launch/index.action?siteId=PLCN_ELECAPPL&langId=en_US&pagename=authenticate#makepaymentoptions",
            "llbean": "/RSnextgen/svc/launch/index.action?siteId=PLCN_LLBEAN&langId=en_US&pagename=authenticate#makepaymentoptions",
            "cat": "/RSnextgen/svc/launch/index.action?siteId=PLCN_CAT&langId=en_US&pagename=authenticate#makepaymentoptions",
            "meijer": "/RSnextgen/svc/launch/index.action?siteId=PLCN_meijer&langId=en_US&pagename=authenticate#makepaymentoptions"
        },
        commercial: {
            crc: {},
            prox: {},
            fleet: {}
        }
    },
    SignOn: {
        consumer: {
            "sears": "/RSnextgen/svc/launch/index.action?langId=en_US&siteId=SEARS#signon",
            "shop your way": "/RSnextgen/svc/launch/index.action?langId=en_US&siteId=PLCN_SYW#signon",
            "thd": "/RSnextgen/svc/launch/index.action?langId=en_US&siteId=PLCN_HOMEDEPOT#signon",
            "best buy": "/RSnextgen/svc/launch/index.action?langId=en_US&siteId=PLCN_BESTBUY#signon",
            "good year": "/RSnextgen/svc/launch/index.action?langId=en_US&siteId=PLCN_GOODYEAR#signon",
            "brooks brothers": "/RSnextgen/svc/launch/index.action?langId=en_US&siteId=PLCN_BROOKSBROTHERS#signon",
            "ford": "/RSnextgen/svc/launch/index.action?langId=en_US&siteId=PLCN_SERVICE#signon",
            "quick lane": "/RSnextgen/svc/launch/index.action?langId=en_US&siteId=PLCN_SERVICE#signon",
            "lincoln": "/RSnextgen/svc/launch/index.action?langId=en_US&siteId=PLCN_LINCOLNSERVICES#signon",
            "shell": "/RSnextgen/svc/launch/index.action?langId=en_US&siteId=PLOC_SHELL#signon",
            "sunoco": "/RSnextgen/svc/launch/index.action?langId=en_US&siteId=PLOC_SUNOCO#signon",
            "exxonmobil": "/RSnextgen/svc/launch/index.action?langId=en_US&siteId=PLOC_EXXONMOBIL#signon",
            "american airlines": "/RSnextgen/svc/launch/index.action?langId=en_US&siteId=PLCN_AMERICAN#signon",
            "brand source": "/RSnextgen/svc/launch/index.action?langId=en_US&siteId=PLCN_BRANDSOURCE#signon",
            "tractor supply": "/RSnextgen/svc/launch/index.action?langId=en_US&siteId=PLCN_TRACTORSUPPLY#signon",
            "ross simons-sidney thomas": "/RSnextgen/svc/launch/index.action?langId=en_US&siteId=PLCN_JEWELRY#signon",
            "jewelers reserve": "/RSnextgen/svc/launch/index.action?langId=en_US&siteId=PLCN_JEWELRY#signon",
            "staples": "/RSnextgen/svc/launch/index.action?langId=en_US&siteId=PLCN_STAPLES#signon",
            "office depot": "/RSnextgen/svc/launch/index.action?langId=en_US&siteId=PLCN_OFFICEDEPOT#signon",
            "wawa": "/RSnextgen/svc/launch/index.action?langId=en_US&siteId=PLOC_WAWA#signon",
            "volkswagen drive card": "/RSnextgen/svc/launch/index.action?langId=en_US&siteId=PLCN_DRIVECARD#signon",
            "service central": "/RSnextgen/svc/launch/index.action?langId=en_US&siteId=PLCN_SERVICECENTRAL#signon",
            "brp": "/RSnextgen/svc/launch/index.action?langId=en_US&siteId=PLCN_BRP#signon",
            "toro": "/RSnextgen/svc/launch/index.action?langId=en_US&siteId=PLCN_TORO#signon",
            "honda power equipment": "/RSnextgen/svc/launch/index.action?langId=en_US&siteId=PLCN_HNPE#signon",
            "kawasaki": "/RSnextgen/svc/launch/index.action?langId=en_US&siteId=PLCN_KAWA#signon",
            "honda power sports": "/RSnextgen/svc/launch/index.action?langId=en_US&siteId=PLCN_HNPS#signon",
            "macys": "/RSnextgen/svc/launch/index.action?siteId=PLCN_MACYS&langId=en_US&pagename=authenticate#dashboard",
            "bloomingdales": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BLOOMINGDALES&langId=en_US&pagename=authenticate#dashboard",
            "costco": "/RSnextgen/svc/launch/index.action?langId=en_US&siteId=PLCN_COSTCO#signon",
            "home furnishings": "/RSnextgen/svc/launch/index.action?langId=en_US&siteId=PLCN_HOME#signon",
            "consumer electronics and appliances": "/RSnextgen/svc/launch/index.action?langId=en_US&siteId=PLCN_ELECAPPL#signon",
            "llbean": "/RSnextgen/svc/launch/index.action?langId=en_US&siteId=PLCN_LLBEAN#signon",
            "cat": "/RSnextgen/svc/launch/index.action?langId=en_US&siteId=PLCN_CAT#signon",
            "meijer": "/RSnextgen/svc/launch/index.action?siteId=PLCN_meijer#signon"
        },
        commercial: {
            crc: {
                toro: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_TORO#SignOn",
                cnhi: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_CNHI#SignOn",
                "tractor supply": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_TRACTORSUPPLY",
                thd: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_HOMEDEPOT#SignOn",
                staples: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_STAPLES",
                "honda power equipment": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_HNPE#SignOn",
                cat: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_Cat#SignOn",
                "office depot": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_OFFICEDEPOT#SignOn"
            },
            prox: {
                thd: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_HOMEDEPOT#SignOn",
                staples: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_Staples#SignOn",
                cat: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_CAT#SignOn",
                "office depot": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_Officedepot#SignOn"
            },
            fleet: {
                exxon: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLOF_EXXONMOBIL",
                sunoco: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLOF_SUNOCO"
            }
        }
    },
    ResetPwd: {
        consumer: {
            "sears": "/RSnextgen/svc/launch/index.action?siteId=SEARS&langId=en_US&pagename=signon#reset",
            "shop your way": "/RSnextgen/svc/launch/index.action?siteId=PLCN_SYW&langId=en_US&pagename=signon#reset",
            "thd": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HOMEDEPOT&langId=en_US&pagename=signon#reset",
            "best buy": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BESTBUY&langId=en_US&pagename=signon#reset",
            "good year": "/RSnextgen/svc/launch/index.action?siteId=PLCN_GOODYEAR&langId=en_US&pagename=signon#reset",
            "brooks brothers": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BROOKSBROTHERS&langId=en_US&pagename=signon#reset",
            "ford": "/RSnextgen/svc/launch/index.action?siteId=PLCN_SERVICE&langId=en_US&pagename=signon#reset",
            "quick lane": "/RSnextgen/svc/launch/index.action?siteId=PLCN_SERVICE&langId=en_US&pagename=signon#reset",
            "lincoln": "/RSnextgen/svc/launch/index.action?siteId=PLCN_LINCOLNSERVICES&langId=en_US&pagename=signon#reset",
            "shell": "/RSnextgen/svc/launch/index.action?siteId=PLOC_SHELL&langId=en_US&pagename=signon#reset",
            "sunoco": "/RSnextgen/svc/launch/index.action?siteId=PLOC_SUNOCO&langId=en_US&pagename=signon#reset",
            "exxonmobil": "/RSnextgen/svc/launch/index.action?siteId=PLOC_EXXONMOBIL&langId=en_US&pagename=signon#reset",
            "american airlines": "/RSnextgen/svc/launch/index.action?siteId=PLCN_AMERICAN&langId=en_US&pagename=signon#reset",
            "brand source": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BRANDSOURCE&langId=en_US&pagename=signon#reset",
            "tractor supply": "/RSnextgen/svc/launch/index.action?siteId=PLCN_TRACTORSUPPLY&langId=en_US&pagename=signon#reset",
            "ross simons-sidney thomas": "/RSnextgen/svc/launch/index.action?siteId=PLCN_JEWELRY&langId=en_US&pagename=signon#reset",
            "jewelers reserve": "/RSnextgen/svc/launch/index.action?siteId=PLCN_JEWELRY&langId=en_US&pagename=signon#reset",
            "staples": "/RSnextgen/svc/launch/index.action?siteId=PLCN_STAPLES&langId=en_US&pagename=signon#reset",
            "office depot": "/RSnextgen/svc/launch/index.action?siteId=PLCN_OFFICEDEPOT&langId=en_US&pagename=signon#reset",
            "wawa": "/RSnextgen/svc/launch/index.action?siteId=PLOC_WAWA&langId=en_US&pagename=signon#reset",
            "volkswagen drive card": "/RSnextgen/svc/launch/index.action?siteId=PLCN_DRIVECARD&langId=en_US&pagename=signon#reset",
            "service central": "/RSnextgen/svc/launch/index.action?siteId=PLCN_SERVICECENTRAL&langId=en_US&pagename=signon#reset",
            "brp": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BRP&langId=en_US&pagename=signon#reset",
            "toro": "/RSnextgen/svc/launch/index.action?siteId=PLCN_TORO&langId=en_US&pagename=signon#reset",
            "honda power equipment": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HNPE&langId=en_US&pagename=signon#reset",
            "kawasaki": "/RSnextgen/svc/launch/index.action?siteId=PLCN_KAWA&langId=en_US&pagename=signon#reset",
            "honda power sports": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HNPS&langId=en_US&pagename=signon#reset",
            "macys": "/RSnextgen/svc/launch/index.action?siteId=PLCN_MACYS&langId=en_US&pagename=authenticate#reset",
            "bloomingdales": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BLOOMINGDALES&langId=en_US&pagename=authenticate#reset",
            "costco": "/RSnextgen/svc/launch/index.action?siteId=PLCN_COSTCO&langId=en_US&pagename=signon#reset",
            "home furnishings": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HOME&langId=en_US&pagename=signon#reset",
            "consumer electronics and appliances": "/RSnextgen/svc/launch/index.action?siteId=PLCN_ELECAPPL&langId=en_US&pagename=signon#reset",
            "llbean": "/RSnextgen/svc/launch/index.action?siteId=PLCN_LLBEAN&langId=en_US&pagename=signon#reset",
            "cat": "/RSnextgen/svc/launch/index.action?siteId=PLCN_CAT&langId=en_US&pagename=signon#reset",
            "meijer": "/RSnextgen/svc/launch/index.action?siteId=PLCN_meijer&langId=en_US&pagename=signon#reset"
        },
        commercial: {
            crc: {
                toro: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_TORO#pro/retpwd",
                cnhi: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_CNHI#pro/retpwd",
                "tractor supply": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_TRACTORSUPPLY#pro/retpwd",
                thd: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_HOMEDEPOT#pro/retpwd",
                staples: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_STAPLES#pro/retpwd",
                "honda power equipment": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_HNPE#pro/retpwd",
                cat: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_Cat#pro/retpwd",
                "office depot": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_OFFICEDEPOT#pro/retpwd"
            },
            prox: {
                thd: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_HOMEDEPOT#pro/retpwd",
                staples: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_Staples#pro/retpwd",
                cat: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_CAT#pro/retpwd",
                "office depot": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_Officedepot#pro/retpwd"
            },
            fleet: {
                exxon: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLOF_EXXONMOBIL#pro/retpwd",
                sunoco: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLOF_SUNOCO#pro/retpwd"
            }
        }
    },
    profile: {
        consumer: {
            "sears": "/RSnextgen/svc/launch/index.action?langId=en_US&siteId=SEARS&pagename=authenticate#profile",
            "shop your way": "/RSnextgen/svc/launch/index.action?langId=en_US&siteId=PLCN_SYW&pagename=authenticate#profile",
            "thd": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HOMEDEPOT&langId=en_US&pagename=authenticate#profile",
            "best buy": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BESTBUY&langId=en_US&pagename=authenticate#profile",
            "good year": "/RSnextgen/svc/launch/index.action?siteId=PLCN_GOODYEAR&langId=en_US&pagename=authenticate#profile",
            "brooks brothers": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BROOKSBROTHERS&langId=en_US&pagename=authenticate#profile",
            "ford": "/RSnextgen/svc/launch/index.action?siteId=PLCN_SERVICE&langId=en_US&pagename=authenticate#profile",
            "quick lane": "/RSnextgen/svc/launch/index.action?siteId=PLCN_SERVICE&langId=en_US&pagename=authenticate#profile",
            "lincoln": "/RSnextgen/svc/launch/index.action?siteId=PLCN_LINCOLNSERVICES&langId=en_US&pagename=authenticate#profile",
            "shell": "/RSnextgen/svc/launch/index.action?siteId=PLOC_SHELL&langId=en_US&pagename=authenticate#profile",
            "sunoco": "/RSnextgen/svc/launch/index.action?siteId=PLOC_SUNOCO&langId=en_US&pagename=authenticate#profile",
            "exxonmobil": "/RSnextgen/svc/launch/index.action?siteId=PLOC_EXXONMOBIL&langId=en_US&pagename=authenticate#profile",
            "american airlines": "/RSnextgen/svc/launch/index.action?siteId=PLCN_AMERICAN&langId=en_US&pagename=authenticate#profile",
            "brand source": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BRANDSOURCE&langId=en_US&pagename=authenticate#profile",
            "tractor supply": "/RSnextgen/svc/launch/index.action?siteId=PLCN_TRACTORSUPPLY&langId=en_US&pagename=authenticate#profile",
            "ross simons-sidney thomas": "/RSnextgen/svc/launch/index.action?siteId=PLCN_JEWELRY&langId=en_US&pagename=authenticate#profile",
            "jewelers reserve": "/RSnextgen/svc/launch/index.action?siteId=PLCN_JEWELRY&langId=en_US&pagename=authenticate#profile",
            "staples": "/RSnextgen/svc/launch/index.action?siteId=PLCN_STAPLES&langId=en_US&pagename=authenticate#profile",
            "office depot": "/RSnextgen/svc/launch/index.action?siteId=PLCN_OFFICEDEPOT&langId=en_US&pagename=authenticate#profile",
            "wawa": "/RSnextgen/svc/launch/index.action?siteId=PLOC_WAWA&langId=en_US&pagename=authenticate#profile",
            "volkswagen drive card": "/RSnextgen/svc/launch/index.action?siteId=PLCN_DRIVECARD&langId=en_US&pagename=authenticate#profile",
            "service central": "/RSnextgen/svc/launch/index.action?siteId=PLCN_SERVICECENTRAL&langId=en_US&pagename=authenticate#profile",
            "brp": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BRP&langId=en_US&pagename=authenticate#profile",
            "toro": "/RSnextgen/svc/launch/index.action?siteId=PLCN_TORO&langId=en_US&pagename=authenticate#profile",
            "honda power equipment": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HNPE&langId=en_US&pagename=authenticate#profile",
            "kawasaki": "/RSnextgen/svc/launch/index.action?siteId=PLCN_KAWA&langId=en_US&pagename=authenticate#profile",
            "honda power sports": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HNPS&langId=en_US&pagename=authenticate#profile",
            "macys": "/RSnextgen/svc/launch/index.action?siteId=PLCN_MACYS&langId=en_US&pagename=authenticate#profile",
            "bloomingdales": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BLOOMINGDALES&langId=en_US&pagename=authenticate#profile",
            "costco": "/RSnextgen/svc/launch/index.action?siteId=PLCN_COSTCO&langId=en_US&pagename=authenticate#profile",
            "home furnishings": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HOME&langId=en_US&pagename=authenticate#profile",
            "consumer electronics and appliances": "/RSnextgen/svc/launch/index.action?siteId=PLCN_ELECAPPL&langId=en_US&pagename=authenticate#profile",
            "llbean": "/RSnextgen/svc/launch/index.action?siteId=PLCN_LLBEAN&langId=en_US&pagename=authenticate#profile",
            "cat": "/RSnextgen/svc/launch/index.action?siteId=PLCN_CAT&langId=en_US&pagename=authenticate#profile",
            "meijer": "/RSnextgen/svc/launch/index.action?siteId=PLCN_meijer&langId=en_US&pagename=authenticate#profile"
        },
        commercial: {
            crc: {
                toro: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_TORO#pro/profile",
                cnhi: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_CNHI#pro/profile",
                "tractor supply": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_TRACTORSUPPLY#pro/profile",
                thd: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_HOMEDEPOT#pro/profile",
                staples: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_STAPLES#pro/profile",
                "honda power equipment": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_HNPE#pro/profile",
                cat: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_Cat#pro/profile",
                "office depot": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_OFFICEDEPOT#pro/profile"
            },
            prox: {
                thd: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_HOMEDEPOT#pro/profile",
                staples: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_Staples#pro/profile",
                cat: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_CAT#pro/profile",
                "office depot": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_Officedepot#pro/profile"
            },
            fleet: {
                exxon: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLOF_EXXONMOBIL#pro/profile",
                sunoco: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLOF_SUNOCO#pro/profile"
            }
        }
    },
    statements: {
        consumer: {
            "sears": "/RSnextgen/svc/launch/index.action?langId=en_US&siteId=SEARS&pagename=authenticate#statements",
            "shop your way": "/RSnextgen/svc/launch/index.action?langId=en_US&siteId=PLCN_SYW&pagename=authenticate#statements",
            "thd": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HOMEDEPOT&langId=en_US&pagename=authenticate#statements",
            "best buy": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BESTBUY&langId=en_US&pagename=authenticate#statements",
            "good year": "/RSnextgen/svc/launch/index.action?siteId=PLCN_GOODYEAR&langId=en_US&pagename=authenticate#statements",
            "brooks brothers": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BROOKSBROTHERS&langId=en_US&pagename=authenticate#statements",
            "ford": "/RSnextgen/svc/launch/index.action?siteId=PLCN_SERVICE&langId=en_US&pagename=authenticate#statements",
            "quick lane": "/RSnextgen/svc/launch/index.action?siteId=PLCN_SERVICE&langId=en_US&pagename=authenticate#statements",
            "lincoln": "/RSnextgen/svc/launch/index.action?siteId=PLCN_LINCOLNSERVICES&langId=en_US&pagename=authenticate#statements",
            "shell": "/RSnextgen/svc/launch/index.action?siteId=PLOC_SHELL&langId=en_US&pagename=authenticate#statements",
            "sunoco": "/RSnextgen/svc/launch/index.action?siteId=PLOC_SUNOCO&langId=en_US&pagename=authenticate#statements",
            "exxonmobil": "/RSnextgen/svc/launch/index.action?siteId=PLOC_EXXONMOBIL&langId=en_US&pagename=authenticate#statements",
            "american airlines": "/RSnextgen/svc/launch/index.action?siteId=PLCN_AMERICAN&langId=en_US&pagename=authenticate#statements",
            "brand source": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BRANDSOURCE&langId=en_US&pagename=authenticate#statements",
            "tractor supply": "/RSnextgen/svc/launch/index.action?siteId=PLCN_TRACTORSUPPLY&langId=en_US&pagename=authenticate#statements",
            "ross simons-sidney thomas": "/RSnextgen/svc/launch/index.action?siteId=PLCN_JEWELRY&langId=en_US&pagename=authenticate#statements",
            "jewelers reserve": "/RSnextgen/svc/launch/index.action?siteId=PLCN_JEWELRY&langId=en_US&pagename=authenticate#statements",
            "staples": "/RSnextgen/svc/launch/index.action?siteId=PLCN_STAPLES&langId=en_US&pagename=authenticate#statements",
            "office depot": "/RSnextgen/svc/launch/index.action?siteId=PLCN_OFFICEDEPOT&langId=en_US&pagename=authenticate#statements",
            "wawa": "/RSnextgen/svc/launch/index.action?siteId=PLOC_WAWA&langId=en_US&pagename=authenticate#statements",
            "volkswagen drive card": "/RSnextgen/svc/launch/index.action?siteId=PLCN_DRIVECARD&langId=en_US&pagename=authenticate#statements",
            "service central": "/RSnextgen/svc/launch/index.action?siteId=PLCN_SERVICECENTRAL&langId=en_US&pagename=authenticate#statements",
            "brp": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BRP&langId=en_US&pagename=authenticate#statements",
            "toro": "/RSnextgen/svc/launch/index.action?siteId=PLCN_TORO&langId=en_US&pagename=authenticate#statements",
            "honda power equipment": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HNPE&langId=en_US&pagename=authenticate#statements",
            "kawasaki": "/RSnextgen/svc/launch/index.action?siteId=PLCN_KAWA&langId=en_US&pagename=authenticate#statements",
            "honda power sports": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HNPS&langId=en_US&pagename=authenticate#statements",
            "macys": "/RSnextgen/svc/launch/index.action?siteId=PLCN_MACYS&langId=en_US&pagename=authenticate#statements",
            "bloomingdales": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BLOOMINGDALES&langId=en_US&pagename=authenticate#statements",
            "costco": "/RSnextgen/svc/launch/index.action?siteId=PLCN_COSTCO&langId=en_US&pagename=authenticate#statements",
            "home furnishings": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HOME&langId=en_US&pagename=authenticate#statements",
            "consumer electronics and appliances": "/RSnextgen/svc/launch/index.action?siteId=PLCN_ELECAPPL&langId=en_US&pagename=authenticate#statements",
            "llbean": "/RSnextgen/svc/launch/index.action?siteId=PLCN_LLBEAN&langId=en_US&pagename=authenticate#statements",
            "cat": "/RSnextgen/svc/launch/index.action?siteId=PLCN_CAT&langId=en_US&pagename=authenticate#statements",
            "meijer": "/RSnextgen/svc/launch/index.action?siteId=PLCN_meijer&langId=en_US&pagename=authenticate#statements"
        },
        commercial: {
            crc: {
                toro: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_TORO#stmt/statements",
                cnhi: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_CNHI#stmt/statements",
                "tractor supply": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_TRACTORSUPPLY#stmt/statements",
                thd: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_HOMEDEPOT#stmt/statements",
                staples: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_STAPLES#stmt/statements",
                "honda power equipment": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_HNPE#stmt/statements",
                cat: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_Cat#stmt/statements",
                "office depot": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_OFFICEDEPOT#stmt/statements"
            },
            prox: {
                thd: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_HOMEDEPOT#invprox/invoices",
                staples: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_Staples#invprox/invoices",
                cat: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_CAT#invprox/invoices",
                "office depot": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_Officedepot#invprox/invoices"
            },
            fleet: {
                exxon: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLOF_EXXONMOBIL#stmt/statements",
                sunoco: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLOF_SUNOCO#stmt/statements"
            }
        }
    },
    promoAllocation: {
        consumer: {
            "sears": "/RSnextgen/svc/launch/index.action?langId=en_US&siteId=SEARS&pagename=authenticate#promoAllocation",
            "shop your way": "/RSnextgen/svc/launch/index.action?langId=en_US&siteId=PLCN_SYW&pagename=authenticate#promoAllocation",
            "thd": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HOMEDEPOT&pagename=authenticate&langId=en_US#promoAllocation",
            "best buy": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BESTBUY&langId=en_US&pagename=authenticate#promoAllocation",
            "good year": "/RSnextgen/svc/launch/index.action?siteId=PLCN_GOODYEAR&langId=en_US&pagename=authenticate#promoAllocation",
            "brooks brothers": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BROOKSBROTHERS&langId=en_US&pagename=authenticate#promoAllocation",
            "ford": "/RSnextgen/svc/launch/index.action?siteId=PLCN_SERVICE&langId=en_US&pagename=authenticate#promoAllocation",
            "quick lane": "/RSnextgen/svc/launch/index.action?siteId=PLCN_SERVICE&langId=en_US&pagename=authenticate#promoAllocation",
            "lincoln": "/RSnextgen/svc/launch/index.action?siteId=PLCN_LINCOLNSERVICES&langId=en_US&pagename=authenticate#promoAllocation",
            "shell": "/RSnextgen/svc/launch/index.action?siteId=PLOC_SHELL&langId=en_US&pagename=authenticate#promoAllocation",
            "sunoco": "/RSnextgen/svc/launch/index.action?siteId=PLOC_SUNOCO&langId=en_US&pagename=authenticate#promoAllocation",
            "exxonmobil": "/RSnextgen/svc/launch/index.action?siteId=PLOC_EXXONMOBIL&langId=en_US&pagename=authenticate#promoAllocation",
            "american airlines": "/RSnextgen/svc/launch/index.action?siteId=PLCN_AMERICAN&langId=en_US&pagename=authenticate#promoAllocation",
            "brand source": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BRANDSOURCE&langId=en_US&pagename=authenticate#promoAllocation",
            "tractor supply": "/RSnextgen/svc/launch/index.action?siteId=PLCN_TRACTORSUPPLY&langId=en_US&pagename=authenticate#promoAllocation",
            "ross simons-sidney thomas": "/RSnextgen/svc/launch/index.action?siteId=PLCN_JEWELRY&langId=en_US&pagename=authenticate#promoAllocation",
            "jewelers reserve": "/RSnextgen/svc/launch/index.action?siteId=PLCN_JEWELRY&langId=en_US&pagename=authenticate#promoAllocation",
            "staples": "/RSnextgen/svc/launch/index.action?siteId=PLCN_STAPLES&langId=en_US&pagename=authenticate#promoAllocation",
            "office depot": "/RSnextgen/svc/launch/index.action?siteId=PLCN_OFFICEDEPOT&langId=en_US&pagename=authenticate#promoAllocation",
            "wawa": "/RSnextgen/svc/launch/index.action?siteId=PLOC_WAWA&langId=en_US&pagename=authenticate#promoAllocation",
            "volkswagen drive card": "/RSnextgen/svc/launch/index.action?siteId=PLCN_DRIVECARD&langId=en_US&pagename=authenticate#promoAllocation",
            "service central": "/RSnextgen/svc/launch/index.action?siteId=PLCN_SERVICECENTRAL&langId=en_US&pagename=authenticate#promoAllocation",
            "brp": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BRP&langId=en_US&pagename=authenticate#promoAllocation",
            "toro": "/RSnextgen/svc/launch/index.action?siteId=PLCN_TORO&langId=en_US&pagename=authenticate#promoAllocation",
            "honda power equipment": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HNPE&langId=en_US&pagename=authenticate#promoAllocation",
            "kawasaki": "/RSnextgen/svc/launch/index.action?siteId=PLCN_KAWA&langId=en_US&pagename=authenticate#promoAllocation",
            "honda power sports": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HNPS&langId=en_US&pagename=authenticate#promoAllocation",
            "macys": "/RSnextgen/svc/launch/index.action?siteId=PLCN_MACYS&langId=en_US&pagename=authenticate#promoAllocation",
            "bloomingdales": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BLOOMINGDALES&langId=en_US&pagename=authenticate#promoAllocation",
            "costco": "/RSnextgen/svc/launch/index.action?siteId=PLCN_COSTCO&langId=en_US&pagename=authenticate#promoAllocation",
            "home furnishings": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HOME&langId=en_US&pagename=authenticate#promoAllocation",
            "consumer electronics and appliances": "/RSnextgen/svc/launch/index.action?siteId=PLCN_ELECAPPL&langId=en_US&pagename=authenticate#promoAllocation",
            "llbean": "/RSnextgen/svc/launch/index.action?siteId=PLCN_LLBEAN&langId=en_US&pagename=authenticate#promoAllocation",
            "cat": "/RSnextgen/svc/launch/index.action?siteId=PLCN_CAT&langId=en_US&pagename=authenticate#promoAllocation",
            "meijer": "/RSnextgen/svc/launch/index.action?siteId=PLCN_meijer&langId=en_US&pagename=authenticate#promoAllocation"
        },
        commercial: {
            crc: {
                toro: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_TORO#pro/managealert",
                cnhi: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_CNHI#pro/managealert",
                "tractor supply": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_TRACTORSUPPLY#pro/managealert",
                thd: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_HOMEDEPOT#pro/managealert",
                staples: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_STAPLES#pro/managealert",
                "honda power equipment": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_HNPE#pro/managealert",
                cat: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_Cat#pro/managealert",
                "office depot": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_OFFICEDEPOT#pro/managealert"
            },
            prox: {
                thd: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_HOMEDEPOT#pro/managealert",
                staples: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_Staples#pro/managealert",
                cat: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_CAT#pro/managealert",
                "office depot": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_Officedepot#pro/managealert"
            },
            fleet: {
                exxon: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLOF_EXXONMOBIL#pro/managealert",
                sunoco: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLOF_SUNOCO#pro/managealert"
            }
        }
    },
    registration: {
        consumer: {
            "sears": "/RSnextgen/svc/registration/index.action?langId=en_US&siteId=SEARS#verify",
            "shop your way": "/RSnextgen/svc/registration/index.action?langId=en_US&siteId=PLCN_SYW#verify",
            "thd": "/RSnextgen/svc/registration/index.action?siteId=PLCN_HOMEDEPOT#verify",
            "best buy": "/RSnextgen/svc/registration/index.action?siteId=PLCN_BESTBUY&langId=en_US#verify",
            "good year": "/RSnextgen/svc/registration/index.action?siteId=PLCN_GOODYEAR&langId=en_US#verify",
            "brooks brothers": "/RSnextgen/svc/registration/index.action?siteId=PLCN_BROOKSBROTHERS&langId=en_US#verify",
            "ford": "/RSnextgen/svc/registration/index.action?siteId=PLCN_SERVICE&langId=en_US#verify",
            "quick lane": "/RSnextgen/svc/registration/index.action?siteId=PLCN_SERVICE&langId=en_US#verify",
            "lincoln": "/RSnextgen/svc/registration/index.action?siteId=PLCN_LINCOLNSERVICES&langId=en_US#verify",
            "shell": "/RSnextgen/svc/registration/index.action?siteId=PLOC_SHELL&langId=en_US#verify",
            "sunoco": "/RSnextgen/svc/registration/index.action?siteId=PLOC_SUNOCO&langId=en_US#verify",
            "exxonmobil": "/RSnextgen/svc/registration/index.action?siteId=PLOC_EXXONMOBIL&langId=en_US#verify",
            "american airlines": "/RSnextgen/svc/registration/index.action?siteId=PLCN_AMERICAN&langId=en_US#verify",
            "brand source": "/RSnextgen/svc/registration/index.action?siteId=PLCN_BRANDSOURCE&langId=en_US#verify",
            "tractor supply": "/RSnextgen/svc/registration/index.action?siteId=PLCN_TRACTORSUPPLY&langId=en_US#verify",
            "ross simons-sidney thomas": "/RSnextgen/svc/registration/index.action?siteId=PLCN_JEWELRY&langId=en_US#verify",
            "jewelers reserve": "/RSnextgen/svc/registration/index.action?siteId=PLCN_JEWELRY&langId=en_US#verify",
            "staples": "/RSnextgen/svc/registration/index.action?siteId=PLCN_STAPLES&langId=en_US#verify",
            "office depot": "/RSnextgen/svc/registration/index.action?siteId=PLCN_OFFICEDEPOT&langId=en_US#verify",
            "wawa": "/RSnextgen/svc/registration/index.action?siteId=PLOC_WAWA&langId=en_US#verify",
            "volkswagen drive card": "/RSnextgen/svc/registration/index.action?siteId=PLCN_DRIVECARD&langId=en_US#verify",
            "service central": "/RSnextgen/svc/registration/index.action?siteId=PLCN_SERVICECENTRAL&langId=en_US#verify",
            "brp": "/RSnextgen/svc/registration/index.action?siteId=PLCN_BRP&langId=en_US#verify",
            "toro": "/RSnextgen/svc/registration/index.action?siteId=PLCN_TORO&langId=en_US#verify",
            "honda power equipment": "/RSnextgen/svc/registration/index.action?siteId=PLCN_HNPE&langId=en_US#verify",
            "kawasaki": "/RSnextgen/svc/registration/index.action?siteId=PLCN_KAWA&langId=en_US#verify",
            "honda power sports": "/RSnextgen/svc/registration/index.action?siteId=PLCN_HNPS&langId=en_US#verify",
            "macys": "/RSnextgen/svc/registration/index.action?siteId=PLCN_MACYS&langId=en_US#verify",
            "bloomingdales": "/RSnextgen/svc/registration/index.action?siteId=PLCN_BLOOMINGDALES&langId=en_US#verify",
            "costco": "/RSnextgen/svc/registration/index.action?siteId=PLCN_COSTCO&langId=en_US#verify",
            "home furnishings": "/RSnextgen/svc/registration/index.action?siteId=PLCN_HOME&langId=en_US#verify",
            "consumer electronics and appliances": "/RSnextgen/svc/registration/index.action?siteId=PLCN_ELECAPPL&langId=en_US#verify",
            "llbean": "/RSnextgen/svc/registration/index.action?siteId=PLCN_LLBEAN&langId=en_US#verify",
            "cat": "/RSnextgen/svc/registration/index.action?siteId=PLCN_CAT&langId=en_US#verify",
            "meijer": "/RSnextgen/svc/registration/index.action?siteId=PLCN_meijer#verify"
        },
        commercial: {
            crc: {
                toro: "https://www.retailservicescommercial.citi.com/USCRSF/CMLSVC/index.html?siteId=PLCR_TORO#pro/reg",
                cnhi: "https://www.retailservicescommercial.citi.com/USCRSF/CMLSVC/index.html?siteId=PLCR_CNHI#pro/reg",
                "tractor supply": "https://www.retailservicescommercial.citi.com/USCRSF/CMLSVC/index.html?siteId=PLCR_TRACTORSUPPLY#pro/reg",
                thd: "https://www.retailservicescommercial.citi.com/USCRSF/CMLSVC/index.html?siteId=PLCR_HOMEDEPOT#pro/reg",
                staples: "https://www.retailservicescommercial.citi.com/USCRSF/CMLSVC/index.html?siteId=PLCR_STAPLES#pro/reg",
                "honda power equipment": "https://www.retailservicescommercial.citi.com/USCRSF/CMLSVC/index.html?siteId=PLCR_HNPE#pro/reg",
                cat: "https://www.retailservicescommercial.citi.com/USCRSF/CMLSVC/index.html?siteId=PLCR_Cat#pro/reg",
                "office depot": "https://www.retailservicescommercial.citi.com/USCRSF/CMLSVC/index.html?siteId=PLCR_OFFICEDEPOT#pro/reg"
            },
            prox: {
                thd: "https://www.retailservicescommercial.citi.com/USCRSF/CMLSVC/index.html?siteId=PLNP_HOMEDEPOT#pro/reg",
                staples: "https://www.retailservicescommercial.citi.com/USCRSF/CMLSVC/index.html?siteId=PLNP_Staples#pro/reg",
                cat: "https://www.retailservicescommercial.citi.com/USCRSF/CMLSVC/index.html?siteId=PLNP_CAT#pro/reg",
                "office depot": "https://www.retailservicescommercial.citi.com/USCRSF/CMLSVC/index.html?siteId=PLNP_Officedepot#pro/reg"
            },
            fleet: {
                exxon: "https://www.retailservicescommercial.citi.com/USCRSF/CMLSVC/index.html?siteId=PLOF_EXXONMOBIL#pro/reg",
                sunoco: "https://www.retailservicescommercial.citi.com/USCRSF/CMLSVC/index.html?siteId=PLOF_SUNOCO#pro/reg"
            }
        }
    }
}
var sms_urls = {
    disputes: {
        consumer: {
            "sears": "/RSnextgen/svc/launch/index.action?langId=en_US&siteId=SEARS&pagename=authenticate#disputeCharge",
            "thd": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HOMEDEPOT&langId=en_US&pagename=authenticate#disputeCharge",
            "best buy": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BESTBUY&langId=en_US&pagename=authenticate#disputeCharge",
            "good year": "/RSnextgen/svc/launch/index.action?siteId=PLCN_GOODYEAR&langId=en_US&pagename=authenticate#disputeCharge",
            "brooks brothers": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BROOKSBROTHERS&langId=en_US&pagename=authenticate#disputeCharge",
            "ford": "/RSnextgen/svc/launch/index.action?siteId=PLCN_SERVICE&langId=en_US&pagename=authenticate#disputeCharge",
            "quick lane": "/RSnextgen/svc/launch/index.action?siteId=PLCN_SERVICE&langId=en_US&pagename=authenticate#disputeCharge",
            "lincoln": "/RSnextgen/svc/launch/index.action?siteId=PLCN_LINCOLNSERVICES&langId=en_US&pagename=authenticate#disputeCharge",
            "shell": "/RSnextgen/svc/launch/index.action?siteId=PLOC_SHELL&langId=en_US&pagename=authenticate#disputeCharge",
            "sunoco": "/RSnextgen/svc/launch/index.action?siteId=PLOC_SUNOCO&langId=en_US&pagename=authenticate#disputeCharge",
            "exxonmobil": "/RSnextgen/svc/launch/index.action?siteId=PLOC_EXXONMOBIL&langId=en_US&pagename=authenticate#disputeCharge",
            "american airlines": "/RSnextgen/svc/launch/index.action?siteId=PLCN_AMERICAN&langId=en_US&pagename=authenticate#disputeCharge",
            "brand source": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BRANDSOURCE&langId=en_US&pagename=authenticate#disputeCharge",
            "tractor supply": "/RSnextgen/svc/launch/index.action?siteId=PLCN_TRACTORSUPPLY&langId=en_US&pagename=authenticate#disputeCharge",
            "ross simons-sidney thomas": "/RSnextgen/svc/launch/index.action?siteId=PLCN_JEWELRY&langId=en_US&pagename=authenticate#disputeCharge",
            "jewelers reserve": "/RSnextgen/svc/launch/index.action?siteId=PLCN_JEWELRY&langId=en_US&pagename=authenticate#disputeCharge",
            "staples": "/RSnextgen/svc/launch/index.action?siteId=PLCN_STAPLES&langId=en_US&pagename=authenticate#disputeCharge",
            "office depot": "/RSnextgen/svc/launch/index.action?siteId=PLCN_OFFICEDEPOT&langId=en_US&pagename=authenticate#disputeCharge",
            "wawa": "/RSnextgen/svc/launch/index.action?siteId=PLOC_WAWA&langId=en_US&pagename=authenticate#disputeCharge",
            "volkswagen drive card": "/RSnextgen/svc/launch/index.action?siteId=PLCN_DRIVECARD&langId=en_US&pagename=authenticate#disputeCharge",
            "service central": "/RSnextgen/svc/launch/index.action?siteId=PLCN_SERVICECENTRAL&langId=en_US&pagename=authenticate#disputeCharge",
            "brp": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BRP&langId=en_US&pagename=authenticate#disputeCharge",
            "toro": "/RSnextgen/svc/launch/index.action?siteId=PLCN_TORO&langId=en_US&pagename=authenticate#disputeCharge",
            "honda power equipment": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HNPE&langId=en_US&pagename=authenticate#disputeCharge",
            "kawasaki": "/RSnextgen/svc/launch/index.action?siteId=PLCN_KAWA&langId=en_US&pagename=authenticate#disputeCharge",
            "honda power sports": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HNPS&langId=en_US&pagename=authenticate#disputeCharge",
            "macys": "/RSnextgen/svc/launch/index.action?siteId=PLCN_MACYS&langId=en_US&pagename=authenticate#disputeCharge",
            "bloomingdales": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BLOOMINGDALES&langId=en_US&pagename=authenticate#disputeCharge",
            "costco": "/RSnextgen/svc/launch/index.action?siteId=PLCN_COSTCO&langId=en_US&pagename=authenticate#disputeCharge",
            "home furnishings": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HOME&langId=en_US&pagename=authenticate#disputeCharge",
            "consumer electronics and appliances": "/RSnextgen/svc/launch/index.action?siteId=PLCN_ELECAPPL&langId=en_US&pagename=authenticate#disputeCharge",
            "llbean": "service.llbeanmastercard.com",
            "cat": "/RSnextgen/svc/launch/index.action?siteId=PLCN_CAT&langId=en_US&pagename=authenticate#disputeCharge"
        },
        commercial: {
            crc: {
                toro: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_TORO#servc/disputecharge",
                cnhi: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_CNHI#servc/disputecharge",
                "tractor supply": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_TRACTORSUPPLY#servc/disputecharge",
                thd: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_HOMEDEPOT#servc/disputecharge",
                staples: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_STAPLES#servc/disputecharge",
                "honda power equipment": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_HNPE#servc/disputecharge",
                cat: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_Cat#servc/disputecharge",
                "office depot": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_OFFICEDEPOT#servc/disputecharge"
            },
            prox: {
                thd: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_HOMEDEPOT#servc/disputecharge",
                staples: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_Staples#servc/disputecharge",
                cat: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_CAT#servc/disputecharge",
                "office depot": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_Officedepot#servc/disputecharge"
            },
            fleet: {
                exxon: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLOF_EXXONMOBIL#servc/disputecharge",
                sunoco: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLOF_SUNOCO#servc/disputecharge"
            }
        }
    },
    lostcard: {
        consumer: {
            "sears": "/RSnextgen/svc/launch/index.action?siteId=SEARS&langId=en_US&pagename=authenticate#reportlostorstolen",
            "thd": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HOMEDEPOT&langId=en_US&pagename=authenticate#reportlostorstolen",
            "best buy": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BESTBUY&langId=en_US&pagename=authenticate#reportlostorstolen",
            "good year": "/RSnextgen/svc/launch/index.action?siteId=PLCN_GOODYEAR&langId=en_US&pagename=authenticate#reportlostorstolen",
            "brooks brothers": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BROOKSBROTHERS&langId=en_US&pagename=authenticate#reportlostorstolen",
            "ford": "/RSnextgen/svc/launch/index.action?siteId=PLCN_SERVICE&langId=en_US&pagename=authenticate#reportlostorstolen",
            "quick lane": "/RSnextgen/svc/launch/index.action?siteId=PLCN_SERVICE&langId=en_US&pagename=authenticate#reportlostorstolen",
            "lincoln": "/RSnextgen/svc/launch/index.action?siteId=PLCN_LINCOLNSERVICES&langId=en_US&pagename=authenticate#reportlostorstolen",
            "shell": "/RSnextgen/svc/launch/index.action?siteId=PLOC_SHELL&langId=en_US&pagename=authenticate#reportlostorstolen",
            "sunoco": "/RSnextgen/svc/launch/index.action?siteId=PLOC_SUNOCO&langId=en_US&pagename=authenticate#reportlostorstolen",
            "exxonmobil": "/RSnextgen/svc/launch/index.action?siteId=PLOC_EXXONMOBIL&langId=en_US&pagename=authenticate#reportlostorstolen",
            "american airlines": "/RSnextgen/svc/launch/index.action?siteId=PLCN_AMERICAN&langId=en_US&pagename=authenticate#reportlostorstolen",
            "brand source": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BRANDSOURCE&langId=en_US&pagename=authenticate#reportlostorstolen",
            "tractor supply": "/RSnextgen/svc/launch/index.action?siteId=PLCN_TRACTORSUPPLY&langId=en_US&pagename=authenticate#reportlostorstolen",
            "ross simons-sidney thomas": "/RSnextgen/svc/launch/index.action?siteId=PLCN_JEWELRY&langId=en_US&pagename=authenticate#reportlostorstolen",
            "jewelers reserve": "/RSnextgen/svc/launch/index.action?siteId=PLCN_JEWELRY&langId=en_US&pagename=authenticate#reportlostorstolen",
            "staples": "/RSnextgen/svc/launch/index.action?siteId=PLCN_STAPLES&langId=en_US&pagename=authenticate#reportlostorstolen",
            "office depot": "/RSnextgen/svc/launch/index.action?siteId=PLCN_OFFICEDEPOT&langId=en_US&pagename=authenticate#reportlostorstolen",
            "wawa": "/RSnextgen/svc/launch/index.action?siteId=PLOC_WAWA&langId=en_US&pagename=authenticate#reportlostorstolen",
            "volkswagen drive card": "/RSnextgen/svc/launch/index.action?siteId=PLCN_DRIVECARD&langId=en_US&pagename=authenticate#reportlostorstolen",
            "service central": "/RSnextgen/svc/launch/index.action?siteId=PLCN_SERVICECENTRAL&langId=en_US&pagename=authenticate#reportlostorstolen",
            "brp": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BRP&langId=en_US&pagename=authenticate#reportlostorstolen",
            "toro": "/RSnextgen/svc/launch/index.action?siteId=PLCN_TORO&langId=en_US&pagename=authenticate#reportlostorstolen",
            "honda power equipment": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HNPE&langId=en_US&pagename=authenticate#reportlostorstolen",
            "kawasaki": "/RSnextgen/svc/launch/index.action?siteId=PLCN_KAWA&langId=en_US&pagename=authenticate#reportlostorstolen",
            "honda power sports": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HNPS&langId=en_US&pagename=authenticate#reportlostorstolen",
            "macys": "/RSnextgen/svc/launch/index.action?siteId=PLCN_MACYS&langId=en_US&pagename=authenticate#reportlostorstolen",
            "bloomingdales": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BLOOMINGDALES&langId=en_US&pagename=authenticate#reportlostorstolen",
            "costco": "/RSnextgen/svc/launch/index.action?siteId=PLCN_COSTCO&langId=en_US&pagename=authenticate#reportlostorstolen",
            "home furnishings": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HOME&langId=en_US&pagename=authenticate#reportlostorstolen",
            "consumer electronics and appliances": "/RSnextgen/svc/launch/index.action?siteId=PLCN_ELECAPPL&langId=en_US&pagename=authenticate#reportlostorstolen",
            "llbean": "/RSnextgen/svc/launch/index.action?siteId=PLCN_LLBEAN&langId=en_US&pagename=authenticate#reportlostorstolen",
            "cat": "/RSnextgen/svc/launch/index.action?siteId=PLCN_CAT&langId=en_US&pagename=authenticate#reportlostorstolen"
        },
        commercial: {
            crc: {
                toro: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_TORO#servc/lostcard",
                cnhi: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_CNHI#servc/lostcard",
                "tractor supply": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_TRACTORSUPPLY#servc/lostcard",
                thd: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_HOMEDEPOT#servc/lostcard",
                staples: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_STAPLES#servc/lostcard",
                "honda power equipment": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_HNPE#servc/lostcard",
                cat: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_Cat#servc/lostcard",
                "office depot": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_OFFICEDEPOT#servc/lostcard"
            },
            prox: {
                thd: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_HOMEDEPOT#servc/lostcard",
                staples: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_Staples#servc/lostcard",
                cat: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_CAT#servc/lostcard",
                "office depot": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_Officedepot#servc/lostcard"
            },
            fleet: {
                exxon: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLOF_EXXONMOBIL#servc/lostcard",
                sunoco: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLOF_SUNOCO#servc/lostcard"
            }
        }
    },
    addAuthUser: {
        consumer: {
            "sears": "adduser.searscard.com",
            "thd": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HOMEDEPOT&langId=en_US&pagename=authenticate#addauthusers",
            "best buy": "adduser.bestbuy.accountonline.com",
            "good year": "/RSnextgen/svc/launch/index.action?siteId=PLCN_GOODYEAR&langId=en_US&pagename=authenticate#addauthusers",
            "brooks brothers": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BROOKSBROTHERS&langId=en_US&pagename=authenticate#addauthusers",
            "ford": "/RSnextgen/svc/launch/index.action?siteId=PLCN_SERVICE&langId=en_US&pagename=authenticate#addauthusers",
            "quick lane": "/RSnextgen/svc/launch/index.action?siteId=PLCN_SERVICE&langId=en_US&pagename=authenticate#addauthusers",
            "lincoln": "/RSnextgen/svc/launch/index.action?siteId=PLCN_LINCOLNSERVICES&langId=en_US&pagename=authenticate#addauthusers",
            "shell": "/RSnextgen/svc/launch/index.action?siteId=PLOC_SHELL&langId=en_US&pagename=authenticate#addauthusers",
            "sunoco": "/RSnextgen/svc/launch/index.action?siteId=PLOC_SUNOCO&langId=en_US&pagename=authenticate#addauthusers",
            "exxonmobil": "/RSnextgen/svc/launch/index.action?siteId=PLOC_EXXONMOBIL&langId=en_US&pagename=authenticate#addauthusers",
            "american airlines": "/RSnextgen/svc/launch/index.action?siteId=PLCN_AMERICAN&langId=en_US&pagename=authenticate#addauthusers",
            "brand source": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BRANDSOURCE&langId=en_US&pagename=authenticate#addauthusers",
            "tractor supply": "/RSnextgen/svc/launch/index.action?siteId=PLCN_TRACTORSUPPLY&langId=en_US&pagename=authenticate#addauthusers",
            "ross simons-sidney thomas": "/RSnextgen/svc/launch/index.action?siteId=PLCN_JEWELRY&langId=en_US&pagename=authenticate#addauthusers",
            "jewelers reserve": "/RSnextgen/svc/launch/index.action?siteId=PLCN_JEWELRY&langId=en_US&pagename=authenticate#addauthusers",
            "staples": "/RSnextgen/svc/launch/index.action?siteId=PLCN_STAPLES&langId=en_US&pagename=authenticate#addauthusers",
            "office depot": "/RSnextgen/svc/launch/index.action?siteId=PLCN_OFFICEDEPOT&langId=en_US&pagename=authenticate#addauthusers",
            "wawa": "/RSnextgen/svc/launch/index.action?siteId=PLOC_WAWA&langId=en_US&pagename=authenticate#addauthusers",
            "volkswagen drive card": "/RSnextgen/svc/launch/index.action?siteId=PLCN_DRIVECARD&langId=en_US&pagename=authenticate#addauthusers",
            "service central": "/RSnextgen/svc/launch/index.action?siteId=PLCN_SERVICECENTRAL&langId=en_US&pagename=authenticate#addauthusers",
            "brp": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BRP&langId=en_US&pagename=authenticate#addauthusers",
            "toro": "/RSnextgen/svc/launch/index.action?siteId=PLCN_TORO&langId=en_US&pagename=authenticate#addauthusers",
            "honda power equipment": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HNPE&langId=en_US&pagename=authenticate#addauthusers",
            "kawasaki": "/RSnextgen/svc/launch/index.action?siteId=PLCN_KAWA&langId=en_US&pagename=authenticate#addauthusers",
            "honda power sports": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HNPS&langId=en_US&pagename=authenticate#addauthusers",
            "macys": "/RSnextgen/svc/launch/index.action?siteId=PLCN_MACYS&langId=en_US&pagename=authenticate#addauthusers",
            "bloomingdales": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BLOOMINGDALES&langId=en_US&pagename=authenticate#addauthusers",
            "costco": "/RSnextgen/svc/launch/index.action?siteId=PLCN_COSTCO&langId=en_US&pagename=authenticate#addauthusers",
            "home furnishings": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HOME&langId=en_US&pagename=authenticate#addauthusers",
            "consumer electronics and appliances": "/RSnextgen/svc/launch/index.action?siteId=PLCN_ELECAPPL&langId=en_US&pagename=authenticate#addauthusers",
            "llbean": "adduser.llbeanmastercard.com",
            "cat": "/RSnextgen/svc/launch/index.action?siteId=PLCN_CAT&langId=en_US&pagename=authenticate#addauthusers",
            "meijer": "adduser.meijer.accountonline.com"
        },
        commercial: {
            crc: {
                toro: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_TORO#pro/adduser",
                cnhi: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_CNHI#pro/adduser",
                "tractor supply": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_TRACTORSUPPLY#pro/adduser",
                thd: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_HOMEDEPOT#pro/adduser",
                staples: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_STAPLES#pro/adduser",
                "honda power equipment": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_HNPE#pro/adduser",
                cat: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_Cat#pro/adduser",
                "office depot": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_OFFICEDEPOT#pro/adduser"
            },
            prox: {
                thd: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_HOMEDEPOT#pro/adduser",
                staples: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_Staples#pro/adduser",
                cat: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_CAT#pro/adduser",
                "office depot": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_Officedepot#pro/adduser"
            },
            fleet: {
                exxon: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLOF_EXXONMOBIL#pro/adduser",
                sunoco: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLOF_SUNOCO#pro/adduser"
            }
        }
    },
    creditHome: {
        consumer: {
            "sears": "/RSnextgen/svc/launch/index.action?siteId=SEARS&pagename=authenticate#dashboard",
            "thd": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HOMEDEPOT&pagename=authenticate#dashboard",
            "best buy": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BESTBUY&pagename=authenticate#dashboard",
            "good year": "/RSnextgen/svc/launch/index.action?siteId=PLCN_GOODYEAR&pagename=authenticate#dashboard",
            "brooks brothers": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BROOKSBROTHERS&pagename=authenticate#dashboard",
            "ford": "/RSnextgen/svc/launch/index.action?siteId=PLCN_SERVICE&pagename=authenticate#dashboard",
            "quick lane": "/RSnextgen/svc/launch/index.action?siteId=PLCN_SERVICE&pagename=authenticate#dashboard",
            "lincoln": "/RSnextgen/svc/launch/index.action?siteId=PLCN_LINCOLNSERVICES&pagename=authenticate#dashboard",
            "shell": "/RSnextgen/svc/launch/index.action?siteId=PLOC_SHELL&pagename=authenticate#dashboard",
            "sunoco": "/RSnextgen/svc/launch/index.action?siteId=PLOC_SUNOCO&pagename=authenticate#dashboard",
            "exxonmobil": "/RSnextgen/svc/launch/index.action?siteId=PLOC_EXXONMOBIL&pagename=authenticate#dashboard",
            "american airlines": "/RSnextgen/svc/launch/index.action?siteId=PLCN_AMERICAN&pagename=authenticate#dashboard",
            "brand source": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BRANDSOURCE&pagename=authenticate#dashboard",
            "tractor supply": "/RSnextgen/svc/launch/index.action?siteId=PLCN_TRACTORSUPPLY&pagename=authenticate#dashboard",
            "ross simons-sidney thomas": "/RSnextgen/svc/launch/index.action?siteId=PLCN_JEWELRY&pagename=authenticate#dashboard",
            "jewelers reserve": "/RSnextgen/svc/launch/index.action?siteId=PLCN_JEWELRY&pagename=authenticate#dashboard",
            "staples": "/RSnextgen/svc/launch/index.action?siteId=PLCN_STAPLES&pagename=authenticate#dashboard",
            "office depot": "/RSnextgen/svc/launch/index.action?siteId=PLCN_OFFICEDEPOT&pagename=authenticate#dashboard",
            "wawa": "/RSnextgen/svc/launch/index.action?siteId=PLOC_WAWA&pagename=authenticate#dashboard",
            "volkswagen drive card": "/RSnextgen/svc/launch/index.action?siteId=PLCN_DRIVECARD&pagename=authenticate#dashboard",
            "service central": "/RSnextgen/svc/launch/index.action?siteId=PLCN_SERVICECENTRAL&pagename=authenticate#dashboard",
            "brp": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BRP&pagename=authenticate#dashboard",
            "toro": "/RSnextgen/svc/launch/index.action?siteId=PLCN_TORO&pagename=authenticate#dashboard",
            "honda power equipment": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HNPE&pagename=authenticate#dashboard",
            "kawasaki": "/RSnextgen/svc/launch/index.action?siteId=PLCN_KAWA&pagename=authenticate#dashboard",
            "honda power sports": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HNPS&pagename=authenticate#dashboard",
            "macys": "/RSnextgen/svc/launch/index.action?siteId=PLCN_MACYS&pagename=authenticate#dashboard",
            "bloomingdales": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BLOOMINGDALES&pagename=authenticate#dashboard",
            "costco": "/RSnextgen/svc/launch/index.action?siteId=PLCN_COSTCO&pagename=authenticate#dashboard",
            "home furnishings": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HOME&pagename=authenticate#dashboard",
            "consumer electronics and appliances": "/RSnextgen/svc/launch/index.action?siteId=PLCN_ELECAPPL&pagename=authenticate#dashboard",
            "llbean": "/RSnextgen/svc/launch/index.action?siteId=PLCN_LLBEAN&langId=en_US&pagename=authenticate#rewards",
            "cat": "/RSnextgen/svc/launch/index.action?siteId=PLCN_CAT&pagename=authenticate#dashboard"
        },
        commercial: {
            crc: {
                toro: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_TORO#dash/lan",
                cnhi: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_CNHI#dash/lan",
                "tractor supply": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_TRACTORSUPPLY#dash/lan",
                thd: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_HOMEDEPOT#dash/lan",
                staples: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_STAPLES#dash/lan",
                "honda power equipment": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_HNPE#dash/lan",
                cat: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_Cat#dash/lan",
                "office depot": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_OFFICEDEPOT#dash/lan"
            },
            prox: {
                thd: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_HOMEDEPOT#dash/lan",
                staples: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_Staples#dash/lan",
                cat: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_CAT#dash/lan",
                "office depot": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_Officedepot#dash/lan"
            },
            fleet: {
                exxon: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLOF_EXXONMOBIL#dash/lan",
                sunoco: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLOF_SUNOCO#dash/lan"
            }
        }
    },
    helpContact: {
        consumer: {
            "sears": "/RSnextgen/svc/launch/index.action?langId=en_US&siteId=SEARS&pagename=authenticate#helpcontact",
            "thd": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HOMEDEPOT&langId=en_US&pagename=authenticate#helpcontact",
            "best buy": "helpcontact.bestbuy.accountonline.com ",
            "good year": "/RSnextgen/svc/launch/index.action?siteId=PLCN_GOODYEAR&langId=en_US&pagename=authenticate#helpcontact",
            "brooks brothers": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BROOKSBROTHERS&langId=en_US&pagename=authenticate#helpcontact",
            "ford": "/RSnextgen/svc/launch/index.action?siteId=PLCN_SERVICE&langId=en_US&pagename=authenticate#helpcontact",
            "quick lane": "/RSnextgen/svc/launch/index.action?siteId=PLCN_SERVICE&langId=en_US&pagename=authenticate#helpcontact",
            "lincoln": "/RSnextgen/svc/launch/index.action?siteId=PLCN_LINCOLNSERVICES&langId=en_US&pagename=authenticate#helpcontact",
            "shell": "/RSnextgen/svc/launch/index.action?siteId=PLOC_SHELL&langId=en_US&pagename=authenticate#helpcontact",
            "sunoco": "/RSnextgen/svc/launch/index.action?siteId=PLOC_SUNOCO&langId=en_US&pagename=authenticate#helpcontact",
            "exxonmobil": "/RSnextgen/svc/launch/index.action?siteId=PLOC_EXXONMOBIL&langId=en_US&pagename=authenticate#helpcontact",
            "american airlines": "/RSnextgen/svc/launch/index.action?siteId=PLCN_AMERICAN&langId=en_US&pagename=authenticate#helpcontact",
            "brand source": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BRANDSOURCE&langId=en_US&pagename=authenticate#helpcontact",
            "tractor supply": "/RSnextgen/svc/launch/index.action?siteId=PLCN_TRACTORSUPPLY&langId=en_US&pagename=authenticate#helpcontact",
            "ross simons-sidney thomas": "/RSnextgen/svc/launch/index.action?siteId=PLCN_JEWELRY&langId=en_US&pagename=authenticate#helpcontact",
            "jewelers reserve": "/RSnextgen/svc/launch/index.action?siteId=PLCN_JEWELRY&langId=en_US&pagename=authenticate#helpcontact",
            "staples": "/RSnextgen/svc/launch/index.action?siteId=PLCN_STAPLES&langId=en_US&pagename=authenticate#helpcontact",
            "office depot": "/RSnextgen/svc/launch/index.action?siteId=PLCN_OFFICEDEPOT&langId=en_US&pagename=authenticate#helpcontact",
            "wawa": "/RSnextgen/svc/launch/index.action?siteId=PLOC_WAWA&langId=en_US&pagename=authenticate#helpcontact",
            "volkswagen drive card": "/RSnextgen/svc/launch/index.action?siteId=PLCN_DRIVECARD&langId=en_US&pagename=authenticate#helpcontact",
            "service central": "/RSnextgen/svc/launch/index.action?siteId=PLCN_SERVICECENTRAL&langId=en_US&pagename=authenticate#helpcontact",
            "brp": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BRP&langId=en_US&pagename=authenticate#helpcontact",
            "toro": "/RSnextgen/svc/launch/index.action?siteId=PLCN_TORO&langId=en_US&pagename=authenticate#helpcontact",
            "honda power equipment": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HNPE&langId=en_US&pagename=authenticate#helpcontact",
            "kawasaki": "/RSnextgen/svc/launch/index.action?siteId=PLCN_KAWA&langId=en_US&pagename=authenticate#helpcontact",
            "honda power sports": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HNPS&langId=en_US&pagename=authenticate#helpcontact",
            "macys": "/RSnextgen/svc/launch/index.action?siteId=PLCN_MACYS&langId=en_US&pagename=authenticate#helpcontact",
            "bloomingdales": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BLOOMINGDALES&langId=en_US&pagename=authenticate#helpcontact",
            "costco": "/RSnextgen/svc/launch/index.action?siteId=PLCN_COSTCO&langId=en_US&pagename=authenticate#helpcontact",
            "home furnishings": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HOME&langId=en_US&pagename=authenticate#helpcontact",
            "consumer electronics and appliances": "/RSnextgen/svc/launch/index.action?siteId=PLCN_ELECAPPL&langId=en_US&pagename=authenticate#helpcontact",
            "llbean": "/RSnextgen/svc/launch/index.action?siteId=PLCN_LLBEAN&langId=en_US&pagename=authenticate#helpcontact",
            "cat": "/RSnextgen/svc/launch/index.action?siteId=PLCN_CAT&langId=en_US&pagename=authenticate#helpcontact"
        },
        commercial: {
            crc: {
                toro: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_TORO#help/contact",
                cnhi: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_CNHI#help/contact",
                "tractor supply": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_TRACTORSUPPLY#help/contact",
                thd: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_HOMEDEPOT#help/contact",
                staples: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_STAPLES#help/contact",
                "honda power equipment": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_HNPE#help/contact",
                cat: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_Cat#help/contact",
                "office depot": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_OFFICEDEPOT#help/contact"
            },
            prox: {
                thd: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_HOMEDEPOT#help/contact",
                staples: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_Staples#help/contact",
                cat: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_CAT#help/contact",
                "office depot": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_Officedepot#help/contact"
            },
            fleet: {
                exxon: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLOF_EXXONMOBIL#help/contact",
                sunoco: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLOF_SUNOCO#help/contact"
            }
        }
    },
    payments: {
        consumer: {
            "sears": "pay.searscard.com",
            "thd": "pay.homedepotconsumer.accountonline.com",
            "best buy": "pay.bestbuy.accountonline.com",
            "good year": "/RSnextgen/svc/launch/index.action?siteId=PLCN_GOODYEAR&langId=en_US&pagename=authenticate#payments",
            "brooks brothers": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BROOKSBROTHERS&langId=en_US&pagename=authenticate#payments",
            "ford": "/RSnextgen/svc/launch/index.action?siteId=PLCN_SERVICE&langId=en_US&pagename=authenticate#payments",
            "quick lane": "/RSnextgen/svc/launch/index.action?siteId=PLCN_SERVICE&langId=en_US&pagename=authenticate#payments",
            "lincoln": "/RSnextgen/svc/launch/index.action?siteId=PLCN_LINCOLNSERVICES&langId=en_US&pagename=authenticate#payments",
            "shell": "/RSnextgen/svc/launch/index.action?siteId=PLOC_SHELL&langId=en_US&pagename=authenticate#payments",
            "sunoco": "/RSnextgen/svc/launch/index.action?siteId=PLOC_SUNOCO&langId=en_US&pagename=authenticate#payments",
            "exxonmobil": "/RSnextgen/svc/launch/index.action?siteId=PLOC_EXXONMOBIL&langId=en_US&pagename=authenticate#payments",
            "american airlines": "/RSnextgen/svc/launch/index.action?siteId=PLCN_AMERICAN&langId=en_US&pagename=authenticate#payments",
            "brand source": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BRANDSOURCE&langId=en_US&pagename=authenticate#payments",
            "tractor supply": "/RSnextgen/svc/launch/index.action?siteId=PLCN_TRACTORSUPPLY&langId=en_US&pagename=authenticate#payments",
            "ross simons-sidney thomas": "/RSnextgen/svc/launch/index.action?siteId=PLCN_JEWELRY&langId=en_US&pagename=authenticate#payments",
            "jewelers reserve": "/RSnextgen/svc/launch/index.action?siteId=PLCN_JEWELRY&langId=en_US&pagename=authenticate#payments",
            "staples": "/RSnextgen/svc/launch/index.action?siteId=PLCN_STAPLES&langId=en_US&pagename=authenticate#payments",
            "office depot": "/RSnextgen/svc/launch/index.action?siteId=PLCN_OFFICEDEPOT&langId=en_US&pagename=authenticate#payments",
            "wawa": "/RSnextgen/svc/launch/index.action?siteId=PLOC_WAWA&langId=en_US&pagename=authenticate#payments",
            "volkswagen drive card": "/RSnextgen/svc/launch/index.action?siteId=PLCN_DRIVECARD&langId=en_US&pagename=authenticate#payments",
            "service central": "/RSnextgen/svc/launch/index.action?siteId=PLCN_SERVICECENTRAL&langId=en_US&pagename=authenticate#payments",
            "brp": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BRP&langId=en_US&pagename=authenticate#payments",
            "toro": "/RSnextgen/svc/launch/index.action?siteId=PLCN_TORO&langId=en_US&pagename=authenticate#payments",
            "honda power equipment": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HNPE&langId=en_US&pagename=authenticate#payments",
            "kawasaki": "/RSnextgen/svc/launch/index.action?siteId=PLCN_KAWA&langId=en_US&pagename=authenticate#payments",
            "honda power sports": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HNPS&langId=en_US&pagename=authenticate#payments",
            "macys": "/RSnextgen/svc/launch/index.action?siteId=PLCN_MACYS&langId=en_US&pagename=authenticate#payments",
            "bloomingdales": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BLOOMINGDALES&langId=en_US&pagename=authenticate#payments",
            "costco": "/RSnextgen/svc/launch/index.action?siteId=PLCN_COSTCO&langId=en_US&pagename=authenticate#payments",
            "home furnishings": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HOME&langId=en_US&pagename=authenticate#payments",
            "consumer electronics and appliances": "/RSnextgen/svc/launch/index.action?siteId=PLCN_ELECAPPL&langId=en_US&pagename=authenticate#payments",
            "llbean": "/RSnextgen/svc/launch/index.action?siteId=PLCN_LLBEAN&langId=en_US&pagename=authenticate#payments",
            "cat": "/RSnextgen/svc/launch/index.action?siteId=PLCN_CAT&langId=en_US&pagename=authenticate#payments",
            "meijer": "pay.meijer.accountonline.com"
        },
        commercial: {
            crc: {
                toro: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_TORO#paym/payments",
                cnhi: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_CNHI#paym/payments",
                "tractor supply": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_TRACTORSUPPLY#paym/payments",
                thd: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_HOMEDEPOT#paym/payments",
                staples: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_STAPLES#paym/payments",
                "honda power equipment": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_HNPE#paym/payments",
                cat: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_Cat#paym/payments",
                "office depot": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_OFFICEDEPOT#paym/payments"
            },
            prox: {
                thd: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_HOMEDEPOT#paym/payments",
                staples: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_Staples#paym/payments",
                cat: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_CAT#paym/payments",
                "office depot": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_Officedepot#paym/payments"
            },
            fleet: {
                exxon: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLOF_EXXONMOBIL#paym/payments",
                sunoco: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLOF_SUNOCO#paym/payments"
            }
        }
    },
    autopay: {
        consumer: {
            "sears": "pay.searscard.com",
            "thd": "pay.homedepotconsumer.accountonline.com",
            "best buy": "pay.bestbuy.accountonline.com",
            "good year": "/RSnextgen/svc/launch/index.action?siteId=PLCN_GOODYEAR&langId=en_US&pagename=authenticate#autopay",
            "brooks brothers": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BROOKSBROTHERS&langId=en_US&pagename=authenticate#autopay",
            "ford": "/RSnextgen/svc/launch/index.action?siteId=PLCN_SERVICE&langId=en_US&pagename=authenticate#autopay",
            "quick lane": "/RSnextgen/svc/launch/index.action?siteId=PLCN_SERVICE&langId=en_US&pagename=authenticate#autopay",
            "lincoln": "/RSnextgen/svc/launch/index.action?siteId=PLCN_LINCOLNSERVICES&langId=en_US&pagename=authenticate#autopay",
            "shell": "/RSnextgen/svc/launch/index.action?siteId=PLOC_SHELL&langId=en_US&pagename=authenticate#autopay",
            "sunoco": "/RSnextgen/svc/launch/index.action?siteId=PLOC_SUNOCO&langId=en_US&pagename=authenticate#autopay",
            "exxonmobil": "/RSnextgen/svc/launch/index.action?siteId=PLOC_EXXONMOBIL&langId=en_US&pagename=authenticate#autopay",
            "american airlines": "/RSnextgen/svc/launch/index.action?siteId=PLCN_AMERICAN&langId=en_US&pagename=authenticate#autopay",
            "brand source": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BRANDSOURCE&langId=en_US&pagename=authenticate#autopay",
            "tractor supply": "/RSnextgen/svc/launch/index.action?siteId=PLCN_TRACTORSUPPLY&langId=en_US&pagename=authenticate#autopay",
            "ross simons-sidney thomas": "/RSnextgen/svc/launch/index.action?siteId=PLCN_JEWELRY&langId=en_US&pagename=authenticate#autopay",
            "jewelers reserve": "/RSnextgen/svc/launch/index.action?siteId=PLCN_JEWELRY&langId=en_US&pagename=authenticate#autopay",
            "staples": "/RSnextgen/svc/launch/index.action?siteId=PLCN_STAPLES&langId=en_US&pagename=authenticate#autopay",
            "office depot": "/RSnextgen/svc/launch/index.action?siteId=PLCN_OFFICEDEPOT&langId=en_US&pagename=authenticate#autopay",
            "wawa": "/RSnextgen/svc/launch/index.action?siteId=PLOC_WAWA&langId=en_US&pagename=authenticate#autopay",
            "volkswagen drive card": "/RSnextgen/svc/launch/index.action?siteId=PLCN_DRIVECARD&langId=en_US&pagename=authenticate#autopay",
            "service central": "/RSnextgen/svc/launch/index.action?siteId=PLCN_SERVICECENTRAL&langId=en_US&pagename=authenticate#autopay",
            "brp": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BRP&langId=en_US&pagename=authenticate#autopay",
            "toro": "/RSnextgen/svc/launch/index.action?siteId=PLCN_TORO&langId=en_US&pagename=authenticate#autopay",
            "honda power equipment": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HNPE&langId=en_US&pagename=authenticate#autopay",
            "kawasaki": "/RSnextgen/svc/launch/index.action?siteId=PLCN_KAWA&langId=en_US&pagename=authenticate#autopay",
            "honda power sports": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HNPS&langId=en_US&pagename=authenticate#autopay",
            "macys": "/RSnextgen/svc/launch/index.action?siteId=PLCN_MACYS&langId=en_US&pagename=authenticate#autopay",
            "bloomingdales": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BLOOMINGDALES&langId=en_US&pagename=authenticate#autopay",
            "costco": "/RSnextgen/svc/launch/index.action?siteId=PLCN_COSTCO&langId=en_US&pagename=authenticate#autopay",
            "home furnishings": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HOME&langId=en_US&pagename=authenticate#autopay",
            "consumer electronics and appliances": "/RSnextgen/svc/launch/index.action?siteId=PLCN_ELECAPPL&langId=en_US&pagename=authenticate#autopay",
            "llbean": "/RSnextgen/svc/launch/index.action?siteId=PLCN_LLBEAN&langId=en_US&pagename=authenticate#autopay",
            "cat": "/RSnextgen/svc/launch/index.action?siteId=PLCN_CAT&langId=en_US&pagename=authenticate#autopay"
        },
        commercial: {
            crc: {
                toro: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_TORO#paym/setautopay",
                cnhi: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_CNHI#paym/setautopay",
                "tractor supply": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_TRACTORSUPPLY#paym/setautopay",
                thd: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_HOMEDEPOT#paym/setautopay",
                staples: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_STAPLES#paym/setautopay",
                "honda power equipment": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_HNPE#paym/setautopay",
                cat: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_Cat#paym/setautopay",
                "office depot": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_OFFICEDEPOT#paym/setautopay"
            },
            /* prox:{

                thd : "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_HOMEDEPOT#paym/setautopay",

                staples : "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_Staples#paym/setautopay",

                cat : "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_CAT#paym/setautopay",

                "office depot"  : "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_Officedepot#paym/setautopay"

            }, */
            fleet: {
                exxon: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLOF_EXXONMOBIL#paym/setautopay",
                sunoco: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLOF_SUNOCO#paym/setautopay"
            }
        }
    },
    PaymentSrc: {
        consumer: {
            "sears": "pay.searscard.com",
            "thd": "pay.homedepotconsumer.accountonline.com",
            "best buy": "pay.bestbuy.accountonline.com",
            "good year": "/RSnextgen/svc/launch/index.action?siteId=PLCN_GOODYEAR&langId=en_US&pagename=authenticate#addpaymentsrc",
            "brooks brothers": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BROOKSBROTHERS&langId=en_US&pagename=authenticate#addpaymentsrc",
            "ford": "/RSnextgen/svc/launch/index.action?siteId=PLCN_SERVICE&langId=en_US&pagename=authenticate#addpaymentsrc",
            "quick lane": "/RSnextgen/svc/launch/index.action?siteId=PLCN_SERVICE&langId=en_US&pagename=authenticate#addpaymentsrc",
            "lincoln": "/RSnextgen/svc/launch/index.action?siteId=PLCN_LINCOLNSERVICES&langId=en_US&pagename=authenticate#addpaymentsrc",
            "shell": "/RSnextgen/svc/launch/index.action?siteId=PLOC_SHELL&langId=en_US&pagename=authenticate#addpaymentsrc",
            "sunoco": "/RSnextgen/svc/launch/index.action?siteId=PLOC_SUNOCO&langId=en_US&pagename=authenticate#addpaymentsrc",
            "exxonmobil": "/RSnextgen/svc/launch/index.action?siteId=PLOC_EXXONMOBIL&langId=en_US&pagename=authenticate#addpaymentsrc",
            "american airlines": "/RSnextgen/svc/launch/index.action?siteId=PLCN_AMERICAN&langId=en_US&pagename=authenticate#addpaymentsrc",
            "brand source": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BRANDSOURCE&langId=en_US&pagename=authenticate#addpaymentsrc",
            "tractor supply": "/RSnextgen/svc/launch/index.action?siteId=PLCN_TRACTORSUPPLY&langId=en_US&pagename=authenticate#addpaymentsrc",
            "ross simons-sidney thomas": "/RSnextgen/svc/launch/index.action?siteId=PLCN_JEWELRY&langId=en_US&pagename=authenticate#addpaymentsrc",
            "jewelers reserve": "/RSnextgen/svc/launch/index.action?siteId=PLCN_JEWELRY&langId=en_US&pagename=authenticate#addpaymentsrc",
            "staples": "/RSnextgen/svc/launch/index.action?siteId=PLCN_STAPLES&langId=en_US&pagename=authenticate#addpaymentsrc",
            "office depot": "/RSnextgen/svc/launch/index.action?siteId=PLCN_OFFICEDEPOT&langId=en_US&pagename=authenticate#addpaymentsrc",
            "wawa": "/RSnextgen/svc/launch/index.action?siteId=PLOC_WAWA&langId=en_US&pagename=authenticate#addpaymentsrc",
            "volkswagen drive card": "/RSnextgen/svc/launch/index.action?siteId=PLCN_DRIVECARD&langId=en_US&pagename=authenticate#addpaymentsrc",
            "service central": "/RSnextgen/svc/launch/index.action?siteId=PLCN_SERVICECENTRAL&langId=en_US&pagename=authenticate#addpaymentsrc",
            "brp": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BRP&langId=en_US&pagename=authenticate#addpaymentsrc",
            "toro": "/RSnextgen/svc/launch/index.action?siteId=PLCN_TORO&langId=en_US&pagename=authenticate#addpaymentsrc",
            "honda power equipment": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HNPE&langId=en_US&pagename=authenticate#addpaymentsrc",
            "kawasaki": "/RSnextgen/svc/launch/index.action?siteId=PLCN_KAWA&langId=en_US&pagename=authenticate#addpaymentsrc",
            "honda power sports": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HNPS&langId=en_US&pagename=authenticate#addpaymentsrc",
            "macys": "/RSnextgen/svc/launch/index.action?siteId=PLCN_MACYS&langId=en_US&pagename=authenticate#addpaymentsrc",
            "bloomingdales": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BLOOMINGDALES&langId=en_US&pagename=authenticate#addpaymentsrc",
            "costco": "/RSnextgen/svc/launch/index.action?siteId=PLCN_COSTCO&langId=en_US&pagename=authenticate#addpaymentsrc",
            "home furnishings": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HOME&langId=en_US&pagename=authenticate#addpaymentsrc",
            "consumer electronics and appliances": "/RSnextgen/svc/launch/index.action?siteId=PLCN_ELECAPPL&langId=en_US&pagename=authenticate#addpaymentsrc",
            "llbean": "/RSnextgen/svc/launch/index.action?siteId=PLCN_LLBEAN&langId=en_US&pagename=authenticate#addpaymentsrc",
            "cat": "/RSnextgen/svc/launch/index.action?siteId=PLCN_CAT&langId=en_US&pagename=authenticate#addpaymentsrc"
        },
        commercial: {
            crc: {
                toro: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_TORO#paym/addpymntsrc",
                cnhi: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_CNHI#paym/addpymntsrc",
                "tractor supply": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_TRACTORSUPPLY#paym/addpymntsrc",
                thd: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_HOMEDEPOT#paym/addpymntsrc",
                staples: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_STAPLES#paym/addpymntsrc",
                "honda power equipment": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_HNPE#paym/addpymntsrc",
                cat: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_Cat#paym/addpymntsrc",
                "office depot": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_OFFICEDEPOT#paym/addpymntsrc"
            },
            prox: {
                thd: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_HOMEDEPOT#paym/addpymntsrc",
                staples: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_Staples#paym/addpymntsrc",
                cat: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_CAT#paym/addpymntsrc",
                "office depot": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_Officedepot#paym/addpymntsrc"
            },
            fleet: {
                exxon: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLOF_EXXONMOBIL#paym/addpymntsrc",
                sunoco: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLOF_SUNOCO#paym/addpymntsrc"
            }
        }
    },
    manageaccount: {
        consumer: {
            "sears": "/RSnextgen/svc/launch/index.action?langId=en_US&siteId=SEARS&pagename=authenticate#manageaccount",
            "thd": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HOMEDEPOT&langId=en_US&pagename=authenticate#manageaccount",
            "best buy": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BESTBUY&langId=en_US&pagename=authenticate#manageaccount",
            "good year": "/RSnextgen/svc/launch/index.action?siteId=PLCN_GOODYEAR&langId=en_US&pagename=authenticate#manageaccount",
            "brooks brothers": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BROOKSBROTHERS&langId=en_US&pagename=authenticate#manageaccount",
            "ford": "/RSnextgen/svc/launch/index.action?siteId=PLCN_SERVICE&langId=en_US&pagename=authenticate#manageaccount",
            "quick lane": "/RSnextgen/svc/launch/index.action?siteId=PLCN_SERVICE&langId=en_US&pagename=authenticate#manageaccount",
            "lincoln": "/RSnextgen/svc/launch/index.action?siteId=PLCN_LINCOLNSERVICES&langId=en_US&pagename=authenticate#manageaccount",
            "shell": "/RSnextgen/svc/launch/index.action?siteId=PLOC_SHELL&langId=en_US&pagename=authenticate#manageaccount",
            "sunoco": "/RSnextgen/svc/launch/index.action?siteId=PLOC_SUNOCO&langId=en_US&pagename=authenticate#manageaccount",
            "exxonmobil": "/RSnextgen/svc/launch/index.action?siteId=PLOC_EXXONMOBIL&langId=en_US&pagename=authenticate#manageaccount",
            "american airlines": "/RSnextgen/svc/launch/index.action?siteId=PLCN_AMERICAN&langId=en_US&pagename=authenticate#manageaccount",
            "brand source": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BRANDSOURCE&langId=en_US&pagename=authenticate#manageaccount",
            "tractor supply": "/RSnextgen/svc/launch/index.action?siteId=PLCN_TRACTORSUPPLY&langId=en_US&pagename=authenticate#manageaccount",
            "ross simons-sidney thomas": "/RSnextgen/svc/launch/index.action?siteId=PLCN_JEWELRY&langId=en_US&pagename=authenticate#manageaccount",
            "jewelers reserve": "/RSnextgen/svc/launch/index.action?siteId=PLCN_JEWELRY&langId=en_US&pagename=authenticate#manageaccount",
            "staples": "/RSnextgen/svc/launch/index.action?siteId=PLCN_STAPLES&langId=en_US&pagename=authenticate#manageaccount",
            "office depot": "/RSnextgen/svc/launch/index.action?siteId=PLCN_OFFICEDEPOT&langId=en_US&pagename=authenticate#manageaccount",
            "wawa": "/RSnextgen/svc/launch/index.action?siteId=PLOC_WAWA&langId=en_US&pagename=authenticate#manageaccount",
            "volkswagen drive card": "/RSnextgen/svc/launch/index.action?siteId=PLCN_DRIVECARD&langId=en_US&pagename=authenticate#manageaccount",
            "service central": "/RSnextgen/svc/launch/index.action?siteId=PLCN_SERVICECENTRAL&langId=en_US&pagename=authenticate#manageaccount",
            "brp": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BRP&langId=en_US&pagename=authenticate#manageaccount",
            "toro": "/RSnextgen/svc/launch/index.action?siteId=PLCN_TORO&langId=en_US&pagename=authenticate#manageaccount",
            "honda power equipment": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HNPE&langId=en_US&pagename=authenticate#manageaccount",
            "kawasaki": "/RSnextgen/svc/launch/index.action?siteId=PLCN_KAWA&langId=en_US&pagename=authenticate#manageaccount",
            "honda power sports": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HNPS&langId=en_US&pagename=authenticate#manageaccount",
            "macys": "/RSnextgen/svc/launch/index.action?siteId=PLCN_MACYS&langId=en_US&pagename=authenticate#manageaccount",
            "bloomingdales": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BLOOMINGDALES&langId=en_US&pagename=authenticate#manageaccount",
            "costco": "/RSnextgen/svc/launch/index.action?siteId=PLCN_COSTCO&langId=en_US&pagename=authenticate#manageaccount",
            "home furnishings": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HOME&langId=en_US&pagename=authenticate#manageaccount",
            "consumer electronics and appliances": "/RSnextgen/svc/launch/index.action?siteId=PLCN_ELECAPPL&langId=en_US&pagename=authenticate#manageaccount",
            "llbean": "docs.llbeanmastercard.com",
            "cat": "/RSnextgen/svc/launch/index.action?siteId=PLCN_CAT&langId=en_US&pagename=authenticate#manageaccount",
            "meijer": "docs.meijer.accountonline.com"
        },
        commercial: {
            crc: {
                toro: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_TORO#pro/manageacct",
                cnhi: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_CNHI#pro/manageacct",
                "tractor supply": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_TRACTORSUPPLY#pro/manageacct",
                thd: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_HOMEDEPOT#pro/manageacct",
                staples: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_STAPLES#pro/manageacct",
                "honda power equipment": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_HNPE#pro/manageacct",
                cat: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_Cat#pro/manageacct",
                "office depot": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_OFFICEDEPOT#pro/manageacct"
            },
            prox: {
                thd: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_HOMEDEPOT#pro/manageacct",
                staples: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_Staples#pro/manageacct",
                cat: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_CAT#pro/manageacct",
                "office depot": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_Officedepot#pro/manageacct"
            },
            fleet: {
                exxon: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLOF_EXXONMOBIL#pro/manageacct",
                sunoco: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLOF_SUNOCO#pro/manageacct"
            }
        }
    },
    alert: {
        consumer: {
            "sears": "alerts.searscard.com",
            "thd": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HOMEDEPOT&langId=en_US&pagename=authenticate#citialert",
            "best buy": "alerts.bestbuy.accountonline.com",
            "good year": "/RSnextgen/svc/launch/index.action?siteId=PLCN_GOODYEAR&langId=en_US&pagename=authenticate#citialert",
            "brooks brothers": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BROOKSBROTHERS&langId=en_US&pagename=authenticate#citialert",
            "ford": "/RSnextgen/svc/launch/index.action?siteId=PLCN_SERVICE&langId=en_US&pagename=authenticate#citialert",
            "quick lane": "/RSnextgen/svc/launch/index.action?siteId=PLCN_SERVICE&langId=en_US&pagename=authenticate#citialert",
            "lincoln": "/RSnextgen/svc/launch/index.action?siteId=PLCN_LINCOLNSERVICES&langId=en_US&pagename=authenticate#citialert",
            "shell": "/RSnextgen/svc/launch/index.action?siteId=PLOC_SHELL&langId=en_US&pagename=authenticate#citialert",
            "sunoco": "/RSnextgen/svc/launch/index.action?siteId=PLOC_SUNOCO&langId=en_US&pagename=authenticate#citialert",
            "exxonmobil": "/RSnextgen/svc/launch/index.action?siteId=PLOC_EXXONMOBIL&langId=en_US&pagename=authenticate#citialert",
            "american airlines": "/RSnextgen/svc/launch/index.action?siteId=PLCN_AMERICAN&langId=en_US&pagename=authenticate#citialert",
            "brand source": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BRANDSOURCE&langId=en_US&pagename=authenticate#citialert",
            "tractor supply": "/RSnextgen/svc/launch/index.action?siteId=PLCN_TRACTORSUPPLY&langId=en_US&pagename=authenticate#citialert",
            "ross simons-sidney thomas": "/RSnextgen/svc/launch/index.action?siteId=PLCN_JEWELRY&langId=en_US&pagename=authenticate#citialert",
            "jewelers reserve": "/RSnextgen/svc/launch/index.action?siteId=PLCN_JEWELRY&langId=en_US&pagename=authenticate#citialert",
            "staples": "/RSnextgen/svc/launch/index.action?siteId=PLCN_STAPLES&langId=en_US&pagename=authenticate#citialert",
            "office depot": "/RSnextgen/svc/launch/index.action?siteId=PLCN_OFFICEDEPOT&langId=en_US&pagename=authenticate#citialert",
            "wawa": "/RSnextgen/svc/launch/index.action?siteId=PLOC_WAWA&langId=en_US&pagename=authenticate#citialert",
            "volkswagen drive card": "/RSnextgen/svc/launch/index.action?siteId=PLCN_DRIVECARD&langId=en_US&pagename=authenticate#citialert",
            "service central": "/RSnextgen/svc/launch/index.action?siteId=PLCN_SERVICECENTRAL&langId=en_US&pagename=authenticate#citialert",
            "brp": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BRP&langId=en_US&pagename=authenticate#citialert",
            "toro": "/RSnextgen/svc/launch/index.action?siteId=PLCN_TORO&langId=en_US&pagename=authenticate#citialert",
            "honda power equipment": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HNPE&langId=en_US&pagename=authenticate#citialert",
            "kawasaki": "/RSnextgen/svc/launch/index.action?siteId=PLCN_KAWA&langId=en_US&pagename=authenticate#citialert",
            "honda power sports": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HNPS&langId=en_US&pagename=authenticate#citialert",
            "macys": "/RSnextgen/svc/launch/index.action?siteId=PLCN_MACYS&langId=en_US&pagename=authenticate#citialert",
            "bloomingdales": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BLOOMINGDALES&langId=en_US&pagename=authenticate#citialert",
            "costco": "/RSnextgen/svc/launch/index.action?siteId=PLCN_COSTCO&langId=en_US&pagename=authenticate#citialert",
            "home furnishings": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HOME&langId=en_US&pagename=authenticate#citialert",
            "consumer electronics and appliances": "/RSnextgen/svc/launch/index.action?siteId=PLCN_ELECAPPL&langId=en_US&pagename=authenticate#citialert",
            "llbean": "alerts.llbeanmastercard.com",
            "cat": "/RSnextgen/svc/launch/index.action?siteId=PLCN_CAT&langId=en_US&pagename=authenticate#citialert",
            "meijer": "alerts.meijer.accountonline.com"
        },
        commercial: {
            crc: {
                toro: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_TORO#pro/managealert",
                cnhi: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_CNHI#pro/managealert",
                "tractor supply": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_TRACTORSUPPLY#pro/managealert",
                thd: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_HOMEDEPOT#pro/managealert",
                staples: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_STAPLES#pro/managealert",
                "honda power equipment": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_HNPE#pro/managealert",
                cat: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_Cat#pro/managealert",
                "office depot": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_OFFICEDEPOT#pro/managealert"
            },
            prox: {
                thd: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_HOMEDEPOT#pro/managealert",
                staples: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_Staples#pro/managealert",
                cat: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_CAT#pro/managealert",
                "office depot": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_Officedepot#pro/managealert"
            },
            fleet: {
                exxon: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLOF_EXXONMOBIL#pro/managealert",
                sunoco: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLOF_SUNOCO#pro/managealert"
            }
        }
    },
    makePaymentOptions: {
        consumer: {
            "sears": "pay.searscard.com",
            "thd": "pay.homedepotconsumer.accountonline.com",
            "best buy": "pay.bestbuy.accountonline.com",
            "good year": "/RSnextgen/svc/launch/index.action?siteId=PLCN_GOODYEAR&langId=en_US&pagename=authenticate#makepaymentoptions",
            "brooks brothers": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BROOKSBROTHERS&langId=en_US&pagename=authenticate#makepaymentoptions",
            "ford": "/RSnextgen/svc/launch/index.action?siteId=PLCN_SERVICE&langId=en_US&pagename=authenticate#makepaymentoptions",
            "quick lane": "/RSnextgen/svc/launch/index.action?siteId=PLCN_SERVICE&langId=en_US&pagename=authenticate#makepaymentoptions",
            "lincoln": "/RSnextgen/svc/launch/index.action?siteId=PLCN_LINCOLNSERVICES&langId=en_US&pagename=authenticate#makepaymentoptions",
            "shell": "/RSnextgen/svc/launch/index.action?siteId=PLOC_SHELL&langId=en_US&pagename=authenticate#makepaymentoptions",
            "sunoco": "/RSnextgen/svc/launch/index.action?siteId=PLOC_SUNOCO&langId=en_US&pagename=authenticate#makepaymentoptions",
            "exxonmobil": "/RSnextgen/svc/launch/index.action?siteId=PLOC_EXXONMOBIL&langId=en_US&pagename=authenticate#makepaymentoptions",
            "american airlines": "/RSnextgen/svc/launch/index.action?siteId=PLCN_AMERICAN&langId=en_US&pagename=authenticate#makepaymentoptions",
            "brand source": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BRANDSOURCE&langId=en_US&pagename=authenticate#makepaymentoptions",
            "tractor supply": "/RSnextgen/svc/launch/index.action?siteId=PLCN_TRACTORSUPPLY&langId=en_US&pagename=authenticate#makepaymentoptions",
            "ross simons-sidney thomas": "/RSnextgen/svc/launch/index.action?siteId=PLCN_JEWELRY&langId=en_US&pagename=authenticate#makepaymentoptions",
            "jewelers reserve": "/RSnextgen/svc/launch/index.action?siteId=PLCN_JEWELRY&langId=en_US&pagename=authenticate#makepaymentoptions",
            "staples": "/RSnextgen/svc/launch/index.action?siteId=PLCN_STAPLES&langId=en_US&pagename=authenticate#makepaymentoptions",
            "office depot": "/RSnextgen/svc/launch/index.action?siteId=PLCN_OFFICEDEPOT&langId=en_US&pagename=authenticate#makepaymentoptions",
            "wawa": "/RSnextgen/svc/launch/index.action?siteId=PLOC_WAWA&langId=en_US&pagename=authenticate#makepaymentoptions",
            "volkswagen drive card": "/RSnextgen/svc/launch/index.action?siteId=PLCN_DRIVECARD&langId=en_US&pagename=authenticate#makepaymentoptions",
            "service central": "/RSnextgen/svc/launch/index.action?siteId=PLCN_SERVICECENTRAL&langId=en_US&pagename=authenticate#makepaymentoptions",
            "brp": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BRP&langId=en_US&pagename=authenticate#makepaymentoptions",
            "toro": "/RSnextgen/svc/launch/index.action?siteId=PLCN_TORO&langId=en_US&pagename=authenticate#makepaymentoptions",
            "honda power equipment": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HNPE&langId=en_US&pagename=authenticate#makepaymentoptions",
            "kawasaki": "/RSnextgen/svc/launch/index.action?siteId=PLCN_KAWA&langId=en_US&pagename=authenticate#makepaymentoptions",
            "honda power sports": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HNPS&langId=en_US&pagename=authenticate#makepaymentoptions",
            "macys": "/RSnextgen/svc/launch/index.action?siteId=PLCN_MACYS&langId=en_US&pagename=authenticate#makepaymentoptions",
            "bloomingdales": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BLOOMINGDALES&langId=en_US&pagename=authenticate#makepaymentoptions",
            "costco": "/RSnextgen/svc/launch/index.action?siteId=PLCN_COSTCO&langId=en_US&pagename=authenticate#makepaymentoptions",
            "home furnishings": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HOME&langId=en_US&pagename=authenticate#makepaymentoptions",
            "consumer electronics and appliances": "/RSnextgen/svc/launch/index.action?siteId=PLCN_ELECAPPL&langId=en_US&pagename=authenticate#makepaymentoptions",
            "llbean": "pay.llbeanmastercard.com",
            "cat": "/RSnextgen/svc/launch/index.action?siteId=PLCN_CAT&langId=en_US&pagename=authenticate#makepaymentoptions"
        },
        commercial: {
            crc: {},
            prox: {},
            fleet: {}
        }
    },
    SignOn: {
        consumer: {
            "sears": "mycard.searscard.com",
            "thd": "pay.homedepotconsumer.accountonline.com",
            "best buy": "homedepotconsumer.accountonline.com",
            "good year": "/RSnextgen/svc/launch/index.action?langId=en_US&siteId=PLCN_GOODYEAR#signon",
            "brooks brothers": "/RSnextgen/svc/launch/index.action?langId=en_US&siteId=PLCN_BROOKSBROTHERS#signon",
            "ford": "/RSnextgen/svc/launch/index.action?langId=en_US&siteId=PLCN_SERVICE#signon",
            "quick lane": "/RSnextgen/svc/launch/index.action?langId=en_US&siteId=PLCN_SERVICE#signon",
            "lincoln": "/RSnextgen/svc/launch/index.action?langId=en_US&siteId=PLCN_LINCOLNSERVICES#signon",
            "shell": "/RSnextgen/svc/launch/index.action?langId=en_US&siteId=PLOC_SHELL#signon",
            "sunoco": "/RSnextgen/svc/launch/index.action?langId=en_US&siteId=PLOC_SUNOCO#signon",
            "exxonmobil": "/RSnextgen/svc/launch/index.action?langId=en_US&siteId=PLOC_EXXONMOBIL#signon",
            "american airlines": "/RSnextgen/svc/launch/index.action?langId=en_US&siteId=PLCN_AMERICAN#signon",
            "brand source": "/RSnextgen/svc/launch/index.action?langId=en_US&siteId=PLCN_BRANDSOURCE#signon",
            "tractor supply": "/RSnextgen/svc/launch/index.action?langId=en_US&siteId=PLCN_TRACTORSUPPLY#signon",
            "ross simons-sidney thomas": "/RSnextgen/svc/launch/index.action?langId=en_US&siteId=PLCN_JEWELRY#signon",
            "jewelers reserve": "/RSnextgen/svc/launch/index.action?langId=en_US&siteId=PLCN_JEWELRY#signon",
            "staples": "/RSnextgen/svc/launch/index.action?langId=en_US&siteId=PLCN_STAPLES#signon",
            "office depot": "/RSnextgen/svc/launch/index.action?langId=en_US&siteId=PLCN_OFFICEDEPOT#signon",
            "wawa": "/RSnextgen/svc/launch/index.action?langId=en_US&siteId=PLOC_WAWA#signon",
            "volkswagen drive card": "/RSnextgen/svc/launch/index.action?langId=en_US&siteId=PLCN_DRIVECARD#signon",
            "service central": "/RSnextgen/svc/launch/index.action?langId=en_US&siteId=PLCN_SERVICECENTRAL#signon",
            "brp": "/RSnextgen/svc/launch/index.action?langId=en_US&siteId=PLCN_BRP#signon",
            "toro": "/RSnextgen/svc/launch/index.action?langId=en_US&siteId=PLCN_TORO#signon",
            "honda power equipment": "/RSnextgen/svc/launch/index.action?langId=en_US&siteId=PLCN_HNPE#signon",
            "kawasaki": "/RSnextgen/svc/launch/index.action?langId=en_US&siteId=PLCN_KAWA#signon",
            "honda power sports": "/RSnextgen/svc/launch/index.action?langId=en_US&siteId=PLCN_HNPS#signon",
            "macys": "/RSnextgen/svc/launch/index.action?siteId=PLCN_MACYS&langId=en_US&pagename=authenticate#dashboard",
            "bloomingdales": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BLOOMINGDALES&langId=en_US&pagename=authenticate#dashboard",
            "costco": "/RSnextgen/svc/launch/index.action?langId=en_US&siteId=PLCN_COSTCO#signon",
            "home furnishings": "/RSnextgen/svc/launch/index.action?langId=en_US&siteId=PLCN_HOME#signon",
            "consumer electronics and appliances": "/RSnextgen/svc/launch/index.action?langId=en_US&siteId=PLCN_ELECAPPL#signon",
            "llbean": "llbeanmastercard.com",
            "cat": "/RSnextgen/svc/launch/index.action?langId=en_US&siteId=PLCN_CAT#signon",
            "meijer": "meijer.accountonline.com"
        },
        commercial: {
            crc: {
                toro: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_TORO#SignOn",
                cnhi: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_CNHI#SignOn",
                "tractor supply": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_TRACTORSUPPLY",
                thd: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_HOMEDEPOT#SignOn",
                staples: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_STAPLES",
                "honda power equipment": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_HNPE#SignOn",
                cat: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_Cat#SignOn",
                "office depot": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_OFFICEDEPOT#SignOn"
            },
            prox: {
                thd: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_HOMEDEPOT#SignOn",
                staples: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_Staples#SignOn",
                cat: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_CAT#SignOn",
                "office depot": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_Officedepot#SignOn"
            },
            fleet: {
                exxon: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLOF_EXXONMOBIL",
                sunoco: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLOF_SUNOCO"
            }
        }
    },
    ResetPwd: {
        consumer: {
            "sears": "reset.searscard.com",
            "thd": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HOMEDEPOT&langId=en_US&pagename=signon#reset",
            "best buy": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BESTBUY&langId=en_US&pagename=signon#reset",
            "good year": "/RSnextgen/svc/launch/index.action?siteId=PLCN_GOODYEAR&langId=en_US&pagename=signon#reset",
            "brooks brothers": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BROOKSBROTHERS&langId=en_US&pagename=signon#reset",
            "ford": "/RSnextgen/svc/launch/index.action?siteId=PLCN_SERVICE&langId=en_US&pagename=signon#reset",
            "quick lane": "/RSnextgen/svc/launch/index.action?siteId=PLCN_SERVICE&langId=en_US&pagename=signon#reset",
            "lincoln": "/RSnextgen/svc/launch/index.action?siteId=PLCN_LINCOLNSERVICES&langId=en_US&pagename=signon#reset",
            "shell": "/RSnextgen/svc/launch/index.action?siteId=PLOC_SHELL&langId=en_US&pagename=signon#reset",
            "sunoco": "/RSnextgen/svc/launch/index.action?siteId=PLOC_SUNOCO&langId=en_US&pagename=signon#reset",
            "exxonmobil": "/RSnextgen/svc/launch/index.action?siteId=PLOC_EXXONMOBIL&langId=en_US&pagename=signon#reset",
            "american airlines": "/RSnextgen/svc/launch/index.action?siteId=PLCN_AMERICAN&langId=en_US&pagename=signon#reset",
            "brand source": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BRANDSOURCE&langId=en_US&pagename=signon#reset",
            "tractor supply": "/RSnextgen/svc/launch/index.action?siteId=PLCN_TRACTORSUPPLY&langId=en_US&pagename=signon#reset",
            "ross simons-sidney thomas": "/RSnextgen/svc/launch/index.action?siteId=PLCN_JEWELRY&langId=en_US&pagename=signon#reset",
            "jewelers reserve": "/RSnextgen/svc/launch/index.action?siteId=PLCN_JEWELRY&langId=en_US&pagename=signon#reset",
            "staples": "/RSnextgen/svc/launch/index.action?siteId=PLCN_STAPLES&langId=en_US&pagename=signon#reset",
            "office depot": "/RSnextgen/svc/launch/index.action?siteId=PLCN_OFFICEDEPOT&langId=en_US&pagename=signon#reset",
            "wawa": "/RSnextgen/svc/launch/index.action?siteId=PLOC_WAWA&langId=en_US&pagename=signon#reset",
            "volkswagen drive card": "/RSnextgen/svc/launch/index.action?siteId=PLCN_DRIVECARD&langId=en_US&pagename=signon#reset",
            "service central": "/RSnextgen/svc/launch/index.action?siteId=PLCN_SERVICECENTRAL&langId=en_US&pagename=signon#reset",
            "brp": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BRP&langId=en_US&pagename=signon#reset",
            "toro": "/RSnextgen/svc/launch/index.action?siteId=PLCN_TORO&langId=en_US&pagename=signon#reset",
            "honda power equipment": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HNPE&langId=en_US&pagename=signon#reset",
            "kawasaki": "/RSnextgen/svc/launch/index.action?siteId=PLCN_KAWA&langId=en_US&pagename=signon#reset",
            "honda power sports": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HNPS&langId=en_US&pagename=signon#reset",
            "macys": "/RSnextgen/svc/launch/index.action?siteId=PLCN_MACYS&langId=en_US&pagename=authenticate#reset",
            "bloomingdales": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BLOOMINGDALES&langId=en_US&pagename=authenticate#reset",
            "costco": "/RSnextgen/svc/launch/index.action?siteId=PLCN_COSTCO&langId=en_US&pagename=signon#reset",
            "home furnishings": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HOME&langId=en_US&pagename=signon#reset",
            "consumer electronics and appliances": "/RSnextgen/svc/launch/index.action?siteId=PLCN_ELECAPPL&langId=en_US&pagename=signon#reset",
            "llbean": "reset.llbeanmastercard.com",
            "cat": "/RSnextgen/svc/launch/index.action?siteId=PLCN_CAT&langId=en_US&pagename=signon#reset",
            "meijer": "reset.meijer.accountonline.com"
        },
        commercial: {
            crc: {
                toro: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_TORO#pro/retpwd",
                cnhi: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_CNHI#pro/retpwd",
                "tractor supply": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_TRACTORSUPPLY#pro/retpwd",
                thd: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_HOMEDEPOT#pro/retpwd",
                staples: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_STAPLES#pro/retpwd",
                "honda power equipment": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_HNPE#pro/retpwd",
                cat: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_Cat#pro/retpwd",
                "office depot": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_OFFICEDEPOT#pro/retpwd"
            },
            prox: {
                thd: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_HOMEDEPOT#pro/retpwd",
                staples: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_Staples#pro/retpwd",
                cat: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_CAT#pro/retpwd",
                "office depot": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_Officedepot#pro/retpwd"
            },
            fleet: {
                exxon: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLOF_EXXONMOBIL#pro/retpwd",
                sunoco: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLOF_SUNOCO#pro/retpwd"
            }
        }
    },
    profile: {
        consumer: {
            "sears": "docs.searscard.com",
            "thd": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HOMEDEPOT&langId=en_US&pagename=authenticate#profile",
            "best buy": "docs.bestbuy.accountonline.com",
            "good year": "/RSnextgen/svc/launch/index.action?siteId=PLCN_GOODYEAR&langId=en_US&pagename=authenticate#profile",
            "brooks brothers": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BROOKSBROTHERS&langId=en_US&pagename=authenticate#profile",
            "ford": "/RSnextgen/svc/launch/index.action?siteId=PLCN_SERVICE&langId=en_US&pagename=authenticate#profile",
            "quick lane": "/RSnextgen/svc/launch/index.action?siteId=PLCN_SERVICE&langId=en_US&pagename=authenticate#profile",
            "lincoln": "/RSnextgen/svc/launch/index.action?siteId=PLCN_LINCOLNSERVICES&langId=en_US&pagename=authenticate#profile",
            "shell": "/RSnextgen/svc/launch/index.action?siteId=PLOC_SHELL&langId=en_US&pagename=authenticate#profile",
            "sunoco": "/RSnextgen/svc/launch/index.action?siteId=PLOC_SUNOCO&langId=en_US&pagename=authenticate#profile",
            "exxonmobil": "/RSnextgen/svc/launch/index.action?siteId=PLOC_EXXONMOBIL&langId=en_US&pagename=authenticate#profile",
            "american airlines": "/RSnextgen/svc/launch/index.action?siteId=PLCN_AMERICAN&langId=en_US&pagename=authenticate#profile",
            "brand source": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BRANDSOURCE&langId=en_US&pagename=authenticate#profile",
            "tractor supply": "/RSnextgen/svc/launch/index.action?siteId=PLCN_TRACTORSUPPLY&langId=en_US&pagename=authenticate#profile",
            "ross simons-sidney thomas": "/RSnextgen/svc/launch/index.action?siteId=PLCN_JEWELRY&langId=en_US&pagename=authenticate#profile",
            "jewelers reserve": "/RSnextgen/svc/launch/index.action?siteId=PLCN_JEWELRY&langId=en_US&pagename=authenticate#profile",
            "staples": "/RSnextgen/svc/launch/index.action?siteId=PLCN_STAPLES&langId=en_US&pagename=authenticate#profile",
            "office depot": "/RSnextgen/svc/launch/index.action?siteId=PLCN_OFFICEDEPOT&langId=en_US&pagename=authenticate#profile",
            "wawa": "/RSnextgen/svc/launch/index.action?siteId=PLOC_WAWA&langId=en_US&pagename=authenticate#profile",
            "volkswagen drive card": "/RSnextgen/svc/launch/index.action?siteId=PLCN_DRIVECARD&langId=en_US&pagename=authenticate#profile",
            "service central": "/RSnextgen/svc/launch/index.action?siteId=PLCN_SERVICECENTRAL&langId=en_US&pagename=authenticate#profile",
            "brp": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BRP&langId=en_US&pagename=authenticate#profile",
            "toro": "/RSnextgen/svc/launch/index.action?siteId=PLCN_TORO&langId=en_US&pagename=authenticate#profile",
            "honda power equipment": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HNPE&langId=en_US&pagename=authenticate#profile",
            "kawasaki": "/RSnextgen/svc/launch/index.action?siteId=PLCN_KAWA&langId=en_US&pagename=authenticate#profile",
            "honda power sports": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HNPS&langId=en_US&pagename=authenticate#profile",
            "macys": "/RSnextgen/svc/launch/index.action?siteId=PLCN_MACYS&langId=en_US&pagename=authenticate#profile",
            "bloomingdales": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BLOOMINGDALES&langId=en_US&pagename=authenticate#profile",
            "costco": "/RSnextgen/svc/launch/index.action?siteId=PLCN_COSTCO&langId=en_US&pagename=authenticate#profile",
            "home furnishings": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HOME&langId=en_US&pagename=authenticate#profile",
            "consumer electronics and appliances": "/RSnextgen/svc/launch/index.action?siteId=PLCN_ELECAPPL&langId=en_US&pagename=authenticate#profile",
            "llbean": "/RSnextgen/svc/launch/index.action?siteId=PLCN_LLBEAN&langId=en_US&pagename=authenticate#profile",
            "cat": "/RSnextgen/svc/launch/index.action?siteId=PLCN_CAT&langId=en_US&pagename=authenticate#profile"
        },
        commercial: {
            crc: {
                toro: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_TORO#pro/profile",
                cnhi: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_CNHI#pro/profile",
                "tractor supply": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_TRACTORSUPPLY#pro/profile",
                thd: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_HOMEDEPOT#pro/profile",
                staples: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_STAPLES#pro/profile",
                "honda power equipment": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_HNPE#pro/profile",
                cat: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_Cat#pro/profile",
                "office depot": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_OFFICEDEPOT#pro/profile"
            },
            prox: {
                thd: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_HOMEDEPOT#pro/profile",
                staples: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_Staples#pro/profile",
                cat: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_CAT#pro/profile",
                "office depot": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_Officedepot#pro/profile"
            },
            fleet: {
                exxon: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLOF_EXXONMOBIL#pro/profile",
                sunoco: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLOF_SUNOCO#pro/profile"
            }
        }
    },
    statements: {
        consumer: {
            "sears": "docs.searscard.com",
            "thd": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HOMEDEPOT&langId=en_US&pagename=authenticate#statements",
            "best buy": "docs.bestbuy.accountonline.com",
            "good year": "/RSnextgen/svc/launch/index.action?siteId=PLCN_GOODYEAR&langId=en_US&pagename=authenticate#statements",
            "brooks brothers": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BROOKSBROTHERS&langId=en_US&pagename=authenticate#statements",
            "ford": "/RSnextgen/svc/launch/index.action?siteId=PLCN_SERVICE&langId=en_US&pagename=authenticate#statements",
            "quick lane": "/RSnextgen/svc/launch/index.action?siteId=PLCN_SERVICE&langId=en_US&pagename=authenticate#statements",
            "lincoln": "/RSnextgen/svc/launch/index.action?siteId=PLCN_LINCOLNSERVICES&langId=en_US&pagename=authenticate#statements",
            "shell": "/RSnextgen/svc/launch/index.action?siteId=PLOC_SHELL&langId=en_US&pagename=authenticate#statements",
            "sunoco": "/RSnextgen/svc/launch/index.action?siteId=PLOC_SUNOCO&langId=en_US&pagename=authenticate#statements",
            "exxonmobil": "/RSnextgen/svc/launch/index.action?siteId=PLOC_EXXONMOBIL&langId=en_US&pagename=authenticate#statements",
            "american airlines": "/RSnextgen/svc/launch/index.action?siteId=PLCN_AMERICAN&langId=en_US&pagename=authenticate#statements",
            "brand source": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BRANDSOURCE&langId=en_US&pagename=authenticate#statements",
            "tractor supply": "/RSnextgen/svc/launch/index.action?siteId=PLCN_TRACTORSUPPLY&langId=en_US&pagename=authenticate#statements",
            "ross simons-sidney thomas": "/RSnextgen/svc/launch/index.action?siteId=PLCN_JEWELRY&langId=en_US&pagename=authenticate#statements",
            "jewelers reserve": "/RSnextgen/svc/launch/index.action?siteId=PLCN_JEWELRY&langId=en_US&pagename=authenticate#statements",
            "staples": "/RSnextgen/svc/launch/index.action?siteId=PLCN_STAPLES&langId=en_US&pagename=authenticate#statements",
            "office depot": "/RSnextgen/svc/launch/index.action?siteId=PLCN_OFFICEDEPOT&langId=en_US&pagename=authenticate#statements",
            "wawa": "/RSnextgen/svc/launch/index.action?siteId=PLOC_WAWA&langId=en_US&pagename=authenticate#statements",
            "volkswagen drive card": "/RSnextgen/svc/launch/index.action?siteId=PLCN_DRIVECARD&langId=en_US&pagename=authenticate#statements",
            "service central": "/RSnextgen/svc/launch/index.action?siteId=PLCN_SERVICECENTRAL&langId=en_US&pagename=authenticate#statements",
            "brp": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BRP&langId=en_US&pagename=authenticate#statements",
            "toro": "/RSnextgen/svc/launch/index.action?siteId=PLCN_TORO&langId=en_US&pagename=authenticate#statements",
            "honda power equipment": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HNPE&langId=en_US&pagename=authenticate#statements",
            "kawasaki": "/RSnextgen/svc/launch/index.action?siteId=PLCN_KAWA&langId=en_US&pagename=authenticate#statements",
            "honda power sports": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HNPS&langId=en_US&pagename=authenticate#statements",
            "macys": "/RSnextgen/svc/launch/index.action?siteId=PLCN_MACYS&langId=en_US&pagename=authenticate#statements",
            "bloomingdales": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BLOOMINGDALES&langId=en_US&pagename=authenticate#statements",
            "costco": "/RSnextgen/svc/launch/index.action?siteId=PLCN_COSTCO&langId=en_US&pagename=authenticate#statements",
            "home furnishings": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HOME&langId=en_US&pagename=authenticate#statements",
            "consumer electronics and appliances": "/RSnextgen/svc/launch/index.action?siteId=PLCN_ELECAPPL&langId=en_US&pagename=authenticate#statements",
            "llbean": "/RSnextgen/svc/launch/index.action?siteId=PLCN_LLBEAN&langId=en_US&pagename=authenticate#statements",
            "cat": "/RSnextgen/svc/launch/index.action?siteId=PLCN_CAT&langId=en_US&pagename=authenticate#statements"
        },
        commercial: {
            crc: {
                toro: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_TORO#stmt/statements",
                cnhi: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_CNHI#stmt/statements",
                "tractor supply": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_TRACTORSUPPLY#stmt/statements",
                thd: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_HOMEDEPOT#stmt/statements",
                staples: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_STAPLES#stmt/statements",
                "honda power equipment": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_HNPE#stmt/statements",
                cat: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_Cat#stmt/statements",
                "office depot": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_OFFICEDEPOT#stmt/statements"
            },
            prox: {
                thd: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_HOMEDEPOT#invprox/invoices",
                staples: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_Staples#invprox/invoices",
                cat: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_CAT#invprox/invoices",
                "office depot": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_Officedepot#invprox/invoices"
            },
            fleet: {
                exxon: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLOF_EXXONMOBIL#stmt/statements",
                sunoco: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLOF_SUNOCO#stmt/statements"
            }
        }
    },
    promoAllocation: {
        consumer: {
            "sears": "/RSnextgen/svc/launch/index.action?langId=en_US&siteId=SEARS&pagename=authenticate#promoAllocation",
            "thd": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HOMEDEPOT&pagename=authenticate&langId=en_US#promoAllocation",
            "best buy": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BESTBUY&langId=en_US&pagename=authenticate#promoAllocation",
            "good year": "/RSnextgen/svc/launch/index.action?siteId=PLCN_GOODYEAR&langId=en_US&pagename=authenticate#promoAllocation",
            "brooks brothers": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BROOKSBROTHERS&langId=en_US&pagename=authenticate#promoAllocation",
            "ford": "/RSnextgen/svc/launch/index.action?siteId=PLCN_SERVICE&langId=en_US&pagename=authenticate#promoAllocation",
            "quick lane": "/RSnextgen/svc/launch/index.action?siteId=PLCN_SERVICE&langId=en_US&pagename=authenticate#promoAllocation",
            "lincoln": "/RSnextgen/svc/launch/index.action?siteId=PLCN_LINCOLNSERVICES&langId=en_US&pagename=authenticate#promoAllocation",
            "shell": "/RSnextgen/svc/launch/index.action?siteId=PLOC_SHELL&langId=en_US&pagename=authenticate#promoAllocation",
            "sunoco": "/RSnextgen/svc/launch/index.action?siteId=PLOC_SUNOCO&langId=en_US&pagename=authenticate#promoAllocation",
            "exxonmobil": "/RSnextgen/svc/launch/index.action?siteId=PLOC_EXXONMOBIL&langId=en_US&pagename=authenticate#promoAllocation",
            "american airlines": "/RSnextgen/svc/launch/index.action?siteId=PLCN_AMERICAN&langId=en_US&pagename=authenticate#promoAllocation",
            "brand source": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BRANDSOURCE&langId=en_US&pagename=authenticate#promoAllocation",
            "tractor supply": "/RSnextgen/svc/launch/index.action?siteId=PLCN_TRACTORSUPPLY&langId=en_US&pagename=authenticate#promoAllocation",
            "ross simons-sidney thomas": "/RSnextgen/svc/launch/index.action?siteId=PLCN_JEWELRY&langId=en_US&pagename=authenticate#promoAllocation",
            "jewelers reserve": "/RSnextgen/svc/launch/index.action?siteId=PLCN_JEWELRY&langId=en_US&pagename=authenticate#promoAllocation",
            "staples": "/RSnextgen/svc/launch/index.action?siteId=PLCN_STAPLES&langId=en_US&pagename=authenticate#promoAllocation",
            "office depot": "/RSnextgen/svc/launch/index.action?siteId=PLCN_OFFICEDEPOT&langId=en_US&pagename=authenticate#promoAllocation",
            "wawa": "/RSnextgen/svc/launch/index.action?siteId=PLOC_WAWA&langId=en_US&pagename=authenticate#promoAllocation",
            "volkswagen drive card": "/RSnextgen/svc/launch/index.action?siteId=PLCN_DRIVECARD&langId=en_US&pagename=authenticate#promoAllocation",
            "service central": "/RSnextgen/svc/launch/index.action?siteId=PLCN_SERVICECENTRAL&langId=en_US&pagename=authenticate#promoAllocation",
            "brp": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BRP&langId=en_US&pagename=authenticate#promoAllocation",
            "toro": "/RSnextgen/svc/launch/index.action?siteId=PLCN_TORO&langId=en_US&pagename=authenticate#promoAllocation",
            "honda power equipment": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HNPE&langId=en_US&pagename=authenticate#promoAllocation",
            "kawasaki": "/RSnextgen/svc/launch/index.action?siteId=PLCN_KAWA&langId=en_US&pagename=authenticate#promoAllocation",
            "honda power sports": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HNPS&langId=en_US&pagename=authenticate#promoAllocation",
            "macys": "/RSnextgen/svc/launch/index.action?siteId=PLCN_MACYS&langId=en_US&pagename=authenticate#promoAllocation",
            "bloomingdales": "/RSnextgen/svc/launch/index.action?siteId=PLCN_BLOOMINGDALES&langId=en_US&pagename=authenticate#promoAllocation",
            "costco": "/RSnextgen/svc/launch/index.action?siteId=PLCN_COSTCO&langId=en_US&pagename=authenticate#promoAllocation",
            "home furnishings": "/RSnextgen/svc/launch/index.action?siteId=PLCN_HOME&langId=en_US&pagename=authenticate#promoAllocation",
            "consumer electronics and appliances": "/RSnextgen/svc/launch/index.action?siteId=PLCN_ELECAPPL&langId=en_US&pagename=authenticate#promoAllocation",
            "llbean": "promo.llbeanmastercard.com",
            "cat": "/RSnextgen/svc/launch/index.action?siteId=PLCN_CAT&langId=en_US&pagename=authenticate#promoAllocation"
        },
        commercial: {
            crc: {
                toro: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_TORO#pro/managealert",
                cnhi: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_CNHI#pro/managealert",
                "tractor supply": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_TRACTORSUPPLY#pro/managealert",
                thd: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_HOMEDEPOT#pro/managealert",
                staples: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_STAPLES#pro/managealert",
                "honda power equipment": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_HNPE#pro/managealert",
                cat: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_Cat#pro/managealert",
                "office depot": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLCR_OFFICEDEPOT#pro/managealert"
            },
            prox: {
                thd: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_HOMEDEPOT#pro/managealert",
                staples: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_Staples#pro/managealert",
                cat: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_CAT#pro/managealert",
                "office depot": "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLNP_Officedepot#pro/managealert"
            },
            fleet: {
                exxon: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLOF_EXXONMOBIL#pro/managealert",
                sunoco: "https://www.sit1.retailservicescommercial.citi.com/pcfdev/index.html?siteId=PLOF_SUNOCO#pro/managealert"
            }
        }
    },
    registration: {
        consumer: {
            "sears": "enroll.searscard.com",
            "thd": "activate.homedepotconsumer.accountonline.com",
            "best buy": "welcome.bestbuy.accountonline.com",
            "good year": "/RSnextgen/svc/registration/index.action?siteId=PLCN_GOODYEAR&langId=en_US#verify",
            "brooks brothers": "/RSnextgen/svc/registration/index.action?siteId=PLCN_BROOKSBROTHERS&langId=en_US#verify",
            "ford": "/RSnextgen/svc/registration/index.action?siteId=PLCN_SERVICE&langId=en_US#verify",
            "quick lane": "/RSnextgen/svc/registration/index.action?siteId=PLCN_SERVICE&langId=en_US#verify",
            "lincoln": "/RSnextgen/svc/registration/index.action?siteId=PLCN_LINCOLNSERVICES&langId=en_US#verify",
            "shell": "/RSnextgen/svc/registration/index.action?siteId=PLOC_SHELL&langId=en_US#verify",
            "sunoco": "/RSnextgen/svc/registration/index.action?siteId=PLOC_SUNOCO&langId=en_US#verify",
            "exxonmobil": "/RSnextgen/svc/registration/index.action?siteId=PLOC_EXXONMOBIL&langId=en_US#verify",
            "american airlines": "/RSnextgen/svc/registration/index.action?siteId=PLCN_AMERICAN&langId=en_US#verify",
            "brand source": "/RSnextgen/svc/registration/index.action?siteId=PLCN_BRANDSOURCE&langId=en_US#verify",
            "tractor supply": "/RSnextgen/svc/registration/index.action?siteId=PLCN_TRACTORSUPPLY&langId=en_US#verify",
            "ross simons-sidney thomas": "/RSnextgen/svc/registration/index.action?siteId=PLCN_JEWELRY&langId=en_US#verify",
            "jewelers reserve": "/RSnextgen/svc/registration/index.action?siteId=PLCN_JEWELRY&langId=en_US#verify",
            "staples": "/RSnextgen/svc/registration/index.action?siteId=PLCN_STAPLES&langId=en_US#verify",
            "office depot": "/RSnextgen/svc/registration/index.action?siteId=PLCN_OFFICEDEPOT&langId=en_US#verify",
            "wawa": "/RSnextgen/svc/registration/index.action?siteId=PLOC_WAWA&langId=en_US#verify",
            "volkswagen drive card": "/RSnextgen/svc/registration/index.action?siteId=PLCN_DRIVECARD&langId=en_US#verify",
            "service central": "/RSnextgen/svc/registration/index.action?siteId=PLCN_SERVICECENTRAL&langId=en_US#verify",
            "brp": "/RSnextgen/svc/registration/index.action?siteId=PLCN_BRP&langId=en_US#verify",
            "toro": "/RSnextgen/svc/registration/index.action?siteId=PLCN_TORO&langId=en_US#verify",
            "honda power equipment": "/RSnextgen/svc/registration/index.action?siteId=PLCN_HNPE&langId=en_US#verify",
            "kawasaki": "/RSnextgen/svc/registration/index.action?siteId=PLCN_KAWA&langId=en_US#verify",
            "honda power sports": "/RSnextgen/svc/registration/index.action?siteId=PLCN_HNPS&langId=en_US#verify",
            "macys": "/RSnextgen/svc/registration/index.action?siteId=PLCN_MACYS&langId=en_US#verify",
            "bloomingdales": "/RSnextgen/svc/registration/index.action?siteId=PLCN_BLOOMINGDALES&langId=en_US#verify",
            "costco": "/RSnextgen/svc/registration/index.action?siteId=PLCN_COSTCO&langId=en_US#verify",
            "home furnishings": "/RSnextgen/svc/registration/index.action?siteId=PLCN_HOME&langId=en_US#verify",
            "consumer electronics and appliances": "/RSnextgen/svc/registration/index.action?siteId=PLCN_ELECAPPL&langId=en_US#verify",
            "llbean": "enroll.llbeanmastercard.com",
            "cat": "/RSnextgen/svc/registration/index.action?siteId=PLCN_CAT&langId=en_US#verify",
            "meijer": "welcome.meijer.accountonline.com"
        },
        commercial: {
            crc: {
                toro: "https://www.retailservicescommercial.citi.com/USCRSF/CMLSVC/index.html?siteId=PLCR_TORO#pro/reg",
                cnhi: "https://www.retailservicescommercial.citi.com/USCRSF/CMLSVC/index.html?siteId=PLCR_CNHI#pro/reg",
                "tractor supply": "https://www.retailservicescommercial.citi.com/USCRSF/CMLSVC/index.html?siteId=PLCR_TRACTORSUPPLY#pro/reg",
                thd: "https://www.retailservicescommercial.citi.com/USCRSF/CMLSVC/index.html?siteId=PLCR_HOMEDEPOT#pro/reg",
                staples: "https://www.retailservicescommercial.citi.com/USCRSF/CMLSVC/index.html?siteId=PLCR_STAPLES#pro/reg",
                "honda power equipment": "https://www.retailservicescommercial.citi.com/USCRSF/CMLSVC/index.html?siteId=PLCR_HNPE#pro/reg",
                cat: "https://www.retailservicescommercial.citi.com/USCRSF/CMLSVC/index.html?siteId=PLCR_Cat#pro/reg",
                "office depot": "https://www.retailservicescommercial.citi.com/USCRSF/CMLSVC/index.html?siteId=PLCR_OFFICEDEPOT#pro/reg"
            },
            prox: {
                thd: "https://www.retailservicescommercial.citi.com/USCRSF/CMLSVC/index.html?siteId=PLNP_HOMEDEPOT#pro/reg",
                staples: "https://www.retailservicescommercial.citi.com/USCRSF/CMLSVC/index.html?siteId=PLNP_Staples#pro/reg",
                cat: "https://www.retailservicescommercial.citi.com/USCRSF/CMLSVC/index.html?siteId=PLNP_CAT#pro/reg",
                "office depot": "https://www.retailservicescommercial.citi.com/USCRSF/CMLSVC/index.html?siteId=PLNP_Officedepot#pro/reg"
            },
            fleet: {
                exxon: "https://www.retailservicescommercial.citi.com/USCRSF/CMLSVC/index.html?siteId=PLOF_EXXONMOBIL#pro/reg",
                sunoco: "https://www.retailservicescommercial.citi.com/USCRSF/CMLSVC/index.html?siteId=PLOF_SUNOCO#pro/reg"
            }
        }
    }
}

function getUrl(task) {
    // console.log('this is the link :'+ all_urls[task][type][brand][partner])  toLowerCase()
    var type, brand, partner, task = task;
    if (context.session.BotUserSession.lastMessage.channel == 'ivr') { //SMS CHANNEL
        // var type = context.session.BotUserSession.channels[0].botInfo.customData.type,
        type = "consumer",
            //brand = context.session.BotUserSession.lastMessage.messagePayload.brand,
            partner = context.session.BotUserSession.lastMessage.messagePayload.siteId;
        if (partner === "PLCN_HOMEDEPOT") {
            partner = "thd";
        } else if (partner === "PLCN_BESTBUY") {
            partner = "best buy";
        } else if (partner === "SEARS") {
            partner = "sears";
        } else {
            partner = "thd";
        }
        if (partner == 'tire kingdom' || partner == 'merchant\'s tire' || partner == 'ntb' || partner == 'big o tires') partner = 'service central';
        if (partner == 'max') partner = 'office depot';
        if (type == 'consumer') {
            // return "https://dit08.mobile.citibank.com" + sms_urls[task][type][partner]
            var sms_get_url = sms_urls[task][type][partner];
            if (sms_get_url && sms_get_url.indexOf(".com") > -1) return sms_urls[task][type][partner];
            else return "https://uat10.mobile.citibank.com" + sms_urls[task][type][partner];
        } else return all_urls[task][type][brand][partner]
    } else if (context.session.BotUserSession.lastMessage.channel == 'rtm') { //WEB CHANNEL
        var getCustomerData = getCustomerType();
        //console.log("Retrieved Secure Data : ", getCustomerData);
        if (getCustomerData.partner == 'tire kingdom' || getCustomerData.partner == 'merchant\'s tire' || getCustomerData.partner == 'ntb' || getCustomerData.partner == 'big o tires') getCustomerData.partner = 'service central';
        else if (getCustomerData.partner == 'max') getCustomerData.partner = 'office depot';
        else getCustomerData.partner = getCustomerData.partner;
        if (getCustomerData.type == 'consumer') {
            //console.log("getUrl : ",task,getCustomerData.type,getCustomerData.partner);
            return all_urls[task][getCustomerData.type][getCustomerData.partner];
        } else {
            //console.log("getUrl : ",task,getCustomerData.type,getCustomerData.brand,getCustomerData.partner);
            return all_urls[task][getCustomerData.type][getCustomerData.brand][getCustomerData.partner];
        }
    } else {
        let type = "commercial";
        let partner = "thd";
        let brand = "crc"
        return all_urls[task][type][brand][partner];
    }
}

function getDefaultMessage() {
    return "Sorry, I do not have specific information on this."
}

function getShortCodes() {
    var shortCode = "";
    if (context.session.BotUserSession.lastMessage.messagePayload && context.session.BotUserSession.lastMessage.messagePayload.siteId) {
        var siteId = context.session.BotUserSession.lastMessage.messagePayload.siteId;
        if (siteId === "PLCN_HOMEDEPOT") {
            shortCode = "31748";
        } else if (siteId === "PLCN_BESTBUY") {
            shortCode = "81964";
        } else if (siteId === "SEARS") {
            shortCode = "38911";
        }
        return shortCode;
    }
}

function getCustomerType() {
    //SecureCustomData WEB channel
    try {
        if (context.session.UserContext && context.session.UserContext.secureCustomData) {
            var secureCustomData = JSON.parse(context.session.UserContext.secureCustomData);
            return {
                "type": secureCustomData.type,
                "partner": secureCustomData.partner,
                "brand": secureCustomData.brand,
                "siteId": secureCustomData.siteId,
                "fusionSid": secureCustomData.fusionSid,
                "customerFirstName": secureCustomData.customerFirstName
            }
        } else if (context.session.BotUserSession.lastMessage.channel == 'ivr') {
            customerDetails.type = context.session.BotUserSession.lastMessage.messagePayload.type;
            customerDetails.brand = context.session.BotUserSession.lastMessage.messagePayload.brand;
            customerDetails.partner = context.session.BotUserSession.lastMessage.messagePayload.partner;
            if (customerDetails && customerDetails.type && Object.keys(customerDetails).length) {
                return customerDetails;
            } else return "gotAnError from SMS"
        } else {
            if (context.session.BotUserSession.customer) {
                return {
                    "type": context.session.BotUserSession.customer,
                    "partner": context.session.BotUserSession.partner,
                    "brand": context.session.BotUserSession.brand
                }
            } else {
                return {
                    "type": "consumer",
                    "partner": "thd"
                }
            }
        }
    } catch (Err) {
        return {
            "type": "consumer",
            "partner": "thd"
        }
    }
}

var partnerName = {
    "consumer": {
        "thd": "The Home Depot® Consumer Credit Card",
        "shell": "Shell | Fuel Rewards® Card",
        "best buy": "My Best Buy® Credit Card",
        "exxonmobil": "ExxonMobil Credit Card",
        "sears": "Sears Card®",
        "llbean": "L.L.Bean Mastercard",
        "shop your way": "Shop Your Way Mastercard®",
        "meijer": "Meijer Credit Card"
    },
    "commercial": {
        "crc": {
            "toro": "Toro-Exmark Commercial Credit Card Program",
            "cnhi": "CNH Industrial Capital Productivity Plus® Account",
            "tractor supply": "Tractor Supply Company Business Credit Account",
            "thd": "The Home Depot® Commercial Revolving Charge Card",
            "staples": "Staples® Business More Account",
            "honda power equipment": "Honda Power Equipment Commercial Credit Card",
            "cat": "Cat Commercial Revolving Account Card",
            "office depot": "Office Depot Business Credit Account"
        },
        "fleet": {
            "exxon": "ExxonMobil Business Card",
            "sunoco": "Sunoco® Corporate Card"
        },
        "prox": {
            "thd": "The Home Depot® Commercial Account",
            "staples": "Staples® Commercial More Account",
            "cat": "Cat Commercial Invoice Card",
            "office depot": "Office Depot Business Account"
        }
    }
}

function getPartnerName() {
    var type = "";
    var partner = "";
    var brand = "";
    var customerDetails = getCustomerType();
    if (customerDetails && customerDetails.partner) {
        partner = customerDetails.partner;
    }
    if (customerDetails && customerDetails.type) {
        type = customerDetails.type;
        if (type === "commercial") {
            if (customerDetails.brand) {
                brand = customerDetails.brand;
                return partnerName[type][brand][partner];
            }
            else
                return "";
        }
        else if (type === "consumer")
            return partnerName[type][partner];
        else
            return "";
    }
}

var paymentAddress = {
    "rtm": {
        "consumer": {
            "thd": "The Home Depot® Consumer Credit Card Payments\nHome Depot Credit Services\nP.O. Box 9001010\nLouisville, KY 40290-1010\n\nThe Home Depot® Consumer Credit Card Overnight Delivery/Express Payments\nAttn: Consumer Payment Dept.\n6716 Grade Lane\nBuilding 9, Suite 910\nLouisville, KY 40213",
            "sears": "Sears Consumer Payments\nP.O. Box 9001055\nLouisville, KY 40290-1055\n\nSears Consumer Express Payments\nAttn: Consumer Payment Dept.\n6716 Grade Lane\nBuilding 9, Suite 910\nLouisville, KY 40213",
            "best buy": "My Best Buy® Credit Card Payments \nP.O. Box 9001007 \nLouisville, KY 40290-1007 \n\nMy Best Buy® Credit Card Overnight Delivery/Express Payments \nAttn: Consumer Payment Dept. \n6716 Grade Lane \nBuilding 9, Suite 910 \nLouisville, KY 40213",
            "exxonmobil": "ExxonMobil \nP.O. Box 78072 \nPhoenix, AZ 85062-8072 \n\nExxonMobil Credit Card \nOvernight Delivery/Express Payments \nProcessing Center \n6716 Grade Lane \nBuilding 9, Suite 910 \nLouisville, KY 40213",
            "shell": "Shell Card Payments \nP.O. Box 9001011 \nLouisville, KY 40290-1011 \n\nShell Card Overnight Delivery/Express Payments \nAttn: Consumer Payment Dept. \n6716 Grade Lane \nBuilding 9, Suite 910 \nLouisville, KY 40213",
            "llbean": "L.L.Bean Mastercard Payments \nPO Box 9001068 \nLouisville KY 40290-1068 \n\nL.L.Bean Mastercard \nOvernight Delivery/Express Payments \nAttn: Consumer Payment Dept. \n6716 Grade Lane \nBuilding 9, Suite 910 \nLouisville, KY 40213",
            "shop your way": "Shop Your Way Credit Card Payments \nP.O. Box 78024 \nPhoenix, AZ 85062-8024 \n\nShop Your Way Credit Card \nOvernight Delivery/Express Payments \nAttn: Consumer Payment Dept. \n6716 Grade Lane \nBuilding 9, Suite 910 \nLouisville, KY 40213",
            "meijer": "Meijer Credit Card \nPO Box 9001006 \nLouisville, KY 40290-1006 \n\nMeijer Mastercard \nPO Box 9001006 \nLouisville, KY 40290-1006"
        },
        "commercial": {
            "crc": {
                "thd": "The Home Depot® Commercial Revolving Charge Card Payments\nHome Depot Credit Services\nP.O. Box 9001030\nLouisville, KY 40290-1030\n\nThe Home Depot® Commercial Revolving Charge Card\nOvernight Delivery/Express Payments\nPayments Department\n6716 Grade Lane\nBuilding 9, Suite 910\nLouisville, KY 40213",
                "staples": "Staples® Business More Account\nPayments\nPO Box 78004\nPhoenix, AZ 85062-8004\n\nStaples® Business More Account\nOvernight Delivery/Express Payments\n1820 E Sky Harbor Circle South\nSTE 150\nPhoenix, AZ 85034",
                "cat": "Cat Commercial Revolving Account Card\nPO BOX 78004\nPhoenix, AZ 85062-8004\n\nCat Commercial Revolving Account Card\nAttn: Commercial Payment Dept.\n1820 E Sky Harbor Cir S STE 150\nPhoenix, AZ 85034",
                "cnhi": "Productivity Plus Account \nPO BOX 78004 \nPhoenix, AZ 85062-8004 \n\nProductivity Plus Account \nAttn: Commercial Payment Department \n1820 E Sky Harbor Cir S STE 150 \nPhoenix, AZ 85034",
                "tractor supply": "Tractor Supply Credit Plan \nPayments \nP.O. Box 78004 \nPhoenix, AZ 85062-8004 \n\nTractor Supply Credit Plan \nOvernight Delivery/Express Payments \n1820 E Sky Harbor Cir S STE 150 \nPhoenix, AZ 85034",
                "toro": "Toro-Exmark Commercial Card Services \nPayments \nP.O. Box 78004 \nPhoenix, AZ 85062-8004 \n\nToro-Exmark Commercial Card Services \nOvernight Delivery/Express Payments \nAttn: Commercial Payment Dept. \n1820 E. Sky Harbor Circle South \nSTE 150 \nPhoenix, AZ 85034",
                "honda power equipment": "Honda Power Equipment Commercial Credit Card \nPO Box 78004 \nPhoenix, AZ 85062-8004 \n\nHonda Power Equipment Commercial Credit Card \nOvernight Delivery Express Payments \nAttn: Commercial Payment Dept. \n1820 E. Sky Harbor Circle \nSouth STE 150 \nPhoenix, AZ 85034",
                "office depot": "Office Depot Business Credit Account\nPO Box 78004 \nPhoenix, AZ 85062-8004 \n\nCommercial Payment Dept. \n1820 E. Sky Harbor Circle South \nSuite 150 \nPhoenix, AZ 85034"
            },
            "fleet": {
                "exxon": "ExxonMobil Business Card Payments\nProcessing Center\nPO Box 78001\nPhoenix, AZ 85062-8001\n\nExxonMobil Business Card Overnight Delivery/Express Payments\nAttn: Commercial Oil Dept.\n1820 E. Sky Harbor Circle South\nSTE 150\nPhoenix, AZ 85034",
                "sunoco": "Sunoco Corporate Card Payments\nPO Box 78013\nPhoenix, AZ 85062-8013\n\nSunoco Corporate Card Overnight Delivery/Express Payments\nAttn: Commercial Oil Dept.\n1820 E. Sky Harbor Circle South\nSTE 150\nPhoenix, AZ 85034"
            },
            "prox": {
                "thd": "The Home Depot® Commercial Account Payments \nHome Depot Credit Services \nP.O. Box 78047\nPhoenix, AZ 85062-8047 \n\nThe Home Depot® Commercial Account Overnight Delivery/Express Payments \nAttn: Consumer Payment Dept.\n6716 Grade Lane \nBuilding 9, Suite 910 \nLouisville, KY 40213",
                "staples": "Staples® Commercial More Account Payments \nPO Box 9001036 \nLouisville, KY 40290-1036 \n\nStaples® Commercial More Account Overnight Delivery/Express Payments \nCommercial Payment Dept \n6716 Grade Lane Building 9 \nSuite 910 \nLouisville, KY 40213",
                "cat": "Cat Commercial Invoice Card \nP.O. Box 9001036 \nLouisville, KY 40290-1036 \n\nAttn: Prox Payment Dept \n6716 Grade Lane \nBuilding 9, Suite 910 \nLexington, KY 40213",
                "office depot": "Office Depot® OfficeMax® \nPO Box 9001036 \nLouisville, KY 40290-1036 \n\nCommercial Payment Dept. \n6716 Grade Lane Building 9 \nSuite 910 \nLouisville, KY 40213"
            }
        }
    },
    "ivr": {
        "PLCN_HOMEDEPOT": "The Home Depot Consumer Credit Card Website\nThe Home Depot® Consumer Credit Card Payments\nHome Depot Credit Services\nP.O. Box 9001010\nLouisville, KY 40290-1010\n\nThe Home Depot® Consumer Credit Card Overnight Delivery/Express Payments\nAttn: Consumer Payment Dept.\n6716 Grade Lane\nBuilding 9, Suite 910\nLouisville, KY 40213",
        "SEARS": "Sears Consumer Payments\nP.O. Box 9001055\nLouisville, KY 40290-1055\n\nSears Consumer Express Payments\nAttn: Consumer Payment Dept.\n6716 Grade Lane\nBuilding 9, Suite 910\nLouisville, KY 40213",
        "PLCN_BESTBUY": "My Best Buy® Credit Card Payments \nP.O. Box 9001007 \nLouisville, KY 40290-1007 \n\nMy Best Buy® Credit Card Overnight Delivery/Express Payments \nAttn: Consumer Payment Dept. \n6716 Grade Lane \nBuilding 9, Suite 910 \nLouisville, KY 40213",
        "PLOC_EXXONMOBIL": "ExxonMobil \nP.O. Box 78072 \nPhoenix, AZ 85062-8072 \n\nExxonMobil Credit Card \nOvernight Delivery/Express Payments \nProcessing Center \n6716 Grade Lane \nBuilding 9, Suite 910 \nLouisville, KY 40213",
        "PLOC_SHELL": "Shell Card Payments \nP.O. Box 9001011 \nLouisville, KY 40290-1011 \n\nShell Card Overnight Delivery/Express Payments \nAttn: Consumer Payment Dept. \n6716 Grade Lane \nBuilding 9, Suite 910 \nLouisville, KY 40213",
        "PLCN_LLBEAN": "L.L.Bean Mastercard Payments \nPO Box 9001068 \nLouisville KY 40290-1068 \n\nL.L.Bean Mastercard \nOvernight Delivery/Express Payments \nAttn: Consumer Payment Dept. \n6716 Grade Lane \nBuilding 9, Suite 910 \nLouisville, KY 40213",
        "PLCR_HOMEDEPOT": "The Home Depot Commercial Revolving Credit Card Website\nThe Home Depot® Commercial Revolving Charge Card Payments\nHome Depot Credit Services\nP.O. Box 9001030\nLouisville, KY 40290-1030\n\nThe Home Depot® Commercial Revolving Charge Card\nOvernight Delivery/Express Payments\nPayments Department\n6716 Grade Lane\nBuilding 9, Suite 910\nLouisville, KY 40213",
        "PLNP_HOMEDEPOT": "The Home Depot® Commercial Account Payments \nHome Depot Credit Services \nP.O. Box 78047\nPhoenix, AZ 85062-8047 \n\nThe Home Depot® Commercial Account Overnight Delivery/Express Payments \nAttn: Consumer Payment Dept.\n6716 Grade Lane \nBuilding 9, Suite 910 \nLouisville, KY 40213",
        "PLOF_EXXONMOBIL": "ExxonMobil Business Card Payments\nProcessing Center\nPO Box 78001\nPhoenix, AZ 85062-8001\n\nExxonMobil Business Card Overnight Delivery/Express Payments\nAttn: Commercial Oil Dept.\n1820 E. Sky Harbor Circle South\nSTE 150\nPhoenix, AZ 85034",
        "PLOF_SUNOCO": "Sunoco Corporate Card Payments\nPO Box 78013\nPhoenix, AZ 85062-8013\n\nSunoco Corporate Card Overnight Delivery/Express Payments\nAttn: Commercial Oil Dept.\n1820 E. Sky Harbor Circle South\nSTE 150\nPhoenix, AZ 85034",
        "PLCR_STAPLES": "Staples® Business More Account\nPayments\nPO Box 78004\nPhoenix, AZ 85062-8004\n\nStaples® Business More Account\nOvernight Delivery/Express Payments\n1820 E Sky Harbor Circle South\nSTE 150\nPhoenix, AZ 85034",
        "PLNP_STAPLES": "Staples® Commercial More Account Payments \nPO Box 9001036 \nLouisville, KY 40290-1036 \n\nStaples® Commercial More Account Overnight Delivery/Express Payments \nCommercial Payment Dept \n6716 Grade Lane Building 9 \nSuite 910 \nLouisville, KY 40213",
        "PLCR_Cat": "Cat Commercial Revolving Account Card\nPO BOX 78004\nPhoenix, AZ 85062-8004\n\nCat Commercial Revolving Account Card\nAttn: Commercial Payment Dept.\n1820 E Sky Harbor Cir S STE 150\nPhoenix, AZ 85034",
        "PLNP_CAT": "Cat Commercial Invoice Card \nP.O. Box 9001036 \nLouisville, KY 40290-1036 \n\nAttn: Prox Payment Dept \n6716 Grade Lane \nBuilding 9, Suite 910 \nLexington, KY 40213",
        "PLCR_OFFICEDEPOT": "Office Depot Business Credit Account\nPO Box 78004 \nPhoenix, AZ 85062-8004 \n\nCommercial Payment Dept. \n1820 E. Sky Harbor Circle South \nSuite 150 \nPhoenix, AZ 85034",
        "PLNP_OFFICEDEPOT": "Office Depot® OfficeMax® \nPO Box 9001036 \nLouisville, KY 40290-1036 \n\nCommercial Payment Dept. \n6716 Grade Lane Building 9 \nSuite 910 \nLouisville, KY 40213",
        "PLCR_CNHI": "Productivity Plus Account \nPO BOX 78004 \nPhoenix, AZ 85062-8004 \n\nProductivity Plus Account \nAttn: Commercial Payment Department \n1820 E Sky Harbor Cir S STE 150 \nPhoenix, AZ 85034",
        "PLCR_TRACTORSUPPLY": "Tractor Supply Credit Plan \nPayments \nP.O. Box 78004 \nPhoenix, AZ 85062-8004 \n\nTractor Supply Credit Plan \nOvernight Delivery/Express Payments \n1820 E Sky Harbor Cir S STE 150 \nPhoenix, AZ 85034",
        "PLCR_TORO": "Toro-Exmark Commercial Card Services \nPayments \nP.O. Box 78004 \nPhoenix, AZ 85062-8004 \n\nToro-Exmark Commercial Card Services \nOvernight Delivery/Express Payments \nAttn: Commercial Payment Dept. \n1820 E. Sky Harbor Circle South \nSTE 150 \nPhoenix, AZ 85034",
        "PLCR_HNPE": "Honda Power Equipment Commercial Credit Card \nPO Box 78004 \nPhoenix, AZ 85062-8004 \n\nHonda Power Equipment Commercial Credit Card \nOvernight Delivery Express Payments \nAttn: Commercial Payment Dept. \n1820 E. Sky Harbor Circle \nSouth STE 150 \nPhoenix, AZ 85034",
        "PLCN_SYW": "Shop Your Way Credit Card Payments \nP.O. Box 78024 \nPhoenix, AZ 85062-8024 \nShop Your Way Credit Card \nOvernight Delivery/Express Payments \nAttn: Consumer Payment Dept. \n6716 Grade Lane \nBuilding 9, Suite 910 \nLouisville, KY 40213",
        "PLCN_MEIJER": "Meijer Credit Card \nPO Box 9001006 \nLouisville, KY 40290-1006 \n\nMeijer Mastercard \nPO Box 9001006 \nLouisville, KY 40290-1006"
    }
}

function getPaymentAddress() {
    var session = "";
    if (context.session && context.session.BotUserSession) {
        session = context.session.BotUserSession;
    }
    var channel = "";
    if (session && session.lastMessage && session.lastMessage.channel === "rtm") {
        channel = "rtm";
        var type = "";
        var partner = "";
        var brand = "";
        var customerDetails = getCustomerType();
        if (customerDetails && customerDetails.partner) {
            partner = customerDetails.partner;
        }
        if (customerDetails && customerDetails.type) {
            type = customerDetails.type;
            if (type === "commercial") {
                if (customerDetails.brand) {
                    brand = customerDetails.brand;
                    return paymentAddress[channel][type][brand][partner];
                }
                else
                    return "";
            }
            else if (type === "consumer")
                return paymentAddress[channel][type][partner];
            else
                return "";
        }
    }
    else if (session && session.lastMessage && session.lastMessage.channel === "ivr") {
        channel = "ivr";
        var siteId = "";
        if (session.lastMessage.messagePayload && session.lastMessage.messagePayload.siteId) {
            siteId = session.lastMessage.messagePayload.siteId;
            return paymentAddress[channel][siteId];
        }
        else {
            return "";
        }
    }
    else {
        return "";
    }
}