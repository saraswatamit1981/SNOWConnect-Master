

var request = require('request-promise');
var config = require("./config");
var _ = require('lodash');
var cuProxy = require("./cuproxy");


function makeCmsBotCall(req, res) {
    console.log("In Make CMS BOT call ", JSON.stringify(req.body))
    var mobileNumber = req.body["from"]["id"].replace("+1", "");
    var accountNumber = req.body["accountNumber"];
    if (req.body.from.id.includes("+1")) {
        console.log("Mobile number has the +1" + req.body.from.id);
    } else {
        req.body["from"]["id"] = "+1" + req.body.from.id;
    }
    req.body["from"]["id"] = req.body["from"]["id"] + "@" + req.body["siteId"];
    var options = {
        method: 'POST',
        url: config.cms.kore.api,
        body: req.body,
        json: true,
        headers: {
            'Content-Type': 'application/json',
            'Authorization': config.cms.kore.authToken
        }
    };
    console.log("Kore API call options are ", options);
    request(options, function (error, response, body) {
        if (!error) {
            console.log('Kore response [' + response.statusCode + '] body:  ' + JSON.stringify(body));
            var responseText = body.text;
            if (Array.isArray(responseText)) {
                responseText = responseText.join("\n\n");
            }
            var data = {
                "sourceApplicationId": config.connect.sourceApplicationId,
                "preferredLanguageCode": config.connect.preferredLanguageCode,
                "lineOfBusinessCode": config.cms.connect.lineOfBusinessCode,
                "eligibilityOverrideFlag": true,
                "campaignName": config.connect.campaignName,
                "smsMessageData": responseText,
                "smsMessageType": "",
                "portfolio": config.cms.connect.portfolio,
                "phone": {
                    "phoneNumber": mobileNumber,
                },
                "accountInfo": {
                    "accountNumber": accountNumber
                }
            }
            var options = {
                method: 'POST',
                url: config.connect.api,
                body: data,
                json: true,
                headers: {
                    'Content-Type': 'application/json',
                    'uuid': req.body.uuid,
                    'Authorization': "Bearer " + cuProxy.getJWTToken().access_token,
                    'countryCode': config.connect.countryCode,
                    'businessCode': config.connect.businessCode,
                    'channelId': config.connect.channelId,
                    'Accept': 'application/json',
                    'client_id': config.connect.clientId,
                    'accessToken': cuProxy.getJWTToken().metadata.replace("a:", "")
                }
            };
            console.log(req.body.uuid + "::CU outbound request: ", options);
            request(options, function (error, response, body) {
                if (!error) {
                    console.log(req.body.uuid + '::CU response status code [' + response.statusCode + '] and body:  [' + body.code + ']');
                    return res.status(response.statusCode).jsonp(body);
                } else {
                    console.log(req.body.uuid + '::CU API Error', error);
                    return res.status(500).jsonp({
                        "code": "INTERNAL SERVER ERROR",
                        "message": "The request failed due to an internal error/server unavailability"
                    })
                }
            });
        } else {
            console.log('Error happened: ' + error);
            return res.status(500).jsonp({
                "code": "INTERNAL SERVER ERROR",
                "message": "The request failed due to an internal error/server unavailability"
            })
        }
    });
}


function cmsInputProxy(body, mobileNumber) {
    console.log("In  CMS cuInputProxy call ", JSON.stringify(body))
    var options = {
        method: 'POST',
        url: config.cms.kore.api,
        body: body,
        json: true,
        headers: {
            'Content-Type': 'application/json',
            'Authorization': config.cms.kore.authToken
        }
    };
    console.log("CMS Kore API call options are ", options);
    request(options, function (error, response, body) {
        if (!error) {
            console.log('Kore response [' + response.statusCode + '] body:  ' + JSON.stringify(body));
          
            var data = {
                "sourceApplicationId": config.connect.sourceApplicationId,
                "preferredLanguageCode": config.connect.preferredLanguageCode,
                "lineOfBusinessCode": config.cms.connect.lineOfBusinessCode,
                "eligibilityOverrideFlag": true,
                "campaignName": config.connect.campaignName,
                "smsMessageType": "",
                "portfolio": config.cms.connect.portfolio,
                "phone": {
                    "phoneNumber": mobileNumber,
                }
            }
            var responseText = body.text;
            var responseMessage = "";

            if (Array.isArray(responseText)) {
                if (typeof responseText[0] == "object" && responseText[0].accountNumber) {
                    console.log("Stop Flow");
                    data["accountInfo"] = {
                        "accountNumber": responseText[0].accountNumber
                    }
                    data["smsMessageType"] = "STOP_WITH_CONFIRM"
                    responseMessage = responseText[0].textmessage;
                } else {
                    responseMessage = responseText.join("\n\n");
                }
            }else if(typeof responseText == "object"){
                console.log("Stop Flow");
                data["accountInfo"] = {
                    "accountNumber": responseText.accountNumber
                }
                data["smsMessageType"] = "STOP_WITH_CONFIRM"
                responseMessage = responseText.textmessage;
            }

            var allowedText = ["VIEW YOUR ACCOUNT INFORMATION AT CITI.COM OR CITI.COM/CITIMOBILEAPP OR CONTACT US AT ONLINE.CITI.COM/US/AG/CONTACTUS", "YOU'VE OPTED OUT OF TEXTS, EXCEPT FOR THE ONES YOU CHOSE TO RECEIVE. WE MAY STILL SEND CRITICAL TEXTS, SUCH AS POTENTIAL FRAUD. EDIT PREFERENCES AT CITI.COM/PREF", "SOMETHING WENT WRONG, PLEASE STAY ON THE LINE TO TALK WITH AN AGENT"]
            
            if (allowedText.includes(responseMessage.toLocaleUpperCase())) {
                data["smsMessageData"] = responseMessage;
            } else {
                data["smsMessageData"] = "Your response was not recognized. Reply STOP to opt out or HELP for more info."
            }
            var options = {
                method: 'POST',
                url: config.connect.api,
                body: data,
                json: true,
                headers: {
                    'Content-Type': 'application/json',
                    'uuid': body.uuid,
                    'Authorization': "Bearer " + cuProxy.getJWTToken().access_token,
                    'countryCode': config.connect.countryCode,
                    'businessCode': config.connect.businessCode,
                    'channelId': config.connect.channelId,
                    'Accept': 'application/json',
                    'client_id': config.connect.clientId,
                    'accessToken': cuProxy.getJWTToken().metadata.replace("a:", "")
                }
            };
            console.log(body.uuid + "::CU outbound request: ", options);
            request(options, function (error, response, cubody) {
                if (!error) {
                    console.log(body.uuid + '::CU response status code [' + response.statusCode + '] and body:  [' + cubody.code + ']');
                } else {
                    console.log(body.uuid + '::CU API Error', error);
                }
            });
        } else {
            console.log('Error happened: ' + error);
        }
    });
}


function cbolProxy(req, res) {
    console.log("IVR Request is: " + JSON.stringify(req.body) + " headers " + JSON.stringify(req.headers));
    try {
        if (!(req.body.to && req.body.to.id)) {
            return res.status(400).jsonp({
                "code": "Missing Parameters",
                "message": "Bot Id is missing"
            })
        }
        if (!(req.body.from && req.body.from.id)) {
            return res.status(400).jsonp({
                "code": "Missing Parameters",
                "message": "From mobile number is missing"
            })
        }
        if (!(req.body.from && req.body.from.id)) {
            return res.status(400).jsonp({
                "code": "Missing Parameters",
                "message": "From mobile number is missing"
            })
        }
        if (!req.body.accountNumber) {
            return res.status(400).jsonp({
                "code": "Missing Parameters",
                "message": "AccountNumber number is missing"
            })
        }

        if (!req.body.siteId) {
            return res.status(400).jsonp({
                "code": "Missing Parameters",
                "message": "Invalid siteId"
            })
        }
        req.body["channelId"] = "IVR";
        if (!(req.body && req.body.uuid)) {
            if (req.headers && req.headers.uuid) {
                req.body.uuid = req.headers.uuid;
            } else {
                let UUID = cuProxy.uuid();
                console.log("No UUID in headers or body generating the new UUID from Kore" + UUID)
                req.body.uuid = UUID;
            }
        }
        return makeCmsBotCall(req, res);
    } catch (err) {
        console.log("eror" + err);
        res.status(500).jsonp({
            "code": "INTERNAL SERVER ERROR",
            "message": "The request failed due to an internal error/server unavailability"
        })
    }
}
module.exports = {
    cbolProxy,
    makeCmsBotCall,
    cmsInputProxy
}





