const config = require("./config");
const sql = require('mssql');

var dbConfig = {
    user: config.sql.username,
    password: config.sql.password,
    server: config.sql.host, // You can use 'localhost\\instance' to connect to named instance
    database: config.sql.database,
    port: config.sql.port
}

function extentionApi(req, res) {
    console.log("promoExtentionApi", JSON.stringify(req.body));
    try {
        sql.connect(dbConfig).then(pool => {
            return pool.request().input('AccountNumber', sql.VarChar(16), req.body.accountNumber).input('TransactionDate', sql.Date, req.body.transactionDate).input('TransactionAmount', sql.Money, req.body.transactionAmount).input('LengthOfPromo', sql.Int, req.body.lengthOfPromo).execute('dbo.InsertReferralsSMS')
        }).then(result => {
            console.log(result.recordset[0]);
            sql.close();
            return res.status(200).jsonp({ "referanceNumber": Object.values(result.recordset[0])[0] })
        }).catch(err => {
            console.error("Error while excuting the stored procedure", err);
            sql.close();
            return res.status(500).jsonp({ "code": "INTERNAL SERVER ERROR", "message": "The request failed due to an internal error/server unavailability" });
        })
    } catch (Err) {
        console.log("Error while excuting the sql query", Err);
        sql.close();
        return res.status(500).jsonp({ "code": "INTERNAL SERVER ERROR", "message": "The request failed due to an internal error/server unavailability" });
    }
}
module.exports = {
    extentionApi
}
