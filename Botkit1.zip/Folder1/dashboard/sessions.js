
var _ = require('lodash');
var mongoUtil = require('./../mongoUtil');
var request = require("request");

async function getSessionsByUserIds(platformDB, sessionCollection, fromDate, toDate, docs) {
    return new Promise(function (resolve, reject) {
        let promises = docs.map(function (obj) {
            //console.log(JSON.stringify(obj))
            return platformDB.collection(sessionCollection).
                aggregate([
                    { $match: { uId: { $in: obj.userIds } } },
                    { $match: { $and: [{ 'sST': { '$gte': fromDate } }, { 'lAT': { '$lt': toDate } }] } },                    
                    { $group: { _id: { userId: "$uId" }, count: { "$sum": 1 } }} ,
                    { $sort: { count: -1 } }
                ])
                .toArray()
                .then(function (doc) {
                   // console.log(JSON.stringify(docs))
                    let tempObj = {};
                    tempObj['siteId'] = obj._id.siteId;
                    tempObj['total'] = doc.sum("count");
                    tempObj['sessions'] = doc;
                    return tempObj;
                });
        });
        return Promise.all(promises)
            .then(function (respArr) {
                //console.log(respArr);
                return resolve(respArr);
            })
    });
}

async function getSessionsSeriesByUserIds(platformDB, sessionCollection, fromDate, toDate, docs) {
    return new Promise(function (resolve, reject) {
        let promises = docs.map(function (obj) {
            //console.log(JSON.stringify(obj))
            return platformDB.collection(sessionCollection).
                aggregate([
                    { $match: { uId: { $in: obj.userIds } } },
                    { $match: { $and: [{ 'sST': { '$gte': fromDate } }, { 'lAT': { '$lt': toDate } }] } },
                    { $group: { _id: { $dateToString: { format: "%Y-%m-%d", date: "$lAT" } }, count: { "$sum": 1 } } },
                    { $sort: { count: -1 } }
                ])
                .toArray()
                .then(function (doc) {
                    //console.log(JSON.stringify(docs))
                    let tempObj = {};
                    tempObj['siteId'] = obj._id.siteId;
                    //tempObj['total']=doc.sum("count");
                    tempObj['sessions'] = doc;
                    return tempObj;
                });
        });
        return Promise.all(promises)
            .then(function (respArr) {
                //console.log(respArr);
                return resolve(respArr);
            })
    });
}


Array.prototype.sum = function (prop) {
    var total = 0
    for (var i = 0, _len = this.length; i < _len; i++) {
        total += this[i][prop]
    }
    return total
}


async function getUserIdsBySiteId(botkitDB, reportsCollection, fromDate, toDate, channel) {
    return new Promise(function (resolve, reject) {
        try {
            var query = [
                {
                    $match: {
                        $and: [{ 'timestamp': { '$gte': fromDate } },
                        { 'timestamp': { '$lt': toDate } }]
                    }
                },
                {
                    $group: {
                        _id: { siteId: "$siteId" },
                        userIds: { $push: "$userId" }
                    }
                }];
            if (channel) {
                query.unshift({ $match: { 'channel': channel } })
            }
            console.log(JSON.stringify(query));
            return botkitDB.collection(reportsCollection).aggregate(query).toArray()
                .then(function (docs) {
                    return resolve(docs);
                });
        } catch (e) {
            console.log("Error occured in getUserIdsBySiteId", e)
            return resolve(false)
        }
    })
}



function getSessions(req, res) {
    console.log("GetSessions Request is: " + JSON.stringify(req.query) + " headers " + JSON.stringify(req.headers));
    try {
        var fromDate = req.query.fromDate;
        var toDate = req.query.toDate;
        var siteId = req.query.siteId;
        var channel = req.query.channel;
        var type = req.query.type;
        if (!fromDate) {
            return res.status(400).jsonp({
                "code": "Missing Parameters",
                "message": "fromDate is missing"
            })
        }
        if (!toDate) {
            return res.status(400).jsonp({
                "code": "Missing Parameters",
                "message": "toDate is missing"
            })
        }
        if (channel && channel.toLowerCase() != 'all') {
            channel = channel.toLowerCase();
        }else{
            channel = null;
        }

        fromDate = new Date(fromDate);
        toDate = new Date(toDate);
        var botkitDB = mongoUtil.getDb();
        if (botkitDB) {
            return getUserIdsBySiteId(botkitDB, "reports", fromDate, toDate, channel)
                .then(function (docs) {
                    //console.log(docs)
                    if (docs) {
                        var platformDB = mongoUtil.getPlatformDb();
                        return getSessionsByUserIds(platformDB, "botsessions", fromDate, toDate, docs)
                    } else {
                        return Promise.reject(res.status(500).json({ 'message': 'Internal Server error' }));
                    }
                }).then(function (resP) {
                    if (resP) {
                        res.status(200).json({
                            "status": "success",
                            "message": "successfully retrived all the partners session records",
                            "data": resP
                        });
                    } else {
                        return Promise.reject(res.status(500).json({ 'message': 'Internal Server error' }));
                    }
                })
        } else {
            console.log("DB issue");
            res.status(500).json({ 'message': 'Internal Mongo error' })
        }
    } catch (Err) {
        res.status(500).json({ 'message': 'Internal Server error' })
        console.log("Error occured while geting the sessions", Err);
    }
}


function getSessionsBySeries(req, res) {
    console.log("getSessionsBySeries Request is: " + JSON.stringify(req.query) + " headers " + JSON.stringify(req.headers));
    try {
        var fromDate = req.query.fromDate;
        var toDate = req.query.toDate;
        var siteId = req.query.siteId;
        var channel = req.query.channel;
        var type = req.query.type;
        if (!fromDate) {
            return res.status(400).jsonp({
                "code": "Missing Parameters",
                "message": "fromDate is missing"
            })
        }
        if (!toDate) {
            return res.status(400).jsonp({
                "code": "Missing Parameters",
                "message": "toDate is missing"
            })
        }
        if (channel && channel.toLowerCase() != 'all') {
            channel = channel.toLowerCase();
        }else{
            channel = null;
        }

        fromDate = new Date(fromDate);
        toDate = new Date(toDate);
        var botkitDB = mongoUtil.getDb();
        if (botkitDB) {
            return getUserIdsBySiteId(botkitDB, "reports", fromDate, toDate, channel)
                .then(function (docs) {
                   // console.log(docs)
                    if (docs) {
                        var platformDB = mongoUtil.getPlatformDb();
                        return getSessionsSeriesByUserIds(platformDB, "botsessions", fromDate, toDate, docs)
                    } else {
                        return Promise.reject(res.status(500).json({ 'message': 'Internal Server error' }));
                    }
                }).then(function (resP) {
                    if (resP) {
                        res.status(200).json({
                            "status": "success",
                            "message": "successfully retrived all the partners session serieas records",
                            "data": resP
                        });
                    } else {
                        return Promise.reject(res.status(500).json({ 'message': 'Internal Server error' }));
                    }
                })
        } else {
            console.log("DB issue");
            res.status(500).json({ 'message': 'Internal Mongo error' })
        }
    } catch (Err) {
        res.status(500).json({ 'message': 'Internal Server error' })
        console.log("Error occured while geting the sessions", Err);
    }
}


module.exports={
    getSessionsBySeries,
    getSessions
}




