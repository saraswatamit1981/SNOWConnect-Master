
var config = require('./config');
var MongoClient = require('mongodb').MongoClient,
    f = require('util').format,
    fs = require('fs');

var _db;
var _platformdb;

module.exports = {
    connectToServer: function (callback) {
        var ca = [fs.readFileSync(config.mongoDB.sshKeyPath)];
        // Connect validating the returned certificates from the server
        MongoClient.connect("mongodb://"+config.mongoDB.username+":"+config.mongoDB.password+"@"+config.mongoDB.host1+":"+config.mongoDB.port+","+config.mongoDB.host2+":"+config.mongoDB.port+","+config.mongoDB.host3+":"+config.mongoDB.port+"?replicaSet="+config.mongoDB.replicaSet+"&ssl=true", {
        server: {
                sslValidate: false,
                sslCA: ca,
                poolSize: 20,
                socketOptions:
                {
                    connecTimeoutMS: 30000,
                    keepAlive: 1
                }
            }
        }, function (err, client) {
            _db = client.db(config.mongoDB.dbName);
            _platformdb = client.db("koredbm001");
            return callback(err);
        });
    },
    getDb: function () {
        return _db;
    },
    getPlatformDb: function () {
        return _platformdb;
    }
};




