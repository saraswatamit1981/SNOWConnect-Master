
var prod = {
    "server": {
        "port": 9000
    },
    "app": {
        "apiPrefix": "/crsbotkit"
    },
    "koreAuthToken": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwiYXBwSWQiOiJjcy03Y2QwZTlhZi0wYjM0LTU1YjktYjdkMi1kZDY5NmVmODdlOGEifQ.xo_O6L-XKecP_AFIfd4IfIti-MJww8AGFY_Y2MJbRSs",
    "siteIds": {
        "THD": "PLCN_HOMEDEPOT",
        "BBY": "PLCN_BESTBUY",
        "SEARS": "SEARS",
        "LLB": "PLCN_LLBEAN",
        "SYW": "PLCN_SYW",
        "EXXONMOBIL": "PLOC_EXXONMOBIL",
        "SHELL": "PLOC_SHELL",
        "STAPLES": "PLCN_STAPLES"
    },
    "deeplinks": {
        "PLCN_HOMEDEPOT": "pay.homedepotconsumer.accountonline.com",
        "PLCN_BESTBUY": "bestbuy.accountonline.com",
        "SEARS": "mycard.searscard.com",
        "PLCN_LLBEAN": "llbeanmastercard.com",
        "PLCN_SYW": "syw.accountonline.com",
        "PLOC_SHELL": "shell.accountonline.com",
        "PLCN_STAPLES": "staplespersonal.accountonline.com",
        "PLOC_EXXONMOBIL": "exxonmobil.accountonline.com"
    },
    "credentials": {
        "apikey": "iCGyoZtrumZaTbrZXr/bov7i8S7hHALxXc3nGjhuOVk=",
        "appId": "cs-7cd0e9af-0b34-55b9-b7d2-dd696ef87e8a",
        "botId": "st-e545489f-97f1-528b-baf1-f9a36517d9ee",
        "botName": "COVA"
    },
    "connect": {
        "api": "https://api.citigroup.net/gcgapi/prod/api/private/v1/bank/customers/phone/outbound/alerts",
        "sourceApplicationId": "KOREAI",
        "countryCode": "US",
        "businessCode": "CRS",
        "channelId": "SMSKORE",
        "clientId": "c120a56f-9c7a-4f0a-8d65-3491fa00ffdf",
        "lineOfBusinessCode": "CRS",
        "campaignName": "KoreFreeformText",
        "preferredLanguageCode": "EN"
    },
    "kore": {
        "api": "https://botbuilder.consumerna.citigroup.net/chatbot/hooks/st-e545489f-97f1-528b-baf1-f9a36517d9ee"
    },
    "Oauth": {
        "clientId": "c120a56f-9c7a-4f0a-8d65-3491fa00ffdf",
        "clientSecret": "G3aM4aO2uO1jI8aH3xF3oF1hT4pS5cL2xG3mU4vY4dH8pT0oQ4",
        "scope": "/api",
        "grantType": "password",
        "accessTokenUri": "https://api.citigroup.net/gcgapi/prod/api/koreai/oauth2/token"
    },
    "accountApi": {
        "countryCode": "US",
        "businessCode": "CRS",
        "channelId": "SMSKORE",
        "endPoint": "https://rhifabric-vip.nam.nsroot.net/gcgapi/prod/api/private/v1/retailCards/accounts/detailsByPhone/retrieve",
        "clientId": "c120a56f-9c7a-4f0a-8d65-3491fa00ffdf"
    },
    "sql": {
        "username": "RPA_SMS_PRD",
        "password": "N2Tozjm5",
        "host": "CRA076PDB004V",
        "port": 2901,
        "database": "AAPromoReferral"
    },
    "ssgConfig": {
        "domain": "https://soagatewayuat.consumer.citigroup.net/LP",
        "headerKey": "host-name",
        "certFile": "/var/www/ssl/cert.pem",
        "keyFile": "/var/www/ssl/key.pem",
        "caFile": "/var/www/ssl/ca.pem",
        "passphrase": "",
        "securityOptions": "TLSv1_2_method"
    },
    "ignoreIntents": ["Feedback", "Welcome", "XXYYZZ", "ActionPrompts", "NoIntent Match", "Agent Transfer", "Stop123", "TCPA CHECK", "ClearSession", "SetUser", "GPUERROR", "CUSTOMERROR", "MessageAlert"],
    "liveperson": {
        "accountId": "70208405",
        "clientSecret": "mpfj66i4i8p3ea6vkof1o1n020",
        "clientId": "735a3e9b-af2c-4595-b7df-6dd445672970",
        "host": "http://api.liveperson.net",
        "skillId": "272324714"
    },
    "redis": {
        "options": {
            "password": "prodops4all",
            "deployment_type": "sentinel",
            "sentinels": [
                {
                    "host": "169.177.55.21",
                    "port": 26379
                },
                {
                    "host": "169.177.53.72",
                    "port": 26379
                },
                {
                    "host": "10.46.83.74",
                    "port": 26379
                }
            ],
            "name": "RedisMaster"
        },
        "available": true
    },
    "mongoDB": {
        "username": "KORE_BOT_PROD",
        "password": "WqVJ_izqNo",
        "host1": "maas-mw-p135-l0001.nam.nsroot.net",
        "host2": "maas-gt-p135-l0002.nam.nsroot.net",
        "host3": "maas-sw-p135-l0002.nam.nsroot.net",
        "dbName": "koreapp",
        "replicaSet": "MGORPST_2896",
        "sshKeyPath": "/var/www/ssl/ca.pem",
        "port": "37017"
    },
    "examples": {
        "mockServicesHost": "http://localhost:8004"
    },
    "cms": {
        "kore": {
            "authToken": "Bearer eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwiYXBwSWQiOiJjcy0zOGRhNTMzZC0zYmI4LTUwMzktODdkNi0wZWVlMmJjOWVkMWUifQ.3BIYcuj6-dfGv-PVNO8-TkZbRUiSqCeyQkoPrcDcXFg",
            "api": "https://botbuilder.consumerna.citigroup.net/chatbot/hooks/st-956cf1d8-69bb-5ae4-9c84-1f55035cc131"
        },
        "connect": {
            "portfolio": "BRANDS PORTFOLIO",
            "lineOfBusinessCode": "BRANDS"
        }
    },
    "liveagentlicense": "8947569",
    "supportsMessageAck": true,
    "languages": [
        "en", 
        "de"
    ]
}
module.exports = prod;



