var uat = {
    "server": {
        "port": 9000
    },
    "app": {
        "apiPrefix": "/crsbotkit"
    },
    "siteIds": {
        "THD": "PLCN_HOMEDEPOT",
        "BBY": "PLCN_BESTBUY",
        "SEARS": "SEARS",
        "LLBEAN": "PLCN_LLBEAN",
        "SYW": "PLCN_SYW",
        "EXXONMOBIL": "PLOC_EXXONMOBIL",
        "SHELL": "PLOC_SHELL",
        "STAPLES": "PLCN_STAPLES"
    },
    "koreAuthToken": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwiYXBwSWQiOiJjcy0yYzk4ZGI0Zi1lNjQ5LTUzMTItOTk2Yi1jNDk5NmViZDVkYTYifQ.cEtnafkPuwgC7ef5igbaWlz_khIUfNhHwo_zg8nZGq4",
    "deeplinks": {
        "PLCN_HOMEDEPOT": "pay.homedepotconsumer.accountonline.com",
        "PLCN_BESTBUY": "bestbuy.accountonline.com",
        "SEARS": "mycard.searscard.com",
        "PLCN_LLBEAN": "llbeanmastercard.com",
        "PLCN_SYW": "syw.accountonline.com",
        "PLOC_SHELL": "shell.accountonline.com",
        "PLCN_STAPLES": "staplespersonal.accountonline.com",
        "PLOC_EXXONMOBIL": "exxonmobil.accountonline.com"
    },
    "credentials": {
        "apikey": "6JOwWyExxauor57ZS9b1fyL6foRXaMChCr0qdOxMfT8=",
        "appId": "cs-2c98db4f-e649-5312-996b-c4996ebd5da6",
        "botId": "st-5bda0ad1-6529-5279-948e-7d70bf790d80",
        "botName": "COVA"
    },
    "connect": {
        "api": "https://sit.api.citigroup.net/gcgapi/uat1/api/private/v1/bank/customers/phone/outbound/alerts",
        "sourceApplicationId": "KOREAI",
        "countryCode": "US",
        "businessCode": "CRS",
        "channelId": "SMSKORE",
        "clientId": "fc3f6e99-08d3-435d-af1e-ce4d742cb204",
        "lineOfBusinessCode": "CRS",
        "campaignName": "KoreFreeformText",
        "preferredLanguageCode": "EN"
    },
    "kore": {
        "api": "https://uat.botbuilder.consumerna.citigroup.net/chatbot/hooks/st-5bda0ad1-6529-5279-948e-7d70bf790d80"
    },
    "Oauth": {
        "clientId": "fc3f6e99-08d3-435d-af1e-ce4d742cb204",
        "clientSecret": "sC6nR2xX0iG6nV4bH5qI2yK4gQ4tF3tI2iH1qG6aQ5jQ6iW1sF",
        "scope": "/api",
        "grantType": "password",
        "accessTokenUri": "https://sit.api.citigroup.net/gcgapi/uat1/api/koreai/oauth2/token"
    },
    "accountApi": {
        "countryCode": "US",
        "businessCode": "CRS",
        "channelId": "SMSKORE",
        "endPoint": "https://sit.api.citigroup.net/gcgapi/uat1/api/private/v1/retailCards/accounts/detailsByPhone/retrieve",
        "clientId": "fc3f6e99-08d3-435d-af1e-ce4d742cb204"
    },
    "sql": {
        "username": "RPA_SMS_UAT",
        "password": "N2Tozjm5",
        "host": "CRA076UDB003V",
        "port": 1726,
        "database": "AAPromoReferral"
    },
    "ssgConfig": {
        "domain": "https://soagatewayuat.consumer.citigroup.net/LP",
        "headerKey": "host-name",
        "certFile": "/var/www/ssl/cert.pem",
        "keyFile": "/var/www/ssl/key.pem",
        "caFile": "/var/www/ssl/ca.pem",
        "passphrase": "",
        "securityOptions": "TLSv1_2_method"
    },
    "ignoreIntents": ["Feedback", "Welcome", "XXYYZZ", "ActionPrompts", "NoIntent Match", "Agent Transfer", "Stop123", "TCPA CHECK", "ClearSession", "SetUser", "GPUERROR", "CUSTOMERROR", "MessageAlert"],
    "liveperson": {
        "accountId": "70208405",
        "clientSecret": "5f7d4s9rrpij7dpd631snrhr9p",
        "clientId": "b402aba7-7a5a-4c1f-930f-ee6e385d8ba9",
        "host": "http://api.liveperson.net",
        "skillId": "272324714"
    },
    "redis": {
        "options": {
            "password": "kore123",
            "deployment_type": "sentinel",
            "sentinels": [
                {
                    "host": "127.0.0.1",
                    "port": 26379
                },
                {
                    "host": "169.171.172.41",
                    "port": 26379
                },
                {
                    "host": "169.171.163.20",
                    "port": 26379
                }
            ],
            "name": "RedisMaster"
        },
        "available": true
    },
    "mongoDB": {
        "username": "KORE_BOT_UAT",
        "password": "PWQLs5_y09",
        "host1": "maas-gt-p5-m0002.nam.nsroot.net",
        "host2": "maas-mw-p5-m0002.nam.nsroot.net",
        "host3": "maas-sw-p5-m0002.nam.nsroot.net",
        "dbName": "koreapp",
        "replicaSet": "MGORPST_2774",
        "sshKeyPath": "/var/www/ssl/ca.pem",
        "port": "37017"
    },
    "examples": {
        "mockServicesHost": "http://localhost:8004"
    },
    "cms": {
        "kore": {
            "authToken": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwiYXBwSWQiOiJjcy0yYzk4ZGI0Zi1lNjQ5LTUzMTItOTk2Yi1jNDk5NmViZDVkYTYifQ.cEtnafkPuwgC7ef5igbaWlz_khIUfNhHwo_zg8nZGq4",
            "api": "https://uat.botbuilder.consumerna.citigroup.net/chatbot/hooks/st-d05ce673-af9a-5fa1-a1c2-cd5f71ff1a39"
        },
        "connect": { 
                "portfolio":"Branded_Cards",
                "lineOfBusinessCode": "BRANDS"
        }
    },
    "liveagentlicense": "8947569",
    "supportsMessageAck": true,
    "languages": [
        "en",
        "de"
    ]
}
module.exports = uat;





