
var dit = {
    "server": {
        "port": 9000
    },
    "app": {
        "apiPrefix": "/crsbotkit"
    },
    "koreAuthToken": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwiYXBwSWQiOiJjcy1iODAxZDRlOS1iNTEwLTU0ZDYtOWNjNC0xNDJmZDhlN2NiMWQifQ.-Yoh1De6cltL3WFpN7T_95Y6n-0lt_n2dIKXjFdWatU",
    "siteIds": {
        "THD": "PLCN_HOMEDEPOT",
        "BBY": "PLCN_BESTBUY",
        "SEARS": "SEARS",
        "LLBEAN": "PLCN_LLBEAN",
        "SYW": "PLCN_SYW",
        "EXXONMOBIL": "PLOC_EXXONMOBIL",
        "SHELL": "PLOC_SHELL",
        "STAPLES": "PLCN_STAPLES"
    },
    "deeplinks": {
        "PLCN_HOMEDEPOT": "pay.homedepotconsumer.accountonline.com",
        "PLCN_BESTBUY": "bestbuy.accountonline.com",
        "SEARS": "mycard.searscard.com",
        "PLCN_LLBEAN": "llbeanmastercard.com",
        "PLCN_SYW": "syw.accountonline.com",
        "PLOC_SHELL": "shell.accountonline.com",
        "PLCN_STAPLES": "staplespersonal.accountonline.com",
        "PLOC_EXXONMOBIL": "exxonmobil.accountonline.com"
    },
    "credentials": {
        "apikey": "fTWr34+QqoqaT97wa4pAq9/4crX//ipyJnVRcLxkJS0=",
        "appId": "cs-b801d4e9-b510-54d6-9cc4-142fd8e7cb1d",
        "botId": "st-fc77c68b-a12c-5024-aae0-7aa1680690fa",
        "botName": "COVA"
    },
    "connect": {
        "api": "https://sit.api.citigroup.net/gcgapi/dev3/api/private/v1/bank/customers/phone/outbound/alerts",
        "sourceApplicationId": "KOREAI",
        "countryCode": "US",
        "businessCode": "CRS",
        "channelId": "SMSKORE",
        "clientId": "9197eb12-5bc7-4d43-b5ea-e35490bb8be5",
        "lineOfBusinessCode": "CRS",
        "campaignName": "KoreFreeformText",
        "preferredLanguageCode": "EN"
    },
    "kore": {
        "api": "https://b172935-vip.nam.nsroot.net/chatbot/hooks/st-fc77c68b-a12c-5024-aae0-7aa1680690fa"
    },
    "Oauth": {
        "clientId": "9197eb12-5bc7-4d43-b5ea-e35490bb8be5",
        "clientSecret": "E1sK7kN7kJ5hY3hY3nK5aS1xN6iB0fD1wA4tT4oT0kD3uU8vM1",
        "scope": "/api",
        "grantType": "password",
        "accessTokenUri": "https://sit.api.citigroup.net/gcgapi/dev3/api/koreai/oauth2/token"
    },
    "accountApi": {
        "countryCode": "US",
        "businessCode": "CRS",
        "channelId": "SMSKORE",
        "endPoint": "https://sit.api.citigroup.net/gcgapi/dev3/api/private/v1/retailCards/accounts/detailsByPhone/retrieve",
        "clientId": "9197eb12-5bc7-4d43-b5ea-e35490bb8be5"
    },
    "sql": {
        "username": "RPA_SMS_UAT",
        "password": "N2Tozjm5",
        "host": "vm-c231-8dd3",
        "port": 2431,
        "database": "AAPromoReferral"
    },
    "ssgConfig": {
        "domain": "https://soagatewaysit.consumer.citigroup.net/LP",
        "headerKey": "host-name",
        "certFile": "/var/www/ssl/cert.pem",
        "keyFile": "/var/www/ssl/key.pem",
        "caFile": "/var/www/ssl/ca.pem",
        "passphrase": "",
        "securityOptions": "TLSv1_2_method"
    },
    "liveperson": {
        "accountId": "70208405",
        "clientSecret": "h36lh03h80c0hupma3fsl5q454",
        "clientId": "4833ed1d-0729-49b8-9e0a-90c56415d4c4",
        "host": "https://api.liveperson.net",
        "skillId": "272324714"
    },
    "ignoreIntents": ["Feedback", "Welcome", "XXYYZZ", "ActionPrompts", "NoIntent Match", "Agent Transfer", "Stop123", "TCPA CHECK", "ClearSession", "SetUser", "GPUERROR", "CUSTOMERROR", "MessageAlert"],
    "redis": {
        "options": {
            "password": "kore123",
            "deployment_type": "sentinel",
            "sentinels": [
                {
                    "host": "127.0.0.1",
                    "port": 26379
                },
                {
                    "host": "169.171.165.150",
                    "port": 26379
                },
                {
                    "host": "169.171.165.59",
                    "port": 26379
                }
            ],
            "name": "RedisMaster"
        },
        "available": true
    },
    "mongoDB": {
        "username": "admin_mongodb",
        "password": "azUz9dMd",
        "host1": "maas-gt-d4-u0046.nam.nsroot.net",
        "host2": "maas-mw-d4-u0037.nam.nsroot.net",
        "host3": "maas-sw-d4-u0044.nam.nsroot.net",
        "dbName": "koreapp",
        "replicaSet": "MGORPST_2754",
        "sshKeyPath": "/var/www/ssl/ca.pem",
        "port": "37017"
    },
    "examples": {
        "mockServicesHost": "http://localhost:8004"
    },
    "cms": {
        "kore": {
            "authToken": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwiYXBwSWQiOiJjcy1iODAxZDRlOS1iNTEwLTU0ZDYtOWNjNC0xNDJmZDhlN2NiMWQifQ.-Yoh1De6cltL3WFpN7T_95Y6n-0lt_n2dIKXjFdWatU",
            "api": "https://b172935-vip.nam.nsroot.net/chatbot/hooks/st-3d6c0068-4432-5c7b-8945-ad2dc0f22282"
        },
        "connect": { 
                "portfolio":"Branded_Cards",
                "lineOfBusinessCode": "BRANDS"
        }
    },
    "liveagentlicense": "8947569",
    "supportsMessageAck": true,
    "languages": [
        "en",
        "de"
    ]
}

module.exports = dit;




