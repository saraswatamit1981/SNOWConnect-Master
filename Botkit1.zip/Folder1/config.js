const DIT1 = require('./config/config_dit1');
const DIT2= require('./config/config_dit2');
const DIT3 = require('./config/config_dit3');
const UAT1= require('./config/config_uat1');
const UAT2 = require('./config/config_uat2');
const UAT3= require('./config/config_uat3');
const PROD= require('./config/config_prod');


const env = process.env.NODE_ENV;

const config = {
    PROD,
    DIT1,
    DIT2,
    DIT3,
    UAT1,
    UAT2,
    UAT3 
};
module.exports=config[env];




