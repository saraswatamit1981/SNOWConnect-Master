

var memes = [
    'Dude, you smashed my turtle saying "I\'M MARIO BROS!"',
    'Dude, you grabed seven oranges and yelled "I GOT THE DRAGON BALLS!"',
    'Dude, you threw my hamster across the room and said "PIKACHU I CHOOSE YOU!"',
    'Dude, you congratulated a potato for getting a part in Toy Story',
    'Dude, you were hugging an old man with a beard screaming "DUMBLEDORE YOU\'RE ALIVE!"',
    'Dude, you were cutting all my pinapples yelling "SPONGEBOB! I KNOW YOU\'RE THERE!"',
];

var random = document.querySelector('#random');

var counter = 0;

//random.innerHTML = memes[Math.floor(Math.random() * memes.length)];

/* Time */

var deviceTime = document.querySelector('.status-bar .time');
var messageTime = document.querySelectorAll('.message .time');

deviceTime.innerHTML = moment().format('h:mm');

setInterval(function () {
    deviceTime.innerHTML = moment().format('h:mm');
}, 1000);

for (var i = 0; i < messageTime.length; i++) {
    messageTime[i].innerHTML = moment().format('h:mm A');
}

/* Message */

//var form = document.querySelector('.conversation-compose');
var conversation = document.querySelector('.conversation-container');

//form.addEventListener('submit', newMessage);

$(document).ready(function () {
    $("span#siteId").text(getQueryStringValue("siteId").toUpperCase());
    $("#sendbutton").on("click", function () {
        newMessage();
    });
});

$('#userInput').keypress(function (e) {
    if (e.which == 13) {
        newMessage();
    }
});

function newMessage() {
    var input = document.getElementById("userInput").value;
    if (input) {
        var message = buildMessage(input);
        conversation.appendChild(message);
        //animateMessage(message);
        makeApiCall(input)
    }
    document.getElementById('userInput').value = ''
    conversation.scrollTop = conversation.scrollHeight;
    //e.preventDefault();
}

function getQueryStringValue(key) {
    return decodeURIComponent(window.location.search.replace(new RegExp("^(?:.*[&\\?]" + encodeURIComponent(key).replace(/[\.\+\*]/g, "\\$&") + "(?:\\=([^&]*))?)?.*$", "i"), "$1"));
}

function makeApiCall(queryString) {

    //var type = getQueryStringValue("type").toLocaleLowerCase();
    var siteId = getQueryStringValue("siteId").toLocaleLowerCase();
    var phoneNumber = getQueryStringValue("phoneNumber")


    var body = {
        "from": {
            "id": "+1" + phoneNumber + "@" + siteId
        },
        "to": {
            "id": "st-5bda0ad1-6529-5279-948e-7d70bf790d80"
        },
        "message": {
            "text": queryString
        },
        "session": {
            "new": true
        },
        "siteId": siteId,
        "channelId": "SMSAG",
        "uuid": counter + "_" + phoneNumber + "_" + siteId + "_" + Math.round(new Date().getTime() / 1000)
    }
    counter = counter + 1;
    console.log(JSON.stringify(body));
    $.ajax({
        url: 'https://b172935-vip.nam.nsroot.net/chatbot/hooks/st-fc77c68b-a12c-5024-aae0-7aa1680690fa',
        type: "POST",
        dataType: "json",
        headers: {
            "Authorization": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwiYXBwSWQiOiJjcy1iODAxZDRlOS1iNTEwLTU0ZDYtOWNjNC0xNDJmZDhlN2NiMWQifQ.-Yoh1De6cltL3WFpN7T_95Y6n-0lt_n2dIKXjFdWatU",
            "Content-Type": "application/json"
        },
        data: JSON.stringify(body),
        success: function (response) {
            console.log(response);
            var responseText = response.text;
            if (Array.isArray(responseText)) {
                responseText.forEach(function (element) {
                    console.log(" in Array " + element + " typeof element" + typeof element);
                    let msg;
                    if (IsJsonString(element)) {
                        msg = JSON.parse(element).textmessage;
                        if (msg.textmessage) {
                            msg = msg.textmessage;
                        }
                    } else if (typeof element === 'object') {
                        msg = element.textmessage;
                    } else {
                        msg = element;
                    }
                    let message = buildIncomingMessage(msg);
                    conversation.appendChild(message);
                    //animateMessage(message);

                });
            } else if (responseText instanceof Object) {
                console.log(" in object " + element);

                let message = buildIncomingMessage(JSON.parse(responseText).text);
                conversation.appendChild(message);
                //animateMessage(message);
            } else {
                console.log(" in default " + responseText + " type of: " + typeof responseText);
                let msg;
                if (IsJsonString(responseText)) {
                    msg = JSON.parse(responseText).textmessage;
                    if (!msg) {
                        msg = JSON.parse(responseText).text;
                    }
                } else {
                    msg = responseText;
                }

                let message = buildIncomingMessage(msg);
                conversation.appendChild(message);
                //animateMessage(message);
            };
            conversation.scrollTop = conversation.scrollHeight;
        },
        error: function () {
            console.log("error");
        }
    });
}

function buildMessage(text) {
    var element = document.createElement('div');
    element.classList.add('message', 'sent');
    element.innerHTML = text +
        '<span class="metadata">' +
        '<span class="sentTime">' + moment().format('h:mm A') + '</span>' +
        '</span>';

    return element;
}

function urlify(text) {
    var urlRegex = /(https?:\/\/[^\s]+)/g;
    return text.replace(urlRegex, function (url) {
        return '<a href="' + url + '">' + url + '</a>';
    })
}



function buildIncomingMessage(text) {
    console.log('buildIncomingMessage: ' + text);
    //text = text.split("#").join("");
    text = text.split("\n").join("<br>");
    text = urlify(text);
    if (!text) {
        text = "Looks like I had a technical issue on my end and I need to back up a sec. What do you need help with?";
    }
    var element = document.createElement('div');
    element.classList.add('message', 'received');
    element.innerHTML = '<div>' + text + '</div>'
    '<span class="metadata">' +
        '<span class="time">' + moment().format('h:mm A') + '</span>' +
        '</span>';

    return element;
}


function IsJsonString(str) {
    try {
        JSON.parse(str);
    } catch (e) {
        return false;
    }
    return true;
}

function animateMessage(message) {
    setTimeout(function () {
        var tick = message.querySelector('.tick');
        tick.classList.remove('tick-animation');
    }, 500);
}
var sampleInput = {

        "phoneNumber": "9729988092",
        "siteId": "PLCN_BESTBUY",
        "environment":"DIT",

        "happyPath": {


        "input": [

            // "ClearSession",

            "Discard all",

            // "Hi",

            //"1183",

            "make payment",

            "1183",

            "Yes",

            "4",

            "3",

            "3",

            "07/25/2020",

            "Yes",

            "Yes",

            "Yes",

            "6789"

        ],

        "output": [

            // "context",

            "discarding the task for now",

            //"*",

            // "Hi, I'm your virtual guide to ",

            // "@@@@",

            "Which account do you want to pay?",

            "Before we begin, you should know that your account information, including last statement balance, current balance and minimum payment due, will be displayed on this device and any other device where you receive text messages. Do you want to continue and allow this information to be displayed?",

            "It looks like",

            "Please enter the amount of payment greater than $1 in $xx.xx format",

            "When do you want to make a payment",

            "Please enter a valid date in MM/DD/YYYY format",

            "We have your  account information from previous payments you have made",

            "Almost done: let's confirm the payment information and get your authorization to make the payment.",

            "If you choose to pay less than the Minimum Payment Due and do not make any additional payments, your account will be past due. You will also pay more in interest and it will take you longer to pay off your balance.\n\nTo avoid a late fee, schedule your Payment Date no later than your Payment Due Date.$$$$2/2. Would you like to continue and make a payment. \nText Y to make a payment\nText N to stop the payment communication.",

            "Do I have your authorization to take this payment now?\nPlease text the last 4 digits of the primary account holder's SSN to authorize this payment.\nText N if you do not authorize this payment.",

            "Your payment was successful $$$$ Is there anything else I can help you with today?"

        ]

    }

};
//   $('#jsonIde').jsonViewer(sampleInput);
  new JsonEditor('#jsonIde', sampleInput);


  $(document).ready(function () {
      $('#cova_run_btn').hide();

      // dropdown list onload
      $('#cova-type, #cova-siteid, #cova-environment, #cova-phonenumber, #cova-usecases,#cova-testcases, #cova-validation').hide();

    // $(" #editor ").fadeTo(1, 0.25);
    // $(" #device ").fadeTo(1, 0.25);
    // $("#editor").children().prop('disabled',true);
    // document.getElementById("editor").disabled = true;

    $('#cova_form select[name="select-channel"]').change(function () {
        if ($('#cova_form select[name="select-channel"]').val() == 'web') {
            $('#cova-type, #cova-siteid, #cova-environment, #cova-testcases').show();
  
            $("#testcasesData").attr('disabled', false);

            $('#cova-usecases').hide();
        } else if($('#cova_form select[name="select-channel"]').val() == ''){
            $('#cova-type, #cova-siteid, #cova-environment, #cova-phonenumber, #cova-phonenumber, #cova-usecases, #cova-testcases,#cova-validation').hide();
        
        } else if($('#cova_form select[name="select-channel"]').val() == 'sms'){
            $('#cova-siteid, #cova-environment, #cova-phonenumber, #cova-usecases, #cova-testcases').show();

            $('#cova-type').hide();
            console.log("testcases up");
        }
    });
    $('#cova_form #cova-usecases select[name="select-usecases"]').change(function () {
        if($('#cova_form select[name="select-usecases"]').val() == 'mannual'){
            $('#cova-validation').show();
            $("#testcasesData").attr('disabled', true);
        } else if($('#cova_form select[name="select-usecases"]').val() == 'automation'){
            $('#cova-validation').hide();
            $("#testcasesData").attr('disabled', false);
        }
    });

});

$(document).ready(function () {
$("#cova_details_tab").click(function(){
    console.log("The paragraph was clicked.");
    $("#cova_details_tab").hide();
    $('#cova_run_btn').show();
    // $("#editor").stop().fadeTo(1, 0.25);
   
  });
  $("#cova_previous_btn").click(function(){
    console.log("The previous was clicked.");
    // $("#editor").stop().fadeTo(1, 0.25);
    $('#cova_run_btn').hide();
    $("#cova_details_tab").show();
  });
});
$(document).ready(function () { 
    $('#testcasesData').chosen();
});

function covaFormData(){
    var channel = $('#channelData').val();
    
}
var select = document.getElementById("testcasesData"); 
var testcases = [ "happy path", "Account_selection_1x to SSN","Account_selection_2x" ,"Payment consent confirmaton_1x to SSN_Successful payment","Payment consent confirmation_2x", "Amount options_1x to SSN", "Amount options_2x", "Enter amount_1x to SSN", "Enter amount_2x", "Payment date options_1x to SSN", "Payment date options_2x", "Enter date_1x to SSN", "Enter date_2x", "Payment Source Confirmation__No_end flow", "Single Payment Source Confirmation_1x to SSN", "Single Payment Source Confirmation_2x","Multiple Payment Source_1x to SSN", "Multiple Payment Source_1x to SSN", "Payment authorization confirmation_1x to SSN", "Payment authorization confirmation_2x", "Change information_1x to SSN", "Change information_2x", "Change information_Date_SSN", "Change information_Date_2x", "Change information_PaymentSource(Multiple payment sources)_SSN", "Change information_PaymentSource_2x", "Change information_Amount_SSN", "Change information_Amount_2x", "Change information_StopPayment", "SSN_1x, SSN_2x", "SameDayPaymentReached_Date Options_1x", "No Outstanding balance", "Less than minimum payment validation_amount_1x to SSN", "More than outstanding balance", "No payment source", "Schedule payment morethan 45 days", "Multiple validation errors(More than outstanding balance and More than 45 days)"];


// Optional: Clear all existing options first:
select.innerHTML = "";
// Populate list with options:
for(var i = 0; i < testcases.length; i++) {
    var opt = testcases[i];
    select.innerHTML += "<option value=\"" + opt + "\">" + opt + "</option>";
}