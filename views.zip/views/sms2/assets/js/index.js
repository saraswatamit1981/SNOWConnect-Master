


var counter = 0;
var testcases = {}
var finalResult = [];

//random.innerHTML = memes[Math.floor(Math.random() * memes.length)];

/* Time */

var deviceTime = document.querySelector('.status-bar .time');
var messageTime = document.querySelectorAll('.message .time');

deviceTime.innerHTML = moment().format('h:mm');

setInterval(function () {
    deviceTime.innerHTML = moment().format('h:mm');
}, 1000);

for (var i = 0; i < messageTime.length; i++) {
    messageTime[i].innerHTML = moment().format('h:mm A');
}

/* Message */

//var form = document.querySelector('.conversation-compose');
var conversation = document.querySelector('.conversation-container');

//form.addEventListener('submit', newMessage);

$(document).ready(function () {
    $("span#siteId").text(getQueryStringValue("siteId").toUpperCase());
    $("#sendbutton").on("click", function () {
        newMessage();
    });
});

$('#userInput').keypress(function (e) {
    if (e.which == 13) {
        newMessage();
    }
});

function newMessage() {
    var input = document.getElementById("userInput").value;
    if (input) {
        var message = buildMessage(input);
        conversation.appendChild(message);
        //animateMessage(message);
        makeApiCall(input)
    }
    document.getElementById('userInput').value = ''
    conversation.scrollTop = conversation.scrollHeight;
    //e.preventDefault();
}

function getQueryStringValue(key) {
    return decodeURIComponent(window.location.search.replace(new RegExp("^(?:.*[&\\?]" + encodeURIComponent(key).replace(/[\.\+\*]/g, "\\$&") + "(?:\\=([^&]*))?)?.*$", "i"), "$1"));
}

async function excuteTestCase(inputs, inputData, tcase) {
    await new Promise(async (resolve, reject) => {
        setTimeout(() => {
            var i = 0;
            var l = inputs.input.length;
            (function iterator() {
                console.log(inputs.input[i]);
                inputData["msg"] = inputs.input[i];
                inputData["expectedOutPut"] = inputs.output[i];
                inputData["name"] = tcase;
                //var input = document.getElementById("userInput").value;
                var message = buildMessage(inputs.input[i]);
                conversation.appendChild(message);
                conversation.scrollTop = conversation.scrollHeight;
                excuteApiCall(inputData)
                if (++i < l) {
                    setTimeout(iterator, 12000);
                } else {
                    setTimeout(() => { return new Promise(resolve) }, 30000);
                }
            })();
        });
    });
}

function addReportTable(name) {
    var reportsTable = document.querySelector('.reportsTable');
    var element = document.createElement('div');
    // element.classList.add('covaTableTitle');
    element.innerHTML = '<span class ="covaTableTitle"><i>' + name + '</i></span>' +
        '<table  class="table table-bordered" id="' + name + 'Id" style ="margin-top:30px">' +
        '<thead class="grey lighten-2">' +
        '<tr>' +
        '<th scope="col">S.No</th>' +
        '<th scope="col">Input</th>' +
        '<th scope="col">Expected OutPut</th>' +
        '<th scope="col">Actual Output</th>' +
        '<th scope="col">Status</th>' +
        '<th scope="col">Percentage</th>' +
        '</tr>' +
        '</thead>' +
        '<tbody>' +

        '</tbody>' +
        '</table>' +
        '</div>';
    reportsTable.appendChild(element);
}


async function excuteTestCases() {
    testcases = new GetJsonEditor("#jsonIde");
    var inputData = {
        "phoneNumber": testcases.phoneNumber,
        "siteId": testcases.siteId,
        "url": environments[testcases.env].url,
        "token": environments[testcases.env].token
    }
    $("span#siteId").text(testcases.siteId);
    //console.log(JSON.stringify(inputData));
    var loopKeys = Object.keys(testcases.senarios);

    let items = loopKeys;
    let a = 0;
    await new Promise(async (resolve, reject) => {
        //$("span#covatableId").text(items[a]);
        addReportTable(items[a])
        let funSync = async () => {
            await excuteTestCase(testcases.senarios[items[a]], inputData, items[a])
            a++;
            if (a == items.length) {
                resolve();
            } else {
                addReportTable(items[a])
                funSync();
            }
        }
        funSync();
    })
    console.log("Final result: " + JSON.stringify(finalResult));
}

function excuteApiCall(inputData) {
    var body = {
        "from": {
            "id": "+1" + inputData.phoneNumber + "@" + inputData.siteId
        },
        "to": {
            "id": "st-5bda0ad1-6529-5279-948e-7d70bf790d80"
        },
        "message": {
            "text": inputData.msg
        },
        "session": {
            "new": true
        },
        "siteId": inputData.siteId,
        "channelId": "SMSAG",
        "uuid": counter + "_" + inputData.phoneNumber + "_" + inputData.siteId + "_" + Math.round(new Date().getTime() / 1000)
    }
    counter = counter + 1;

    var result = {
        "input": inputData.msg,
        "expectedOutPut": inputData.expectedOutPut,
        "index": counter,
        "name": inputData.name
    }
    $.ajax({
        url: inputData.url,
        type: "POST",
        dataType: "json",
        headers: {
            "Authorization": inputData.token,
            "Content-Type": "application/json"
        },
        data: JSON.stringify(body),
        success: function (response) {
            console.log(response);
            var responseText = response.text;
            if (Array.isArray(responseText)) {
                responseText.forEach(function (element) {
                    console.log(" in Array " + element + " typeof element" + typeof element);
                    let msg;
                    if (IsJsonString(element)) {
                        msg = JSON.parse(element).textmessage;
                        if (msg.textmessage) {
                            msg = msg.textmessage;
                        }
                    } else if (typeof element === 'object') {
                        msg = element.textmessage;
                    } else {
                        msg = element;
                    }
                    let message = buildIncomingMessage(msg);
                    conversation.appendChild(message);
                    result["actualOutput"] = msg
                });
            } else if (responseText instanceof Object) {
                console.log(" in object " + element);

                let message = buildIncomingMessage(JSON.parse(responseText).text);
                conversation.appendChild(message);
                result["actualOutput"] = JSON.parse(responseText).text
                //animateMessage(message);
            } else {
                console.log(" in default " + responseText + " type of: " + typeof responseText);
                let msg;
                if (IsJsonString(responseText)) {
                    msg = JSON.parse(responseText).textmessage;
                    if (!msg) {
                        msg = JSON.parse(responseText).text;
                    }
                } else {
                    msg = responseText;
                }

                let message = buildIncomingMessage(msg);
                conversation.appendChild(message);
                result["actualOutput"] = msg
                //animateMessage(message);
            };
            conversation.scrollTop = conversation.scrollHeight;
            if (result.expectedOutPut && result.expectedOutPut !== "@@@@" && result.actualOutput) {
                // alert(s.replace(new RegExp("[0-9]","g"), "X"));
                let eo = result.expectedOutPut.replace(new RegExp("[0-9]", "g"), "X");
                let ao = result.actualOutput.replace(new RegExp("[0-9]", "g"), "X");
                let score = stringSimilarity.compareTwoStrings(eo, ao);
                result["score"] = Number.parseFloat(score).toFixed(2);
                if (score > 0.7) {
                    result["status"] = "pass";
                } else {
                    result["status"] = "fail";
                }
            } else if (result.expectedOutPut === "@@@@") {
                result["status"] = "pass";
                //console.log("Pass For" + uuid + "__Actual Output: " + botResponseText + " expected outPut: " + expectedOutPut);
            } else {
                result["status"] = "fail";
                //console.log("Failed For" + uuid + "__Actual Output: " + botResponseText + " expected outPut: " + expectedOutPut);
            }
            $("#covatableId").show();
            addDataToTable(result)
            finalResult.push(result);
        },
        error: function () {
            console.log("error");
        }
    });
}

function makeApiCall(queryString) {

    //var type = getQueryStringValue("type").toLocaleLowerCase();
    var siteId = getQueryStringValue("siteId").toLocaleLowerCase();
    var phoneNumber = getQueryStringValue("phoneNumber")


    var body = {
        "from": {
            "id": "+1" + phoneNumber + "@" + siteId
        },
        "to": {
            "id": "st-5bda0ad1-6529-5279-948e-7d70bf790d80"
        },
        "message": {
            "text": queryString
        },
        "session": {
            "new": true
        },
        "siteId": siteId,
        "channelId": "SMSAG",
        "uuid": counter + "_" + phoneNumber + "_" + siteId + "_" + Math.round(new Date().getTime() / 1000)
    }
    counter = counter + 1;
    console.log(JSON.stringify(body));

    $.ajax({
        url: 'https://b172935-vip.nam.nsroot.net/chatbot/hooks/st-fc77c68b-a12c-5024-aae0-7aa1680690fa',
        type: "POST",
        dataType: "json",
        headers: {
            "Authorization": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwiYXBwSWQiOiJjcy1iODAxZDRlOS1iNTEwLTU0ZDYtOWNjNC0xNDJmZDhlN2NiMWQifQ.-Yoh1De6cltL3WFpN7T_95Y6n-0lt_n2dIKXjFdWatU",
            "Content-Type": "application/json"
        },
        data: JSON.stringify(body),
        success: function (response) {
            console.log(response);
            var responseText = response.text;
            if (Array.isArray(responseText)) {
                responseText.forEach(function (element) {
                    console.log(" in Array " + element + " typeof element" + typeof element);
                    let msg;
                    if (IsJsonString(element)) {
                        msg = JSON.parse(element).textmessage;
                        if (msg.textmessage) {
                            msg = msg.textmessage;
                        }
                    } else if (typeof element === 'object') {
                        msg = element.textmessage;
                    } else {
                        msg = element;
                    }
                    let message = buildIncomingMessage(msg);
                    conversation.appendChild(message);
                    //animateMessage(message);

                });
            } else if (responseText instanceof Object) {
                console.log(" in object " + element);

                let message = buildIncomingMessage(JSON.parse(responseText).text);
                conversation.appendChild(message);
                //animateMessage(message);
            } else {
                console.log(" in default " + responseText + " type of: " + typeof responseText);
                let msg;
                if (IsJsonString(responseText)) {
                    msg = JSON.parse(responseText).textmessage;
                    if (!msg) {
                        msg = JSON.parse(responseText).text;
                    }
                } else {
                    msg = responseText;
                }

                let message = buildIncomingMessage(msg);
                conversation.appendChild(message);
                //animateMessage(message);
            };
            conversation.scrollTop = conversation.scrollHeight;
        },
        error: function () {
            console.log("error");
        }
    });
}

function buildMessage(text) {
    var element = document.createElement('div');
    element.classList.add('message', 'sent');
    element.innerHTML = text +
        '<span class="metadata">' +
        '<span class="sentTime">' + moment().format('h:mm A') + '</span>' +
        '</span>';

    return element;
}

function urlify(text) {
    var urlRegex = /(https?:\/\/[^\s]+)/g;
    return text.replace(urlRegex, function (url) {
        return '<a href="' + url + '">' + url + '</a>';
    })
}

var environments = {
    "DIT": {
        "url": "https://b172935-vip.nam.nsroot.net/chatbot/hooks/st-fc77c68b-a12c-5024-aae0-7aa1680690fa",
        "token": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwiYXBwSWQiOiJjcy1iODAxZDRlOS1iNTEwLTU0ZDYtOWNjNC0xNDJmZDhlN2NiMWQifQ.-Yoh1De6cltL3WFpN7T_95Y6n-0lt_n2dIKXjFdWatU",
        "botId": "st-fc77c68b-a12c-5024-aae0-7aa1680690fa"
    },
    "UAT": {
        "url": "https://uat.botbuilder.consumerna.citigroup.net/chatbot/hooks/st-5bda0ad1-6529-5279-948e-7d70bf790d80",
        "token": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwiYXBwSWQiOiJjcy0yYzk4ZGI0Zi1lNjQ5LTUzMTItOTk2Yi1jNDk5NmViZDVkYTYifQ.cEtnafkPuwgC7ef5igbaWlz_khIUfNhHwo_zg8nZGq4",
        "botId": "st-5bda0ad1-6529-5279-948e-7d70bf790d80"
    }
}


function buildIncomingMessage(text) {
    console.log('buildIncomingMessage: ' + text);
    //text = text.split("#").join("");
    text = text.split("\n").join("<br>");
    text = urlify(text);
    if (!text) {
        text = "Looks like I had a technical issue on my end and I need to back up a sec. What do you need help with?";
    }
    var element = document.createElement('div');
    element.classList.add('message', 'received');
    element.innerHTML = '<div>' + text + '</div>'
    '<span class="metadata">' +
        '<span class="time">' + moment().format('h:mm A') + '</span>' +
        '</span>';

    return element;
}


function IsJsonString(str) {
    try {
        JSON.parse(str);
    } catch (e) {
        return false;
    }
    return true;
}

function animateMessage(message) {
    setTimeout(function () {
        var tick = message.querySelector('.tick');
        tick.classList.remove('tick-animation');
    }, 500);
}
var sampleInput = {

    "phoneNumber": "9729988092",
    "siteId": "PLCN_BESTBUY",
    "environment": "DIT",

    "happyPath": {


        "input": [

            // "ClearSession",

            "Discard all",

            // "Hi",

            //"1183",

            "make payment",

            "1183",

            "Yes",

            "4",

            "3",

            "3",

            "07/25/2020",

            "Yes",

            "Yes",

            "Yes",

            "6789"

        ],

        "output": [

            // "context",

            "discarding the task for now",

            //"*",

            // "Hi, I'm your virtual guide to ",

            // "@@@@",

            "Which account do you want to pay?",

            "Before we begin, you should know that your account information, including last statement balance, current balance and minimum payment due, will be displayed on this device and any other device where you receive text messages. Do you want to continue and allow this information to be displayed?",

            "It looks like",

            "Please enter the amount of payment greater than $1 in $xx.xx format",

            "When do you want to make a payment",

            "Please enter a valid date in MM/DD/YYYY format",

            "We have your  account information from previous payments you have made",

            "Almost done: let's confirm the payment information and get your authorization to make the payment.",

            "If you choose to pay less than the Minimum Payment Due and do not make any additional payments, your account will be past due. You will also pay more in interest and it will take you longer to pay off your balance.\n\nTo avoid a late fee, schedule your Payment Date no later than your Payment Due Date.$$$$2/2. Would you like to continue and make a payment. \nText Y to make a payment\nText N to stop the payment communication.",

            "Do I have your authorization to take this payment now?\nPlease text the last 4 digits of the primary account holder's SSN to authorize this payment.\nText N if you do not authorize this payment.",

            "Your payment was successful $$$$ Is there anything else I can help you with today?"

        ]

    }

};
//   $('#jsonIde').jsonViewer(sampleInput);
new JsonEditor('#jsonIde', sampleInput);


$(document).ready(function () {
    $('#cova_run_btn').hide();

    // dropdown list onload
    $('#cova-type, #cova-siteid, #cova-environment, #cova-phonenumber, #cova-usecases,#cova-testcases, #cova-validation').hide();

    // $(" #editor ").fadeTo(1, 0.25);
    // $(" #device ").fadeTo(1, 0.25);
    // $("#editor").children().prop('disabled',true);
    // document.getElementById("editor").disabled = true;

    $('#cova_form select[name="select-channel"]').change(function () {
        if ($('#cova_form select[name="select-channel"]').val() == 'web') {
            $('#cova-type, #cova-siteid, #cova-environment, #cova-testcases').show();

            $("#testcasesData").attr('disabled', false);

            $('#cova-usecases').hide();
        } else if ($('#cova_form select[name="select-channel"]').val() == '') {
            $('#cova-type, #cova-siteid, #cova-environment, #cova-phonenumber, #cova-phonenumber, #cova-usecases, #cova-testcases,#cova-validation').hide();

        } else if ($('#cova_form select[name="select-channel"]').val() == 'sms') {
            $('#cova-siteid, #cova-environment, #cova-phonenumber, #cova-usecases, #cova-testcases').show();

            $('#cova-type').hide();
            console.log("testcases up");
        }
    });
    $('#cova_form #cova-usecases select[name="select-usecases"]').change(function () {
        if ($('#cova_form select[name="select-usecases"]').val() == 'mannual') {
            $('#cova-validation').show();
            $("#testcasesData").attr('disabled', true);
        } else if ($('#cova_form select[name="select-usecases"]').val() == 'automation') {
            $('#cova-validation').hide();
            $("#testcasesData").attr('disabled', false);
        }
    });

});


$("#cova_details_tab").click(function () {
    console.log("The paragraph was clicked.");
    $("#cova_details_tab").hide();
    $('#cova_run_btn').show();
    // $("#editor").stop().fadeTo(1, 0.25);

});
$("#cova_previous_btn").click(function () {
    console.log("The previous was clicked.");
    // $("#editor").stop().fadeTo(1, 0.25);
    $('#cova_run_btn').hide();
    $("#cova_details_tab").show();
});

$(document).ready(function () {
    $('#testcasesData').chosen();
});

function covaFormData() {
    //var channel = $('#channelData').val();
    var env = $('#environmentData').val();
    var siteidData = $('#siteidData').val();
    var phoneNumber = $('#phoneNumber').val();
    var senarios = {};
    var selectedTestCases = Array.from(document.getElementById("testcasesData").options).filter(option => option.selected).map(option => option.value);

    for (var tc of selectedTestCases) {
        let obj = {
        }
        obj[tc] = testCasesConfig[tc]
        senarios = Object.assign(senarios, obj)
    }

    testcases = {
        "phoneNumber": phoneNumber,
        "siteId": siteidData,
        "env": env,
        "senarios": senarios
    }

    new JsonEditor('#jsonIde', testcases);
}
var select = document.getElementById("testcasesData");
//var testcases = ["happy path", "Account_selection_1x to SSN", "Account_selection_2x", "Payment consent confirmaton_1x to SSN_Successful payment", "Payment consent confirmation_2x", "Amount options_1x to SSN", "Amount options_2x", "Enter amount_1x to SSN", "Enter amount_2x", "Payment date options_1x to SSN", "Payment date options_2x", "Enter date_1x to SSN", "Enter date_2x", "Payment Source Confirmation__No_end flow", "Single Payment Source Confirmation_1x to SSN", "Single Payment Source Confirmation_2x", "Multiple Payment Source_1x to SSN", "Multiple Payment Source_1x to SSN", "Payment authorization confirmation_1x to SSN", "Payment authorization confirmation_2x", "Change information_1x to SSN", "Change information_2x", "Change information_Date_SSN", "Change information_Date_2x", "Change information_PaymentSource(Multiple payment sources)_SSN", "Change information_PaymentSource_2x", "Change information_Amount_SSN", "Change information_Amount_2x", "Change information_StopPayment", "SSN_1x, SSN_2x", "SameDayPaymentReached_Date Options_1x", "No Outstanding balance", "Less than minimum payment validation_amount_1x to SSN", "More than outstanding balance", "No payment source", "Schedule payment morethan 45 days", "Multiple validation errors(More than outstanding balance and More than 45 days)"];




var testCasesConfig = {
    "HappyPath": {
        "input": [
            "discard all",
            "clearsession",
            "Hi",
            "8098",
            "pay",
            "8098",
            "yes",
            "4",
            "2",
            "2",
            "1",
            "yes",
            "6789"
        ],
        "output": [
            "@@@@",
            "@@@@",
            "@@@@",
            "@@@@",
            "Which account do you want to pay?  Please text\n#1-Account ending in 9994\n#2-Account ending in 7935\n#3-Account ending in 8098\n#4-Account ending in 0222\n#5-Account ending in 6591\n#6-Account ending in 8310\n#7-Account ending in 0198\n#8-Account ending in 0214",
            "Before we begin, you should know that your account information, including last statement balance, current balance and minimum payment due, will be displayed on this device and any other device where you receive text messages. Do you want to continue and allow this information to be displayed?",
            "It looks like:\nYour Minimum Due is $0.00\nYour Last Statement Balance was $13492.46\nYour Current Balance is $2000.00\n\nWhat type of payment would you like to make?\nText 1 for Minimum Due\nText 2 for Last Statement Balance\nText 3 for Current Balance\nText 4 for Other Amount",
            "Please enter the amount of payment greater than $1 in $xx.xx format",
            "When do you want to make a payment? \n            Text 1 - Due Date 08/02/2020\n            Text 2 - Today 07/15/2020\n         Text 3 - A different date",
            "We have your account information from previous payments you have made\nWhich account do you want to use for your payment?  Please text #\n1- Account ending in 3232\n2- Account ending in 6789",
            "Almost done: let's confirm the payment information and get your authorization to make the payment. To confirm, today is 07/15/2020 and you are agreeing to a one-time payment of $2.00 towards your The Home Depot® Consumer Credit Card ending in 8098, from your bank account ending in 3232 posting on 07/15/2020\n\nYou may cancel or change this payment online or by calling us at the number on the back of your card before 5:00 pm Eastern time on the day of your scheduled payment.\n\nText Y if the payment information above is correct\nText N to make changes",
            "Do I have your authorization to schedule this payment now? \n  Please text the last 4 digits of the primary account holder's SSN to authorize this payment.\n Text N if you do not authorize this payment.",
            "Thank you! Your payment was scheduled successfully. Your confirmation number is: 420168656641713. You can save this message for your records. \n\nEnrolling in AutoPay would save you time in the future. Click the link below to register\npay.homedepotconsumer.accountonline.com\n\nIs there anything else I can help you with today?"
        ]
    },

    "Account_selection_1x_to_SSN": {
        "input": [
            "discard all",
            "clearsession",
            "Hi",
            "8098",
            "pay",
            "23",
            "8098",
            "yes",
            "4",
            "2",
            "3",
            "08/01/2020",
            "1",
            "yes"
        ],
        "output": [
            "@@@@",
            "@@@@",
            "@@@@",
            "@@@@",
            "Which account do you want to pay?  Please text\n#1-Account ending in 9994\n#2-Account ending in 7935\n#3-Account ending in 8098\n#4-Account ending in 0222\n#5-Account ending in 6591\n#6-Account ending in 8310\n#7-Account ending in 0198\n#8-Account ending in 0214",
            "You have not selected a valid account, please text\n#1-Account ending in 9994\n#2-Account ending in 7935\n#3-Account ending in 8098\n#4-Account ending in 0222\n#5-Account ending in 6591\n#6-Account ending in 8310\n#7-Account ending in 0198\n#8-Account ending in 0214",
            "Before we begin, you should know that your account information, including last statement balance, current balance and minimum payment due, will be displayed on this device and any other device where you receive text messages. Do you want to continue and allow this information to be displayed?",
            "It looks like:\nYour Minimum Due is $0.00\nYour Last Statement Balance was $13492.46\nYour Current Balance is $2000.00\n\nWhat type of payment would you like to make?\nText 1 for Minimum Due\nText 2 for Last Statement Balance\nText 3 for Current Balance\nText 4 for Other Amount",
            "Please enter the amount of payment greater than $1 in $xx.xx format",
            "When do you want to make a payment? \n            Text 1 - Due Date 08/02/2020\n            Text 2 - Today 07/14/2020\n         Text 3 - A different date",
            "Please enter a valid date in MM/DD/YYYY format",
            "We have your account information from previous payments you have made\nWhich account do you want to use for your payment?  Please text #\n1- Account ending in 3232\n2- Account ending in 6789",
            "Almost done: let's confirm the payment information and get your authorization to make the payment. To confirm, today is 07/14/2020 and you are agreeing to a one-time payment of $2.00 towards your The Home Depot® Consumer Credit Card ending in 8098, from your bank account ending in 3232 posting on 08/01/2020\n\nYou may cancel or change this payment online or by calling us at the number on the back of your card before 5:00 pm Eastern time on the day of your scheduled payment.\n\nText Y if the payment information above is correct\nText N to make changes",
            "Do I have your authorization to schedule this payment now? \n  Please text the last 4 digits of the primary account holder's SSN to authorize this payment.\n Text N if you do not authorize this payment."
        ]
    },

    "Account_selection_2x": {
        "input": [
            "discard all",
            "clearsession",
            "Hi",
            "8098",
            "pay",
            "23",
            "abcd"
        ],
        "output": [
            "@@@@",
            "@@@@",
            "@@@@",
            "@@@@",
            "Which account do you want to pay?  Please text\n#1-Account ending in 9994\n#2-Account ending in 7935\n#3-Account ending in 8098\n#4-Account ending in 0222\n#5-Account ending in 6591\n#6-Account ending in 8310\n#7-Account ending in 0198\n#8-Account ending in 0214",
            "You have not selected a valid account, please text\n#1-Account ending in 9994\n#2-Account ending in 7935\n#3-Account ending in 8098\n#4-Account ending in 0222\n#5-Account ending in 6591\n#6-Account ending in 8310\n#7-Account ending in 0198\n#8-Account ending in 0214",
            "It appears that we will not be able to help you set up a payment via text. Please follow the link below to make a payment or contact the customer service number on the back of your credit card to make the payment. pay.homedepotconsumer.accountonline.com\n\nIs there anything else I can help you with today?"
        ]
    },
    "Payment_consent_confirmaton_1x to SSN": {
        "input": [
            "discard all",
            "clearsession",
            "Hi",
            "8098",
            "pay",
            "8098",
            "abcd",
            "yes",
            "4",
            "2",
            "3",
            "08/01/2020",
            "1",
            "yes"
        ],
        "output": [
            "@@@@",
            "@@@@",
            "@@@@",
            "@@@@",
            "Which account do you want to pay?  Please text\n#1-Account ending in 9994\n#2-Account ending in 7935\n#3-Account ending in 8098\n#4-Account ending in 0222\n#5-Account ending in 6591\n#6-Account ending in 8310\n#7-Account ending in 0198\n#8-Account ending in 0214",
            "Before we begin, you should know that your account information, including last statement balance, current balance and minimum payment due, will be displayed on this device and any other device where you receive text messages. Do you want to continue and allow this information to be displayed?",
            "Before we begin, you should know that your account information, including last statement balance, current balance and minimum payment due, will be displayed on this device and any other device where you receive text messages. Do you want to continue and allow this information to be displayed?",
            "It looks like:\nYour Minimum Due is $0.00\nYour Last Statement Balance was $13492.46\nYour Current Balance is $2000.00\n\nWhat type of payment would you like to make?\nText 1 for Minimum Due\nText 2 for Last Statement Balance\nText 3 for Current Balance\nText 4 for Other Amount",
            "Please enter the amount of payment greater than $1 in $xx.xx format",
            "When do you want to make a payment? \n            Text 1 - Due Date 08/02/2020\n            Text 2 - Today 07/14/2020\n         Text 3 - A different date",
            "Please enter a valid date in MM/DD/YYYY format",
            "We have your account information from previous payments you have made\nWhich account do you want to use for your payment?  Please text #\n1- Account ending in 3232\n2- Account ending in 6789",
            "Almost done: let's confirm the payment information and get your authorization to make the payment. To confirm, today is 07/14/2020 and you are agreeing to a one-time payment of $2.00 towards your The Home Depot® Consumer Credit Card ending in 8098, from your bank account ending in 3232 posting on 08/01/2020n\nYou may cancel or change this payment online or by calling us at the number on the back of your card before 5:00 pm Eastern time on the day of your scheduled payment.\n\nText Y if the payment information above is correct\nText N to make changes",
            "Do I have your authorization to schedule this payment now? \n  Please text the last 4 digits of the primary account holder's SSN to authorize this payment.\n Text N if you do not authorize this payment."
        ]
    },
    "Payment_consent_confirmaton_2x": {
        "input": [
            "discard all",
            "clearsession",
            "Hi",
            "8098",
            "pay",
            "8098",
            "abcd",
            "123456"
        ],
        "output": [
            "@@@@",
            "@@@@",
            "@@@@",
            "@@@@",
            "Which account do you want to pay?  Please text\n#1-Account ending in 9994\n#2-Account ending in 7935\n#3-Account ending in 8098\n#4-Account ending in 0222\n#5-Account ending in 6591\n#6-Account ending in 8310\n#7-Account ending in 0198\n#8-Account ending in 0214",
            "Before we begin, you should know that your account information, including last statement balance, current balance and minimum payment due, will be displayed on this device and any other device where you receive text messages. Do you want to continue and allow this information to be displayed?",
            "Before we begin, you should know that your account information, including last statement balance, current balance and minimum payment due, will be displayed on this device and any other device where you receive text messages. Do you want to continue and allow this information to be displayed?",
            "It appears that we will not be able to help you set up a payment via text. Please follow the link below to make a payment or contact the customer service number on the back of your credit card to make the payment. pay.homedepotconsumer.accountonline.com\n\nIs there anything else I can help you with today?"
        ]
    },

    "Amount_options_1x_to_SSN": {
        "input": [
            "discard all",
            "clearsession",
            "Hi",
            "8098",
            "pay",
            "8098",
            "yes",
            "abcd",
            "4",
            "2",
            "3",
            "08/01/2020",
            "1",
            "yes"
        ],
        "output": [
            "@@@@",
            "@@@@",
            "@@@@",
            "@@@@",
            "Which account do you want to pay?  Please text\n#1-Account ending in 9994\n#2-Account ending in 7935\n#3-Account ending in 8098\n#4-Account ending in 0222\n#5-Account ending in 6591\n#6-Account ending in 8310\n#7-Account ending in 0198\n#8-Account ending in 0214",
            "Before we begin, you should know that your account information, including last statement balance, current balance and minimum payment due, will be displayed on this device and any other device where you receive text messages. Do you want to continue and allow this information to be displayed?",
            "It looks like:\nYour Minimum Due is $0.00\nYour Last Statement Balance was $13492.46\nYour Current Balance is $2000.00\n\nWhat type of payment would you like to make?\nText 1 for Minimum Due\nText 2 for Last Statement Balance\nText 3 for Current Balance\nText 4 for Other Amount",
            "You have not selected a valid option, please\nText 1 for minimum payment due\nText 2 for last statement balance in full due\nText 3 for total current balance\nText 4 for Other Amount",
            "Please enter the amount of payment greater than $1 in $xx.xx format",
            "When do you want to make a payment? \n            Text 1 - Due Date 08/02/2020\n            Text 2 - Today 07/14/2020\n         Text 3 - A different date",
            "Please enter a valid date in MM/DD/YYYY format",
            "We have your account information from previous payments you have made\nWhich account do you want to use for your payment?  Please text #\n1- Account ending in 3232\n2- Account ending in 6789",
            "Almost done: let's confirm the payment information and get your authorization to make the payment. To confirm, today is 07/14/2020 and you are agreeing to a one-time payment of $2.00 towards your The Home Depot® Consumer Credit Card ending in 8098, from your bank account ending in 3232 posting on 08/01/2020\n\nYou may cancel or change this payment online or by calling us at the number on the back of your card before 5:00 pm Eastern time on the day of your scheduled payment.\n\nText Y if the payment information above is correct\nText N to make changes",
            "Do I have your authorization to schedule this payment now? \n  Please text the last 4 digits of the primary account holder's SSN to authorize this payment.\n Text N if you do not authorize this payment."
        ]
    },

    "Amount_options_2x": {
        "input": [
            "discard all",
            "clearsession",
            "Hi",
            "8098",
            "pay",
            "8098",
            "yes",
            "abcd",
            "abcd"
        ],
        "output": [
            "@@@@",
            "@@@@",
            "@@@@",
            "@@@@",
            "Which account do you want to pay?  Please text\n#1-Account ending in 9994\n#2-Account ending in 7935\n#3-Account ending in 8098\n#4-Account ending in 0222\n#5-Account ending in 6591\n#6-Account ending in 8310\n#7-Account ending in 0198\n#8-Account ending in 0214",
            "Before we begin, you should know that your account information, including last statement balance, current balance and minimum payment due, will be displayed on this device and any other device where you receive text messages. Do you want to continue and allow this information to be displayed?",
            "It looks like:\nYour Minimum Due is $0.00\nYour Last Statement Balance was $13492.46\nYour Current Balance is $2000.00\n\nWhat type of payment would you like to make?\nText 1 for Minimum Due\nText 2 for Last Statement Balance\nText 3 for Current Balance\nText 4 for Other Amount",
            "You have not selected a valid option, please\nText 1 for minimum payment due\nText 2 for last statement balance in full due\nText 3 for total current balance\nText 4 for Other Amount",
            "It appears that we will not be able to help you set up a payment via text. Please follow the link below to make a payment or contact the customer service number on the back of your credit card to make the payment. pay.homedepotconsumer.accountonline.com\n\nIs there anything else I can help you with today?"
        ]
    },

    "Enter_amount_1x_to_SSN": {
        "input": [
            "discard all",
            "clearsession",
            "Hi",
            "8098",
            "pay",
            "8098",
            "yes",
            "4",
            "asdf",
            "2",
            "3",
            "08/01/2020",
            "1",
            "yes"
        ],
        "output": [
            "@@@@",
            "@@@@",
            "@@@@",
            "@@@@",
            "Which account do you want to pay?  Please text\n#1-Account ending in 9994\n#2-Account ending in 7935\n#3-Account ending in 8098\n#4-Account ending in 0222\n#5-Account ending in 6591\n#6-Account ending in 8310\n#7-Account ending in 0198\n#8-Account ending in 0214",
            "Before we begin, you should know that your account information, including last statement balance, current balance and minimum payment due, will be displayed on this device and any other device where you receive text messages. Do you want to continue and allow this information to be displayed?",
            "It looks like:\nYour Minimum Due is $0.00\nYour Last Statement Balance was $13492.46\nYour Current Balance is $2000.00\n\nWhat type of payment would you like to make?\nText 1 for Minimum Due\nText 2 for Last Statement Balance\nText 3 for Current Balance\nText 4 for Other Amount",
            "Please enter the amount of payment greater than $1 in $xx.xx format",
            "You have not entered a valid amount, please enter a valid amount in $xx.xx format greater than $1",
            "When do you want to make a payment? \n            Text 1 - Due Date 08/02/2020\n            Text 2 - Today 07/14/2020\n         Text 3 - A different date",
            "Please enter a valid date in MM/DD/YYYY format",
            "We have your account information from previous payments you have made\nWhich account do you want to use for your payment?  Please text #\n1- Account ending in 3232\n2- Account ending in 6789",
            "Almost done: let's confirm the payment information and get your authorization to make the payment. To confirm, today is 07/14/2020 and you are agreeing to a one-time payment of $2.00 towards your The Home Depot® Consumer Credit Card ending in 8098, from your bank account ending in 3232 posting on 08/01/2020\n\nYou may cancel or change this payment online or by calling us at the number on the back of your card before 5:00 pm Eastern time on the day of your scheduled payment.\n\nText Y if the payment information above is correct\nText N to make changes",
            "Do I have your authorization to schedule this payment now? \n  Please text the last 4 digits of the primary account holder's SSN to authorize this payment.\n Text N if you do not authorize this payment."
        ]
    },
    "Enter_amount_2x": {
        "input": [
            "discard all",
            "clearsession",
            "Hi",
            "8098",
            "pay",
            "8098",
            "yes",
            "4",
            "asdf",
            "asdf"
        ],
        "output": [
            "@@@@",
            "@@@@",
            "@@@@",
            "@@@@",
            "Which account do you want to pay?  Please text\n#1-Account ending in 9994\n#2-Account ending in 7935\n#3-Account ending in 8098\n#4-Account ending in 0222\n#5-Account ending in 6591\n#6-Account ending in 8310\n#7-Account ending in 0198\n#8-Account ending in 0214",
            "Before we begin, you should know that your account information, including last statement balance, current balance and minimum payment due, will be displayed on this device and any other device where you receive text messages. Do you want to continue and allow this information to be displayed?",
            "It looks like:\nYour Minimum Due is $0.00\nYour Last Statement Balance was $13492.46\nYour Current Balance is $2000.00\n\nWhat type of payment would you like to make?\nText 1 for Minimum Due\nText 2 for Last Statement Balance\nText 3 for Current Balance\nText 4 for Other Amount",
            "Please enter the amount of payment greater than $1 in $xx.xx format",
            "You have not entered a valid amount, please enter a valid amount in $xx.xx format greater than $1",
            "It appears that we will not be able to help you set up a payment via text. Please follow the link below to make a payment or contact the customer service number on the back of your credit card to make the payment. pay.homedepotconsumer.accountonline.com\n\nIs there anything else I can help you with today?"
        ]
    },

    "Payment_date_options_1x_to_SSN": {
        "input": [
            "discard all",
            "clearsession",
            "Hi",
            "8098",
            "pay",
            "8098",
            "yes",
            "4",
            "2",
            "abcd",
            "3",
            "08/01/2020",
            "1",
            "yes"
        ],
        "output": [
            "@@@@",
            "@@@@",
            "@@@@",
            "@@@@",
            "Which account do you want to pay?  Please text\n#1-Account ending in 9994\n#2-Account ending in 7935\n#3-Account ending in 8098\n#4-Account ending in 0222\n#5-Account ending in 6591\n#6-Account ending in 8310\n#7-Account ending in 0198\n#8-Account ending in 0214",
            "Before we begin, you should know that your account information, including last statement balance, current balance and minimum payment due, will be displayed on this device and any other device where you receive text messages. Do you want to continue and allow this information to be displayed?",
            "It looks like:\nYour Minimum Due is $0.00\nYour Last Statement Balance was $13492.46\nYour Current Balance is $2000.00\n\nWhat type of payment would you like to make?\nText 1 for Minimum Due\nText 2 for Last Statement Balance\nText 3 for Current Balance\nText 4 for Other Amount",
            "Please enter the amount of payment greater than $1 in $xx.xx format",
            "When do you want to make a payment? \n            Text 1 - Due Date 08/02/2020\n            Text 2 - Today 07/14/2020\n         Text 3 - A different date",
            "You have not selected a valid option, please\n            Text 1 to schedule the payment on the due date 08/02/2020\n            Text 2 to schedule the payment for today 07/14/2020\n            Text 3 to schedule the payment on another day",
            "Please enter a valid date in MM/DD/YYYY format",
            "We have your account information from previous payments you have made\nWhich account do you want to use for your payment?  Please text #\n1- Account ending in 3232\n2- Account ending in 6789",
            "Almost done: let's confirm the payment information and get your authorization to make the payment. To confirm, today is 07/14/2020 and you are agreeing to a one-time payment of $2.00 towards your The Home Depot® Consumer Credit Card ending in 8098, from your bank account ending in 3232 posting on 08/01/2020\n\nYou may cancel or change this payment online or by calling us at the number on the back of your card before 5:00 pm Eastern time on the day of your scheduled payment.\n\nText Y if the payment information above is correct\nText N to make changes",
            "Do I have your authorization to schedule this payment now? \n  Please text the last 4 digits of the primary account holder's SSN to authorize this payment.\n Text N if you do not authorize this payment."
        ]
    },
    "Payment_date_options_2x": {
        "input": [
            "discard all",
            "clearsession",
            "Hi",
            "8098",
            "pay",
            "8098",
            "yes",
            "4",
            "2",
            "abcd",
            "abcd"
        ],
        "output": [
            "@@@@",
            "@@@@",
            "@@@@",
            "@@@@",
            "Which account do you want to pay?  Please text\n#1-Account ending in 9994\n#2-Account ending in 7935\n#3-Account ending in 8098\n#4-Account ending in 0222\n#5-Account ending in 6591\n#6-Account ending in 8310\n#7-Account ending in 0198\n#8-Account ending in 0214",
            "Before we begin, you should know that your account information, including last statement balance, current balance and minimum payment due, will be displayed on this device and any other device where you receive text messages. Do you want to continue and allow this information to be displayed?",
            "It looks like:\nYour Minimum Due is $0.00\nYour Last Statement Balance was $13492.46\nYour Current Balance is $2000.00\n\nWhat type of payment would you like to make?\nText 1 for Minimum Due\nText 2 for Last Statement Balance\nText 3 for Current Balance\nText 4 for Other Amount",
            "Please enter the amount of payment greater than $1 in $xx.xx format",
            "When do you want to make a payment? \n            Text 1 - Due Date 08/02/2020\n            Text 2 - Today 07/14/2020\n         Text 3 - A different date",
            "You have not selected a valid option, please\n            Text 1 to schedule the payment on the due date 08/02/2020\n            Text 2 to schedule the payment for today 07/14/2020\n            Text 3 to schedule the payment on another day",
            "Please enter a valid date in MM/DD/YYYY format",
            "It appears that we will not be able to help you set up a payment via text. Please follow the link below to make a payment or contact the customer service number on the back of your credit card to make the payment. pay.homedepotconsumer.accountonline.com\n\nIs there anything else I can help you with today?"
        ]
    },

    "Enter_date_1x_to_SSN": {
        "input": [
            "discard all",
            "clearsession",
            "Hi",
            "8098",
            "pay",
            "8098",
            "yes",
            "4",
            "2",
            "3",
            "7/7/7",
            "08/01/2020",
            "1",
            "yes"
        ],
        "output": [
            "@@@@",
            "@@@@",
            "@@@@",
            "@@@@",
            "Which account do you want to pay?  Please text\n#1-Account ending in 9994\n#2-Account ending in 7935\n#3-Account ending in 8098\n#4-Account ending in 0222\n#5-Account ending in 6591\n#6-Account ending in 8310\n#7-Account ending in 0198\n#8-Account ending in 0214",
            "Before we begin, you should know that your account information, including last statement balance, current balance and minimum payment due, will be displayed on this device and any other device where you receive text messages. Do you want to continue and allow this information to be displayed?",
            "It looks like:\nYour Minimum Due is $0.00\nYour Last Statement Balance was $13492.46\nYour Current Balance is $2000.00\n\nWhat type of payment would you like to make?\nText 1 for Minimum Due\nText 2 for Last Statement Balance\nText 3 for Current Balance\nText 4 for Other Amount",
            "Please enter the amount of payment greater than $1 in $xx.xx format",
            "When do you want to make a payment? \n            Text 1 - Due Date 08/02/2020\n            Text 2 - Today 07/14/2020\n         Text 3 - A different date",
            "Please enter a valid date in MM/DD/YYYY format",
            "You have not selected a valid option, please enter a valid date in MM/DD/YYYY forma",
            "We have your account information from previous payments you have made\nWhich account do you want to use for your payment?  Please text #\n1- Account ending in 3232\n2- Account ending in 6789",
            "Almost done: let's confirm the payment information and get your authorization to make the payment. To confirm, today is 07/14/2020 and you are agreeing to a one-time payment of $2.00 towards your The Home Depot® Consumer Credit Card ending in 8098, from your bank account ending in 3232 posting on 08/01/2020\n\nYou may cancel or change this payment online or by calling us at the number on the back of your card before 5:00 pm Eastern time on the day of your scheduled payment.\n\nText Y if the payment information above is correct\nText N to make changes",
            "Do I have your authorization to schedule this payment now? \n  Please text the last 4 digits of the primary account holder's SSN to authorize this payment.\n Text N if you do not authorize this payment."

        ]
    },
    "Enter_date_2x": {
        "input": [
            "discard all",
            "clearsession",
            "Hi",
            "8098",
            "pay",
            "8098",
            "yes",
            "4",
            "2",
            "3",
            "7/7/7",
            "7/7/7"
        ],
        "output": [
            "@@@@",
            "@@@@",
            "@@@@",
            "@@@@",
            "Which account do you want to pay?  Please text\n#1-Account ending in 9994\n#2-Account ending in 7935\n#3-Account ending in 8098\n#4-Account ending in 0222\n#5-Account ending in 6591\n#6-Account ending in 8310\n#7-Account ending in 0198\n#8-Account ending in 0214",
            "Before we begin, you should know that your account information, including last statement balance, current balance and minimum payment due, will be displayed on this device and any other device where you receive text messages. Do you want to continue and allow this information to be displayed?",
            "It looks like:\nYour Minimum Due is $0.00\nYour Last Statement Balance was $13492.46\nYour Current Balance is $2000.00\n\nWhat type of payment would you like to make?\nText 1 for Minimum Due\nText 2 for Last Statement Balance\nText 3 for Current Balance\nText 4 for Other Amount",
            "Please enter the amount of payment greater than $1 in $xx.xx format",
            "When do you want to make a payment? \n            Text 1 - Due Date 08/02/2020\n            Text 2 - Today 07/14/2020\n         Text 3 - A different date",
            "Please enter a valid date in MM/DD/YYYY format",
            "You have not selected a valid option, please enter a valid date in MM/DD/YYYY format",
            "It appears that we will not be able to help you set up a payment via text. Please follow the link below to make a payment or contact the customer service number on the back of your credit card to make the payment. pay.homedepotconsumer.accountonline.com\n\nIs there anything else I can help you with today?"

        ]
    },
    "Multiple_Payment_Source_1x_to_SSN": {
        "input": [
            "discard all",
            "clearsession",
            "Hi",
            "8098",
            "pay",
            "8098",
            "yes",
            "4",
            "2",
            "3",
            "08/01/2020",
            "abc",
            "1",
            "yes"
        ],
        "output": [
            "@@@@",
            "@@@@",
            "@@@@",
            "@@@@",
            "Which account do you want to pay?  Please text\n#1-Account ending in 9994\n#2-Account ending in 7935\n#3-Account ending in 8098\n#4-Account ending in 0222\n#5-Account ending in 6591\n#6-Account ending in 8310\n#7-Account ending in 0198\n#8-Account ending in 0214",
            "Before we begin, you should know that your account information, including last statement balance, current balance and minimum payment due, will be displayed on this device and any other device where you receive text messages. Do you want to continue and allow this information to be displayed?",
            "It looks like:\nYour Minimum Due is $0.00\nYour Last Statement Balance was $13492.46\nYour Current Balance is $2000.00\n\nWhat type of payment would you like to make?\nText 1 for Minimum Due\nText 2 for Last Statement Balance\nText 3 for Current Balance\nText 4 for Other Amount",
            "Please enter the amount of payment greater than $1 in $xx.xx format",
            "When do you want to make a payment? \n            Text 1 - Due Date 08/02/2020\n            Text 2 - Today 07/14/2020\n         Text 3 - A different date",
            "Please enter a valid date in MM/DD/YYYY format",
            "We have your account information from previous payments you have made\nWhich account do you want to use for your payment?  Please text #\n1- Account ending in 3232\n2- Account ending in 6789",
            "You have not selected a valid option, please enter the number of the account you want to use for your payment\nEnter 1 for account ending in 3232\nEnter 2 for account ending in 6789",
            "Almost done: let's confirm the payment information and get your authorization to make the payment. To confirm, today is 07/14/2020 and you are agreeing to a one-time payment of $2.00 towards your The Home Depot® Consumer Credit Card ending in 8098, from your bank account ending in 3232 posting on 08/01/2020\n\nYou may cancel or change this payment online or by calling us at the number on the back of your card before 5:00 pm Eastern time on the day of your scheduled payment.\n\nText Y if the payment information above is correct\nText N to make changes",
            "Do I have your authorization to schedule this payment now? \n  Please text the last 4 digits of the primary account holder's SSN to authorize this payment.\n Text N if you do not authorize this payment."

        ]
    },
    "Multiple_Payment_Source_2x": {
        "input": [
            "discard all",
            "clearsession",
            "Hi",
            "8098",
            "pay",
            "8098",
            "yes",
            "4",
            "2",
            "3",
            "08/01/2020",
            "abc",
            "abc"
        ],
        "output": [
            "@@@@",
            "@@@@",
            "@@@@",
            "@@@@",
            "Which account do you want to pay?  Please text\n#1-Account ending in 9994\n#2-Account ending in 7935\n#3-Account ending in 8098\n#4-Account ending in 0222\n#5-Account ending in 6591\n#6-Account ending in 8310\n#7-Account ending in 0198\n#8-Account ending in 0214",
            "Before we begin, you should know that your account information, including last statement balance, current balance and minimum payment due, will be displayed on this device and any other device where you receive text messages. Do you want to continue and allow this information to be displayed?",
            "It looks like:\nYour Minimum Due is $0.00\nYour Last Statement Balance was $13492.46\nYour Current Balance is $2000.00\n\nWhat type of payment would you like to make?\nText 1 for Minimum Due\nText 2 for Last Statement Balance\nText 3 for Current Balance\nText 4 for Other Amount",
            "Please enter the amount of payment greater than $1 in $xx.xx format",
            "When do you want to make a payment? \n            Text 1 - Due Date 08/02/2020\n            Text 2 - Today 07/14/2020\n         Text 3 - A different date",
            "Please enter a valid date in MM/DD/YYYY format",
            "We have your account information from previous payments you have made\nWhich account do you want to use for your payment?  Please text #\n1- Account ending in 3232\n2- Account ending in 6789",
            "You have not selected a valid option, please enter the number of the account you want to use for your payment\nEnter 1 for account ending in 3232\nEnter 2 for account ending in 6789",
            "It appears that we will not be able to help you set up a payment via text. Please follow the link below to make a payment or contact the customer service number on the back of your credit card to make the payment. pay.homedepotconsumer.accountonline.com\n\nIs there anything else I can help you with today?"

        ]
    },

    "Payment_authorization_confirmation_1x_to_SSN": {
        "input": [
            "discard all",
            "clearsession",
            "Hi",
            "8098",
            "pay",
            "8098",
            "yes",
            "4",
            "2",
            "3",
            "08/01/2020",
            "1",
            "abcd",
            "yes"
        ],
        "output": [
            "@@@@",
            "@@@@",
            "@@@@",
            "@@@@",
            "Which account do you want to pay?  Please text\n#1-Account ending in 9994\n#2-Account ending in 7935\n#3-Account ending in 8098\n#4-Account ending in 0222\n#5-Account ending in 6591\n#6-Account ending in 8310\n#7-Account ending in 0198\n#8-Account ending in 0214",
            "Before we begin, you should know that your account information, including last statement balance, current balance and minimum payment due, will be displayed on this device and any other device where you receive text messages. Do you want to continue and allow this information to be displayed?",
            "It looks like:\nYour Minimum Due is $0.00\nYour Last Statement Balance was $13492.46\nYour Current Balance is $2000.00\n\nWhat type of payment would you like to make?\nText 1 for Minimum Due\nText 2 for Last Statement Balance\nText 3 for Current Balance\nText 4 for Other Amount",
            "Please enter the amount of payment greater than $1 in $xx.xx format",
            "When do you want to make a payment? \n            Text 1 - Due Date 08/02/2020\n            Text 2 - Today 07/14/2020\n         Text 3 - A different date",
            "Please enter a valid date in MM/DD/YYYY format",
            "We have your account information from previous payments you have made\nWhich account do you want to use for your payment?  Please text #\n1- Account ending in 3232\n2- Account ending in 6789",
            "Almost done: let's confirm the payment information and get your authorization to make the payment. To confirm, today is 07/14/2020 and you are agreeing to a one-time payment of $2.00 towards your The Home Depot® Consumer Credit Card ending in 8098, from your bank account ending in 3232 posting on 08/01/2020\n\nYou may cancel or change this payment online or by calling us at the number on the back of your card before 5:00 pm Eastern time on the day of your scheduled payment.\n\nText Y if the payment information above is correct\nText N to make changes",
            "You have not selected a valid option, please confirm the payment information and provide your authorization to make the payment. To confirm, today is 07/14/2020 and you are agreeing to a one-time payment of $2.00 towards your The Home Depot® Consumer Credit Card ending in 8098, from your bank account ending in 3232 posting on 08/01/2020\n\nYou may cancel or change this payment online or by calling us at the number on the back of your card before 5:00 pm Eastern time on the day of your scheduled payment.\n\nText Y if the payment information above is correct\nText N to make changes",
            "Do I have your authorization to schedule this payment now? \n  Please text the last 4 digits of the primary account holder's SSN to authorize this payment.\n Text N if you do not authorize this payment."

        ]
    },
    "Payment_authorization_confirmation_2x": {
        "input": [
            "discard all",
            "clearsession",
            "Hi",
            "8098",
            "pay",
            "8098",
            "yes",
            "4",
            "2",
            "3",
            "08/01/2020",
            "1",
            "abcd",
            "abcd"
        ],
        "output": [
            "@@@@",
            "@@@@",
            "@@@@",
            "@@@@",
            "Which account do you want to pay?  Please text\n#1-Account ending in 9994\n#2-Account ending in 7935\n#3-Account ending in 8098\n#4-Account ending in 0222\n#5-Account ending in 6591\n#6-Account ending in 8310\n#7-Account ending in 0198\n#8-Account ending in 0214",
            "Before we begin, you should know that your account information, including last statement balance, current balance and minimum payment due, will be displayed on this device and any other device where you receive text messages. Do you want to continue and allow this information to be displayed?",
            "It looks like:\nYour Minimum Due is $0.00\nYour Last Statement Balance was $13492.46\nYour Current Balance is $2000.00\n\nWhat type of payment would you like to make?\nText 1 for Minimum Due\nText 2 for Last Statement Balance\nText 3 for Current Balance\nText 4 for Other Amount",
            "Please enter the amount of payment greater than $1 in $xx.xx format",
            "When do you want to make a payment? \n            Text 1 - Due Date 08/02/2020\n            Text 2 - Today 07/14/2020\n         Text 3 - A different date",
            "Please enter a valid date in MM/DD/YYYY format",
            "We have your account information from previous payments you have made\nWhich account do you want to use for your payment?  Please text #\n1- Account ending in 3232\n2- Account ending in 6789",
            "Almost done: let's confirm the payment information and get your authorization to make the payment. To confirm, today is 07/14/2020 and you are agreeing to a one-time payment of $2.00 towards your The Home Depot® Consumer Credit Card ending in 8098, from your bank account ending in 3232 posting on 08/01/2020\n\nYou may cancel or change this payment online or by calling us at the number on the back of your card before 5:00 pm Eastern time on the day of your scheduled payment.\n\nText Y if the payment information above is correct\nText N to make changes",
            "You have not selected a valid option, please confirm the payment information and provide your authorization to make the payment. To confirm, today is 07/14/2020 and you are agreeing to a one-time payment of $2.00 towards your The Home Depot® Consumer Credit Card ending in 8098, from your bank account ending in 3232 posting on 08/01/2020n\nYou may cancel or change this payment online or by calling us at the number on the back of your card before 5:00 pm Eastern time on the day of your scheduled payment.\n\nText Y if the payment information above is correct\nText N to make changes",
            "It appears that we will not be able to help you set up a payment via text. Please follow the link below to make a payment or contact the customer service number on the back of your credit card to make the payment. pay.homedepotconsumer.accountonline.com\n\nIs there anything else I can help you with today?"

        ]
    },

    "Change_information_1x_to_SSN": {
        "input": [
            "discard all",
            "clearsession",
            "Hi",
            "8098",
            "pay",
            "8098",
            "yes",
            "4",
            "2",
            "3",
            "08/01/2020",
            "1",
            "no",
            "44",
            "2",
            "4",
            "10",
            "yes"
        ],
        "output": [
            "@@@@",
            "@@@@",
            "@@@@",
            "@@@@",
            "Which account do you want to pay?  Please text\n#1-Account ending in 9994\n#2-Account ending in 7935\n#3-Account ending in 8098\n#4-Account ending in 0222\n#5-Account ending in 6591\n#6-Account ending in 8310\n#7-Account ending in 0198\n#8-Account ending in 0214",
            "Before we begin, you should know that your account information, including last statement balance, current balance and minimum payment due, will be displayed on this device and any other device where you receive text messages. Do you want to continue and allow this information to be displayed?",
            "It looks like:\nYour Minimum Due is $0.00\nYour Last Statement Balance was $13492.46\nYour Current Balance is $2000.00\n\nWhat type of payment would you like to make?\nText 1 for Minimum Due\nText 2 for Last Statement Balance\nText 3 for Current Balance\nText 4 for Other Amount",
            "Please enter the amount of payment greater than $1 in $xx.xx format",
            "When do you want to make a payment? \n            Text 1 - Due Date 08/02/2020\n            Text 2 - Today 07/15/2020\n         Text 3 - A different date",
            "Please enter a valid date in MM/DD/YYYY format",
            "We have your account information from previous payments you have made\nWhich account do you want to use for your payment?  Please text #\n1- Account ending in 3232\n2- Account ending in 6789",
            "Almost done: let's confirm the payment information and get your authorization to make the payment. To confirm, today is 07/15/2020 and you are agreeing to a one-time payment of $2.00 towards your The Home Depot® Consumer Credit Card ending in 8098, from your bank account ending in 3232 posting on 08/01/2020\n\nYou may cancel or change this payment online or by calling us at the number on the back of your card before 5:00 pm Eastern time on the day of your scheduled payment.\n\nText Y if the payment information above is correct\nText N to make changes",
            "What information would you like to change?\n        Text 1 for date\n        Text 2 for amount\n        Text 3 for payment source\n        Text 4 to stop making a payment or go to a different topic",
            "You have not selected a valid option, please enter what information would you like to change?\n    Text 1 to update the date\n    Text 2 to update the amount\n    Text 3 to update the payment source\n    Text 4 to stop making a payment or go to a different topic",
            "It looks like:\nYour Minimum Due is $0.00\nYour Last Statement Balance was $13492.46\nYour Current Balance is $2000.00\n\nWhat type of payment would you like to make?\nText 1 for Minimum Due\nText 2 for Last Statement Balance\nText 3 for Current Balance\nText 4 for Other Amount",
            "Please enter the amount of payment greater than $1 in $xx.xx format",
            "Almost done: let's confirm the payment information and get your authorization to make the payment. To confirm, today is 07/15/2020 and you are agreeing to a one-time payment of $10.00 towards your The Home Depot® Consumer Credit Card ending in 8098, from your bank account ending in 3232 posting on 08/01/2020\n\nYou may cancel or change this payment online or by calling us at the number on the back of your card before 5:00 pm Eastern time on the day of your scheduled payment.\n\nText Y if the payment information above is correct\nText N to make changes",
            "Do I have your authorization to schedule this payment now? \n  Please text the last 4 digits of the primary account holder's SSN to authorize this payment.\n Text N if you do not authorize this payment."
        ]
    },

    "Change_information_2x": {
        "input": [
            "discard all",
            "clearsession",
            "Hi",
            "8098",
            "pay",
            "8098",
            "yes",
            "4",
            "2",
            "3",
            "08/01/2020",
            "1",
            "no",
            "44",
            "44"
        ],
        "output": [
            "@@@@",
            "@@@@",
            "@@@@",
            "@@@@",
            "Which account do you want to pay?  Please text\n#1-Account ending in 9994\n#2-Account ending in 7935\n#3-Account ending in 8098\n#4-Account ending in 0222\n#5-Account ending in 6591\n#6-Account ending in 8310\n#7-Account ending in 0198\n#8-Account ending in 0214",
            "Before we begin, you should know that your account information, including last statement balance, current balance and minimum payment due, will be displayed on this device and any other device where you receive text messages. Do you want to continue and allow this information to be displayed?",
            "It looks like:\nYour Minimum Due is $0.00\nYour Last Statement Balance was $13492.46\nYour Current Balance is $2000.00\n\nWhat type of payment would you like to make?\nText 1 for Minimum Due\nText 2 for Last Statement Balance\nText 3 for Current Balance\nText 4 for Other Amount",
            "Please enter the amount of payment greater than $1 in $xx.xx format",
            "When do you want to make a payment? \n            Text 1 - Due Date 08/02/2020\n            Text 2 - Today 07/15/2020\n         Text 3 - A different date",
            "Please enter a valid date in MM/DD/YYYY format",
            "We have your account information from previous payments you have made\nWhich account do you want to use for your payment?  Please text #\n1- Account ending in 3232\n2- Account ending in 6789",
            "Almost done: let's confirm the payment information and get your authorization to make the payment. To confirm, today is 07/15/2020 and you are agreeing to a one-time payment of $2.00 towards your The Home Depot® Consumer Credit Card ending in 8098, from your bank account ending in 3232 posting on 08/01/2020n\nYou may cancel or change this payment online or by calling us at the number on the back of your card before 5:00 pm Eastern time on the day of your scheduled payment.\n\nText Y if the payment information above is correct\nText N to make changes",
            "What information would you like to change?\n        Text 1 for date\n        Text 2 for amount\n        Text 3 for payment source\n        Text 4 to stop making a payment or go to a different topic",
            "You have not selected a valid option, please enter what information would you like to change?\n    Text 1 to update the date\n    Text 2 to update the amount\n    Text 3 to update the payment source\n    Text 4 to stop making a payment or go to a different topic",
            "It appears that we will not be able to help you set up a payment via text. Please follow the link below to make a payment or contact the customer service number on the back of your credit card to make the payment. pay.homedepotconsumer.accountonline.com\n\nIs there anything else I can help you with today?"
        ]
    },


    "Change_information_Date_to_SSN": {
        "input": [
            "discard all",
            "clearsession",
            "Hi",
            "8098",
            "pay",
            "8098",
            "yes",
            "4",
            "2",
            "3",
            "07/30/2020",
            "1",
            "no",
            "1",
            "3",
            "08/01/2020",
            "yes"
        ],
        "output": [
            "@@@@",
            "@@@@",
            "@@@@",
            "@@@@",
            "Which account do you want to pay?  Please text\n#1-Account ending in 9994\n#2-Account ending in 7935\n#3-Account ending in 8098\n#4-Account ending in 0222\n#5-Account ending in 6591\n#6-Account ending in 8310\n#7-Account ending in 0198\n#8-Account ending in 0214",
            "Before we begin, you should know that your account information, including last statement balance, current balance and minimum payment due, will be displayed on this device and any other device where you receive text messages. Do you want to continue and allow this information to be displayed?",
            "It looks like:\nYour Minimum Due is $0.00\nYour Last Statement Balance was $13492.46\nYour Current Balance is $2000.00\n\nWhat type of payment would you like to make?\nText 1 for Minimum Due\nText 2 for Last Statement Balance\nText 3 for Current Balance\nText 4 for Other Amount",
            "Please enter the amount of payment greater than $1 in $xx.xx format",
            "When do you want to make a payment? \n            Text 1 - Due Date 08/02/2020\n            Text 2 - Today 07/15/2020\n         Text 3 - A different date",
            "Please enter a valid date in MM/DD/YYYY format",
            "We have your account information from previous payments you have made\nWhich account do you want to use for your payment?  Please text #\n1- Account ending in 3232\n2- Account ending in 6789",
            "Almost done: let's confirm the payment information and get your authorization to make the payment. To confirm, today is 07/15/2020 and you are agreeing to a one-time payment of $2.00 towards your The Home Depot® Consumer Credit Card ending in 8098, from your bank account ending in 3232 posting on 07/30/2020\n\nYou may cancel or change this payment online or by calling us at the number on the back of your card before 5:00 pm Eastern time on the day of your scheduled payment.\n\nText Y if the payment information above is correct\nText N to make changes",
            "What information would you like to change?\n        Text 1 for date\n        Text 2 for amount\n        Text 3 for payment source\n        Text 4 to stop making a payment or go to a different topic",
            "When do you want to make a payment? \n            Text 1 - Due Date 08/02/2020\n            Text 2 - Today 07/15/2020\n         Text 3 - A different date",
            "Please enter a valid date in MM/DD/YYYY format",
            "Almost done: let's confirm the payment information and get your authorization to make the payment. To confirm, today is 07/15/2020 and you are agreeing to a one-time payment of $2.00 towards your The Home Depot® Consumer Credit Card ending in 8098, from your bank account ending in 3232 posting on 08/01/2020\n\nYou may cancel or change this payment online or by calling us at the number on the back of your card before 5:00 pm Eastern time on the day of your scheduled payment.\n\nText Y if the payment information above is correct\nText N to make changes",
            "Do I have your authorization to schedule this payment now? \n  Please text the last 4 digits of the primary account holder's SSN to authorize this payment.\n Text N if you do not authorize this payment."
        ]
    },


    "Change_information_Date_2x": {
        "input": [
            "discard all",
            "clearsession",
            "Hi",
            "8098",
            "pay",
            "8098",
            "yes",
            "4",
            "2",
            "3",
            "08/01/2020",
            "1",
            "no",
            "1",
            "3",
            "7/7/7",
            "7/7/7"
        ],
        "output": [
            "@@@@",
            "@@@@",
            "@@@@",
            "@@@@",
            "Which account do you want to pay?  Please text\n#1-Account ending in 9994\n#2-Account ending in 7935\n#3-Account ending in 8098\n#4-Account ending in 0222\n#5-Account ending in 6591\n#6-Account ending in 8310\n#7-Account ending in 0198\n#8-Account ending in 0214",
            "Before we begin, you should know that your account information, including last statement balance, current balance and minimum payment due, will be displayed on this device and any other device where you receive text messages. Do you want to continue and allow this information to be displayed?",
            "It looks like:\nYour Minimum Due is $0.00\nYour Last Statement Balance was $13492.46\nYour Current Balance is $2000.00\n\nWhat type of payment would you like to make?\nText 1 for Minimum Due\nText 2 for Last Statement Balance\nText 3 for Current Balance\nText 4 for Other Amount",
            "Please enter the amount of payment greater than $1 in $xx.xx format",
            "When do you want to make a payment? \n            Text 1 - Due Date 08/02/2020\n            Text 2 - Today 07/15/2020\n         Text 3 - A different date",
            "Please enter a valid date in MM/DD/YYYY format",
            "We have your account information from previous payments you have made\nWhich account do you want to use for your payment?  Please text #\n1- Account ending in 3232\n2- Account ending in 6789",
            "Almost done: let's confirm the payment information and get your authorization to make the payment. To confirm, today is 07/15/2020 and you are agreeing to a one-time payment of $2.00 towards your The Home Depot® Consumer Credit Card ending in 8098, from your bank account ending in 3232 posting on 08/01/2020\n\nYou may cancel or change this payment online or by calling us at the number on the back of your card before 5:00 pm Eastern time on the day of your scheduled payment.\n\nText Y if the payment information above is correct\nText N to make changes",
            "What information would you like to change?\n        Text 1 for date\n        Text 2 for amount\n        Text 3 for payment source\n        Text 4 to stop making a payment or go to a different topic",
            "When do you want to make a payment? \n            Text 1 - Due Date 08/02/2020\n            Text 2 - Today 07/15/2020\n         Text 3 - A different date",
            "Please enter a valid date in MM/DD/YYYY format",
            "You have not selected a valid option, please enter a valid date in MM/DD/YYYY format",
            "It appears that we will not be able to help you set up a payment via text. Please follow the link below to make a payment or contact the customer service number on the back of your credit card to make the payment. pay.homedepotconsumer.accountonline.com\n\nIs there anything else I can help you with today?"
        ]
    },

    "Change_information_PaymentSource(Multiple payment sources)_to_SSN": {
        "input": [
            "discard all",
            "clearsession",
            "Hi",
            "8098",
            "pay",
            "8098",
            "yes",
            "4",
            "2",
            "3",
            "08/01/2020",
            "1",
            "no",
            "3",
            "2",
            "yes"
        ],
        "output": [
            "@@@@",
            "@@@@",
            "@@@@",
            "@@@@",
            "Which account do you want to pay?  Please text\n#1-Account ending in 9994\n#2-Account ending in 7935\n#3-Account ending in 8098\n#4-Account ending in 0222\n#5-Account ending in 6591\n#6-Account ending in 8310\n#7-Account ending in 0198\n#8-Account ending in 0214",
            "Before we begin, you should know that your account information, including last statement balance, current balance and minimum payment due, will be displayed on this device and any other device where you receive text messages. Do you want to continue and allow this information to be displayed?",
            "It looks like:\nYour Minimum Due is $0.00\nYour Last Statement Balance was $13492.46\nYour Current Balance is $2000.00\n\nWhat type of payment would you like to make?\nText 1 for Minimum Due\nText 2 for Last Statement Balance\nText 3 for Current Balance\nText 4 for Other Amount",
            "Please enter the amount of payment greater than $1 in $xx.xx format",
            "When do you want to make a payment? \n            Text 1 - Due Date 08/02/2020\n            Text 2 - Today 07/15/2020\n         Text 3 - A different date",
            "Please enter a valid date in MM/DD/YYYY format",
            "We have your account information from previous payments you have made\nWhich account do you want to use for your payment?  Please text #\n1- Account ending in 3232\n2- Account ending in 6789",
            "Almost done: let's confirm the payment information and get your authorization to make the payment. To confirm, today is 07/15/2020 and you are agreeing to a one-time payment of $2.00 towards your The Home Depot® Consumer Credit Card ending in 8098, from your bank account ending in 3232 posting on 08/01/2020\n\nYou may cancel or change this payment online or by calling us at the number on the back of your card before 5:00 pm Eastern time on the day of your scheduled payment.\n\nText Y if the payment information above is correct\nText N to make changes",
            "What information would you like to change?\n        Text 1 for date\n        Text 2 for amount\n        Text 3 for payment source\n        Text 4 to stop making a payment or go to a different topic",
            "We have your account information from previous payments you have made\nWhich account do you want to use for your payment?  Please text #\n1- Account ending in 3232\n2- Account ending in 6789",
            "Almost done: let's confirm the payment information and get your authorization to make the payment. To confirm, today is 07/15/2020 and you are agreeing to a one-time payment of $2.00 towards your The Home Depot® Consumer Credit Card ending in 8098, from your bank account ending in 6789 posting on 08/01/2020\n\nYou may cancel or change this payment online or by calling us at the number on the back of your card before 5:00 pm Eastern time on the day of your scheduled payment.\n\nText Y if the payment information above is correct\nText N to make changes",
            "Do I have your authorization to schedule this payment now? \n  Please text the last 4 digits of the primary account holder's SSN to authorize this payment.\n Text N if you do not authorize this payment."
        ]
    },

    "Change_information_PaymentSource_2x": {
        "input": [
            "discard all",
            "clearsession",
            "Hi",
            "8098",
            "pay",
            "8098",
            "yes",
            "4",
            "2",
            "3",
            "08/01/2020",
            "1",
            "no",
            "3",
            "abc",
            "abc"
        ],
        "output": [
            "@@@@",
            "@@@@",
            "@@@@",
            "@@@@",
            "Which account do you want to pay?  Please text\n#1-Account ending in 9994\n#2-Account ending in 7935\n#3-Account ending in 8098\n#4-Account ending in 0222\n#5-Account ending in 6591\n#6-Account ending in 8310\n#7-Account ending in 0198\n#8-Account ending in 0214",
            "Before we begin, you should know that your account information, including last statement balance, current balance and minimum payment due, will be displayed on this device and any other device where you receive text messages. Do you want to continue and allow this information to be displayed?",
            "It looks like:\nYour Minimum Due is $0.00\nYour Last Statement Balance was $13492.46\nYour Current Balance is $2000.00\n\nWhat type of payment would you like to make?\nText 1 for Minimum Due\nText 2 for Last Statement Balance\nText 3 for Current Balance\nText 4 for Other Amount",
            "Please enter the amount of payment greater than $1 in $xx.xx format",
            "When do you want to make a payment? \n            Text 1 - Due Date 08/02/2020\n            Text 2 - Today 07/15/2020\n         Text 3 - A different date",
            "Please enter a valid date in MM/DD/YYYY format",
            "We have your account information from previous payments you have made\nWhich account do you want to use for your payment?  Please text #\n1- Account ending in 3232\n2- Account ending in 6789",
            "Almost done: let's confirm the payment information and get your authorization to make the payment. To confirm, today is 07/15/2020 and you are agreeing to a one-time payment of $2.00 towards your The Home Depot® Consumer Credit Card ending in 8098, from your bank account ending in 3232 posting on 08/01/2020\n\nYou may cancel or change this payment online or by calling us at the number on the back of your card before 5:00 pm Eastern time on the day of your scheduled payment.\n\nText Y if the payment information above is correct\nText N to make changes",
            "What information would you like to change?\n        Text 1 for date\n        Text 2 for amount\n        Text 3 for payment source\n        Text 4 to stop making a payment or go to a different topic",
            "We have your account information from previous payments you have made\nWhich account do you want to use for your payment?  Please text #\n1- Account ending in 3232\n2- Account ending in 6789",
            "You have not selected a valid option, please enter the number of the account you want to use for your payment\nEnter 1 for account ending in 3232\nEnter 2 for account ending in 6789",
            "It appears that we will not be able to help you set up a payment via text. Please follow the link below to make a payment or contact the customer service number on the back of your credit card to make the payment. pay.homedepotconsumer.accountonline.com\n\nIs there anything else I can help you with today?"

        ]
    },


    "Change_information_Amount_SSN": {
        "input": [
            "discard all",
            "clearsession",
            "Hi",
            "8098",
            "pay",
            "8098",
            "yes",
            "4",
            "2",
            "3",
            "08/01/2020",
            "1",
            "no",
            "2",
            "4",
            "5",
            "yes"

        ],
        "output": [
            "@@@@",
            "@@@@",
            "@@@@",
            "@@@@",
            "Which account do you want to pay?  Please text\n#1-Account ending in 9994\n#2-Account ending in 7935\n#3-Account ending in 8098\n#4-Account ending in 0222\n#5-Account ending in 6591\n#6-Account ending in 8310\n#7-Account ending in 0198\n#8-Account ending in 0214",
            "Before we begin, you should know that your account information, including last statement balance, current balance and minimum payment due, will be displayed on this device and any other device where you receive text messages. Do you want to continue and allow this information to be displayed?",
            "It looks like:\nYour Minimum Due is $0.00\nYour Last Statement Balance was $13492.46\nYour Current Balance is $2000.00\n\nWhat type of payment would you like to make?\nText 1 for Minimum Due\nText 2 for Last Statement Balance\nText 3 for Current Balance\nText 4 for Other Amount",
            "Please enter the amount of payment greater than $1 in $xx.xx format",
            "When do you want to make a payment? \n            Text 1 - Due Date 08/02/2020\n            Text 2 - Today 07/15/2020\n         Text 3 - A different date",
            "Please enter a valid date in MM/DD/YYYY format",
            "We have your account information from previous payments you have made\nWhich account do you want to use for your payment?  Please text #\n1- Account ending in 3232\n2- Account ending in 6789",
            "Almost done: let's confirm the payment information and get your authorization to make the payment. To confirm, today is 07/15/2020 and you are agreeing to a one-time payment of $2.00 towards your The Home Depot® Consumer Credit Card ending in 8098, from your bank account ending in 3232 posting on 08/01/2020\n\nYou may cancel or change this payment online or by calling us at the number on the back of your card before 5:00 pm Eastern time on the day of your scheduled payment.\n\nText Y if the payment information above is correct\nText N to make changes",
            "What information would you like to change?\n        Text 1 for date\n        Text 2 for amount\n        Text 3 for payment source\n        Text 4 to stop making a payment or go to a different topic",
            "It looks like:\nYour Minimum Due is $0.00\nYour Last Statement Balance was $13492.46\nYour Current Balance is $2000.00\n\nWhat type of payment would you like to make?\nText 1 for Minimum Due\nText 2 for Last Statement Balance\nText 3 for Current Balance\nText 4 for Other Amount",
            "Please enter the amount of payment greater than $1 in $xx.xx format",
            "Almost done: let's confirm the payment information and get your authorization to make the payment. To confirm, today is 07/15/2020 and you are agreeing to a one-time payment of $5.00 towards your The Home Depot® Consumer Credit Card ending in 8098, from your bank account ending in 3232 posting on 08/01/2020\n\nYou may cancel or change this payment online or by calling us at the number on the back of your card before 5:00 pm Eastern time on the day of your scheduled payment.\n\nText Y if the payment information above is correct\nText N to make changes",
            "Do I have your authorization to schedule this payment now? \n  Please text the last 4 digits of the primary account holder's SSN to authorize this payment.\n Text N if you do not authorize this payment."

        ]
    },


    "Change_information_Amount_S2x": {
        "input": [
            "discard all",
            "clearsession",
            "Hi",
            "8098",
            "pay",
            "8098",
            "yes",
            "4",
            "2",
            "3",
            "08/01/2020",
            "1",
            "no",
            "2",
            "4",
            "1",
            "abc"

        ],
        "output": [
            "@@@@",
            "@@@@",
            "@@@@",
            "@@@@",
            "Which account do you want to pay?  Please text\n#1-Account ending in 9994\n#2-Account ending in 7935\n#3-Account ending in 8098\n#4-Account ending in 0222\n#5-Account ending in 6591\n#6-Account ending in 8310\n#7-Account ending in 0198\n#8-Account ending in 0214",
            "Before we begin, you should know that your account information, including last statement balance, current balance and minimum payment due, will be displayed on this device and any other device where you receive text messages. Do you want to continue and allow this information to be displayed?",
            "It looks like:\nYour Minimum Due is $0.00\nYour Last Statement Balance was $13492.46\nYour Current Balance is $2000.00\n\nWhat type of payment would you like to make?\nText 1 for Minimum Due\nText 2 for Last Statement Balance\nText 3 for Current Balance\nText 4 for Other Amount",
            "Please enter the amount of payment greater than $1 in $xx.xx format",
            "When do you want to make a payment? \n            Text 1 - Due Date 08/02/2020\n            Text 2 - Today 07/15/2020\n         Text 3 - A different date",
            "Please enter a valid date in MM/DD/YYYY format",
            "We have your account information from previous payments you have made\nWhich account do you want to use for your payment?  Please text #\n1- Account ending in 3232\n2- Account ending in 6789",
            "Almost done: let's confirm the payment information and get your authorization to make the payment. To confirm, today is 07/15/2020 and you are agreeing to a one-time payment of $2.00 towards your The Home Depot® Consumer Credit Card ending in 8098, from your bank account ending in 3232 posting on 08/01/2020\n\nYou may cancel or change this payment online or by calling us at the number on the back of your card before 5:00 pm Eastern time on the day of your scheduled payment.\n\nText Y if the payment information above is correct\nText N to make changes",
            "What information would you like to change?\n        Text 1 for date\n        Text 2 for amount\n        Text 3 for payment source\n        Text 4 to stop making a payment or go to a different topic",
            "It looks like:\nYour Minimum Due is $0.00\nYour Last Statement Balance was $13492.46\nYour Current Balance is $2000.00\n\nWhat type of payment would you like to make?\nText 1 for Minimum Due\nText 2 for Last Statement Balance\nText 3 for Current Balance\nText 4 for Other Amount",
            "Please enter the amount of payment greater than $1 in $xx.xx format",
            "You have not entered a valid amount, please enter a valid amount in $xx.xx format greater than $1",
            "It appears that we will not be able to help you set up a payment via text. Please follow the link below to make a payment or contact the customer service number on the back of your credit card to make the payment. pay.homedepotconsumer.accountonline.com\n\nIs there anything else I can help you with today?"
        ]
    },
    "Change_information_StopPayment": {
        "input": [
            "discard all",
            "clearsession",
            "Hi",
            "8098",
            "pay",
            "8098",
            "yes",
            "4",
            "2",
            "3",
            "08/01/2020",
            "1",
            "no",
            "4"
        ],

        "output": [
            "@@@@",
            "@@@@",
            "@@@@",
            "@@@@",
            "Which account do you want to pay?  Please text\n#1-Account ending in 9994\n#2-Account ending in 7935\n#3-Account ending in 8098\n#4-Account ending in 0222\n#5-Account ending in 6591\n#6-Account ending in 8310\n#7-Account ending in 0198\n#8-Account ending in 0214",
            "Before we begin, you should know that your account information, including last statement balance, current balance and minimum payment due, will be displayed on this device and any other device where you receive text messages. Do you want to continue and allow this information to be displayed?",
            "It looks like:\nYour Minimum Due is $0.00\nYour Last Statement Balance was $13492.46\nYour Current Balance is $2000.00\n\nWhat type of payment would you like to make?\nText 1 for Minimum Due\nText 2 for Last Statement Balance\nText 3 for Current Balance\nText 4 for Other Amount",
            "Please enter the amount of payment greater than $1 in $xx.xx format",
            "When do you want to make a payment? \n            Text 1 - Due Date 08/02/2020\n            Text 2 - Today 07/15/2020\n         Text 3 - A different date",
            "Please enter a valid date in MM/DD/YYYY format",
            "We have your account information from previous payments you have made\nWhich account do you want to use for your payment?  Please text #\n1- Account ending in 3232\n2- Account ending in 6789",
            "Almost done: let's confirm the payment information and get your authorization to make the payment. To confirm, today is 07/15/2020 and you are agreeing to a one-time payment of $2.00 towards your The Home Depot® Consumer Credit Card ending in 8098, from your bank account ending in 3232 posting on 08/01/2020\n\nYou may cancel or change this payment online or by calling us at the number on the back of your card before 5:00 pm Eastern time on the day of your scheduled payment.\n\nText Y if the payment information above is correct\nText N to make changes",
            "What information would you like to change?\n        Text 1 for date\n        Text 2 for amount\n        Text 3 for payment source\n        Text 4 to stop making a payment or go to a different topic",
            "Your payment has not been made.\n\nIs there anything else I can help you with today?"

        ]
    },

    "SSN_1x": {
        "input": [
            "discard all",
            "clearsession",
            "Hi",
            "8098",
            "pay",
            "8098",
            "yes",
            "4",
            "2",
            "3",
            "08/01/2020",
            "1",
            "yes",
            "asdfadf"
        ],

        "output": [
            "@@@@",
            "@@@@",
            "@@@@",
            "@@@@",
            "Which account do you want to pay?  Please text\n#1-Account ending in 9994\n#2-Account ending in 7935\n#3-Account ending in 8098\n#4-Account ending in 0222\n#5-Account ending in 6591\n#6-Account ending in 8310\n#7-Account ending in 0198\n#8-Account ending in 0214",
            "Before we begin, you should know that your account information, including last statement balance, current balance and minimum payment due, will be displayed on this device and any other device where you receive text messages. Do you want to continue and allow this information to be displayed?",
            "It looks like:\nYour Minimum Due is $0.00\nYour Last Statement Balance was $13492.46\nYour Current Balance is $2000.00\n\nWhat type of payment would you like to make?\nText 1 for Minimum Due\nText 2 for Last Statement Balance\nText 3 for Current Balance\nText 4 for Other Amount",
            "Please enter the amount of payment greater than $1 in $xx.xx format",
            "When do you want to make a payment? \n            Text 1 - Due Date 08/02/2020\n            Text 2 - Today 07/15/2020\n         Text 3 - A different date",
            "Please enter a valid date in MM/DD/YYYY format",
            "We have your account information from previous payments you have made\nWhich account do you want to use for your payment?  Please text #\n1- Account ending in 3232\n2- Account ending in 6789",
            "Almost done: let's confirm the payment information and get your authorization to make the payment. To confirm, today is 07/15/2020 and you are agreeing to a one-time payment of $2.00 towards your The Home Depot® Consumer Credit Card ending in 8098, from your bank account ending in 3232 posting on 08/01/2020\n\nYou may cancel or change this payment online or by calling us at the number on the back of your card before 5:00 pm Eastern time on the day of your scheduled payment.\n\nText Y if the payment information above is correct\nText N to make changes",
            "Do I have your authorization to schedule this payment now? \n  Please text the last 4 digits of the primary account holder's SSN to authorize this payment.\n Text N if you do not authorize this payment.",
            "It looks like the number you entered does not match the information we have on file.\n\nDo I have your authorization to schedule this payment now? \n  Please text the last 4 digits of the primary account holder's SSN to authorize this payment.\n Text N if you do not authorize this payment."

        ]
    },

    "SSN_2x": {
        "input": [
            "discard all",
            "clearsession",
            "Hi",
            "8098",
            "pay",
            "8098",
            "yes",
            "4",
            "2",
            "3",
            "08/01/2020",
            "1",
            "yes",
            "asdfadf",
            "asdf"
        ],

        "output": [
            "@@@@",
            "@@@@",
            "@@@@",
            "@@@@",
            "Which account do you want to pay?  Please text\n#1-Account ending in 9994\n#2-Account ending in 7935\n#3-Account ending in 8098\n#4-Account ending in 0222\n#5-Account ending in 6591\n#6-Account ending in 8310\n#7-Account ending in 0198\n#8-Account ending in 0214",
            "Before we begin, you should know that your account information, including last statement balance, current balance and minimum payment due, will be displayed on this device and any other device where you receive text messages. Do you want to continue and allow this information to be displayed?",
            "It looks like:\nYour Minimum Due is $0.00\nYour Last Statement Balance was $13492.46\nYour Current Balance is $2000.00\n\nWhat type of payment would you like to make?\nText 1 for Minimum Due\nText 2 for Last Statement Balance\nText 3 for Current Balance\nText 4 for Other Amount",
            "Please enter the amount of payment greater than $1 in $xx.xx format",
            "When do you want to make a payment? \n            Text 1 - Due Date 08/02/2020\n            Text 2 - Today 07/15/2020\n         Text 3 - A different date",
            "Please enter a valid date in MM/DD/YYYY format",
            "We have your account information from previous payments you have made\nWhich account do you want to use for your payment?  Please text #\n1- Account ending in 3232\n2- Account ending in 6789",
            "Almost done: let's confirm the payment information and get your authorization to make the payment. To confirm, today is 07/15/2020 and you are agreeing to a one-time payment of $2.00 towards your The Home Depot® Consumer Credit Card ending in 8098, from your bank account ending in 3232 posting on 08/01/2020\n\nYou may cancel or change this payment online or by calling us at the number on the back of your card before 5:00 pm Eastern time on the day of your scheduled payment.\n\nText Y if the payment information above is correct\nText N to make changes",
            "Do I have your authorization to schedule this payment now? \n  Please text the last 4 digits of the primary account holder's SSN to authorize this payment.\n Text N if you do not authorize this payment.",
            "It looks like the number you entered does not match the information we have on file.\n\nDo I have your authorization to schedule this payment now? \n  Please text the last 4 digits of the primary account holder's SSN to authorize this payment.\n Text N if you do not authorize this payment.",
            "It appears that we will not be able to help you set up a payment via text. Please follow the link below to make a payment or contact the customer service number on the back of your credit card to make the payment. pay.homedepotconsumer.accountonline.com\n\nIs there anything else I can help you with today?"

        ]
    },


    "SameDayPaymentReached_Date Options": {
        "input": [
            "discard all",
            "clearsession",
            "Hi",
            "8098",
            "pay",
            "8098",
            "yes",
            "4",
            "2",
            "2",
            "1",
            "yes"
        ],
        "output": [
            "@@@@",
            "@@@@",
            "@@@@",
            "@@@@",
            "Which account do you want to pay?  Please text\n#1-Account ending in 9994\n#2-Account ending in 7935\n#3-Account ending in 8098\n#4-Account ending in 0222\n#5-Account ending in 6591\n#6-Account ending in 8310\n#7-Account ending in 0198\n#8-Account ending in 0214",
            "Before we begin, you should know that your account information, including last statement balance, current balance and minimum payment due, will be displayed on this device and any other device where you receive text messages. Do you want to continue and allow this information to be displayed?",
            "It looks like:\nYour Minimum Due is $0.00\nYour Last Statement Balance was $13492.46\nYour Current Balance is $2000.00\n\nWhat type of payment would you like to make?\nText 1 for Minimum Due\nText 2 for Last Statement Balance\nText 3 for Current Balance\nText 4 for Other Amount",
            "Please enter the amount of payment greater than $1 in $xx.xx format",
            "When do you want to make a payment? \n            Text 1 - Due Date 08/02/2020\n            Text 2 - Today 07/15/2020\n         Text 3 - A different date",
            "We have your account information from previous payments you have made\nWhich account do you want to use for your payment?  Please text #\n1- Account ending in 3232\n2- Account ending in 6789",
            "Almost done: let's confirm the payment information and get your authorization to make the payment. To confirm, today is 07/15/2020 and you are agreeing to a one-time payment of $2.00 towards your The Home Depot® Consumer Credit Card ending in 8098, from your bank account ending in 3232 posting on 07/15/2020\n\nYou may cancel or change this payment online or by calling us at the number on the back of your card before 5:00 pm Eastern time on the day of your scheduled payment.\n\nText Y if the payment information above is correct\nText N to make changes",
            "Hmm.. You have reached the maximum number of payments that can be made on the selected date. Please adjust your payment date, or wait for the first payment to be posted.\n\nWhen do you want to make a payment? \n            Text 1 - Due Date 08/02/2020\n            Text 2 - Today 07/14/2020\n         Text 3 - A different date"
        ]
    },


    "No_payment_source": {
        "input": [
            "discard all",
            "clearsession",
            "Hi",
            "8098",
            "pay",
            "0222"
        ],
        "output": [
            "@@@@",
            "@@@@",
            "@@@@",
            "@@@@",
            "Which account do you want to pay?  Please text\n#1-Account ending in 9994\n#2-Account ending in 7935\n#3-Account ending in 8098\n#4-Account ending in 0222\n#5-Account ending in 6591\n#6-Account ending in 8310\n#7-Account ending in 0198\n#8-Account ending in 0214",
            "It appears that either you do not have an existing payment source on file, or the payment source cannot be utilized for pay by text. Please click the link below to setup your payment source or contact the customer service number on the back of your credit card to make a payment.\npay.homedepotconsumer.accountonline.com\n\nIs there anything else I can help you with today?"

        ]
    },


    "More_than_outstanding_balance_to_SSN": {
        "input": [
            "discard all",
            "clearsession",
            "Hi",
            "8098",
            "pay",
            "8098",
            "yes",
            "4",
            "10000",
            "3",
            "08/01/2020",
            "1",
            "yes",
            "4",
            "2",
            "yes"
        ],
        "output": [
            "@@@@",
            "@@@@",
            "@@@@",
            "@@@@",
            "Which account do you want to pay?  Please text\n#1-Account ending in 9994\n#2-Account ending in 7935\n#3-Account ending in 8098\n#4-Account ending in 0222\n#5-Account ending in 6591\n#6-Account ending in 8310\n#7-Account ending in 0198\n#8-Account ending in 0214",
            "Before we begin, you should know that your account information, including last statement balance, current balance and minimum payment due, will be displayed on this device and any other device where you receive text messages. Do you want to continue and allow this information to be displayed?",
            "It looks like:\nYour Minimum Due is $0.00\nYour Last Statement Balance was $13492.46\nYour Current Balance is $2000.00\n\nWhat type of payment would you like to make?\nText 1 for Minimum Due\nText 2 for Last Statement Balance\nText 3 for Current Balance\nText 4 for Other Amount",
            "Please enter the amount of payment greater than $1 in $xx.xx format",
            "When do you want to make a payment? \n            Text 1 - Due Date 08/02/2020\n            Text 2 - Today 07/15/2020\n         Text 3 - A different date",
            "Please enter a valid date in MM/DD/YYYY format",
            "We have your account information from previous payments you have made\nWhich account do you want to use for your payment?  Please text #\n1- Account ending in 3232\n2- Account ending in 6789",
            "Almost done: let's confirm the payment information and get your authorization to make the payment. To confirm, today is 07/15/2020 and you are agreeing to a one-time payment of $10000.00 towards your The Home Depot® Consumer Credit Card ending in 8098, from your bank account ending in 3232 posting on 08/01/2020\n\nYou may cancel or change this payment online or by calling us at the number on the back of your card before 5:00 pm Eastern time on the day of your scheduled payment.\n\nText Y if the payment information above is correct\nText N to make changes",
            "Hmm.. You have exceeded the payment amount that can be scheduled for this account. Your maximum amount is the current balance.\n\nIt looks like:\nYour Minimum Due is $0.00\nYour Last Statement Balance was $13492.46\nYour Current Balance is $2000.00\n\n\nWhat type of payment would you like to make?\nText 1 for Minimum Due\nText 2 for Last Statement Balance\nText 3 for Current Balance\nText 4 for Other Amount",
            "Please enter the amount of payment greater than $1 in $xx.xx format",
            "Almost done: let's confirm the payment information and get your authorization to make the payment. To confirm, today is 07/15/2020 and you are agreeing to a one-time payment of $2.00 towards your The Home Depot® Consumer Credit Card ending in 8098, from your bank account ending in 3232 posting on 08/01/2020\n\nYou may cancel or change this payment online or by calling us at the number on the back of your card before 5:00 pm Eastern time on the day of your scheduled payment.\n\nText Y if the payment information above is correct\nText N to make changes",
            "Do I have your authorization to schedule this payment now? \n  Please text the last 4 digits of the primary account holder's SSN to authorize this payment.\n Text N if you do not authorize this payment."


        ]
    },


    "No_Outstanding_balance": {
        "input": [
            "discard all",
            "clearsession",
            "Hi",
            "8098",
            "pay",
            "8310"
        ],
        "output": [
            "@@@@",
            "@@@@",
            "@@@@",
            "@@@@",
            "Which account do you want to pay?  Please text\n#1-Account ending in 9994\n#2-Account ending in 7935\n#3-Account ending in 8098\n#4-Account ending in 0222\n#5-Account ending in 6591\n#6-Account ending in 8310\n#7-Account ending in 0198\n#8-Account ending in 0214",
            "At this time there is no outstanding balance due on your account. Please check your balance and payment details in the next billing cycle.\n\nIs there anything else I can help you with today?"
        ]
    },



    "ValidationError_Schedule_payment_morethan_45_days": {
        "input": [
            "discard all",
            "clearsession",
            "Hi",
            "8098",
            "pay",
            "8098",
            "yes",
            "4",
            "2",
            "3",
            "09/20/2020",
            "1",
            "yes",
            "3",
            "08/01/2020",
            "yes"
        ],
        "output": [
            "@@@@",
            "@@@@",
            "@@@@",
            "@@@@",
            "Which account do you want to pay?  Please text\n#1-Account ending in 9994\n#2-Account ending in 7935\n#3-Account ending in 8098\n#4-Account ending in 0222\n#5-Account ending in 6591\n#6-Account ending in 8310\n#7-Account ending in 0198\n#8-Account ending in 0214",
            "Before we begin, you should know that your account information, including last statement balance, current balance and minimum payment due, will be displayed on this device and any other device where you receive text messages. Do you want to continue and allow this information to be displayed?",
            "It looks like:\nYour Minimum Due is $0.00\nYour Last Statement Balance was $13492.46\nYour Current Balance is $2000.00\n\nWhat type of payment would you like to make?\nText 1 for Minimum Due\nText 2 for Last Statement Balance\nText 3 for Current Balance\nText 4 for Other Amount",
            "Please enter the amount of payment greater than $1 in $xx.xx format",
            "When do you want to make a payment? \n            Text 1 - Due Date 08/02/2020\n            Text 2 - Today 07/14/2020\n         Text 3 - A different date",
            "Please enter a valid date in MM/DD/YYYY format",
            "We have your account information from previous payments you have made\nWhich account do you want to use for your payment?  Please text #\n1- Account ending in 3232\n2- Account ending in 6789",
            "Almost done: let's confirm the payment information and get your authorization to make the payment. To confirm, today is 07/14/2020 and you are agreeing to a one-time payment of $2.00 towards your The Home Depot® Consumer Credit Card ending in 8098, from your bank account ending in 3232 posting on 09/20/2020\n\nYou may cancel or change this payment online or by calling us at the number on the back of your card before 5:00 pm Eastern time on the day of your scheduled payment.\n\nText Y if the payment information above is correct\nText N to make changes",
            "Hmm.. You can schedule payments between today and 45 days in the future. Please type a date [MM/DD/YYYY] within 45 days from today.\n\nWhen do you want to make a payment? \n            Text 1 - Due Date 08/02/2020\n            Text 2 - Today 07/14/2020\n         Text 3 - A different date",
            "Please enter a valid date in MM/DD/YYYY format",
            "Almost done: let's confirm the payment information and get your authorization to make the payment. To confirm, today is 07/14/2020 and you are agreeing to a one-time payment of $2.00 towards your The Home Depot® Consumer Credit Card ending in 8098, from your bank account ending in 3232 posting on 08/01/2020\n\nYou may cancel or change this payment online or by calling us at the number on the back of your card before 5:00 pm Eastern time on the day of your scheduled payment.\n\nText Y if the payment information above is correct\nText N to make changes",
            "Do I have your authorization to schedule this payment now? \n  Please text the last 4 digits of the primary account holder's SSN to authorize this payment.\n Text N if you do not authorize this payment."

        ]
    },

    "ValidationError_Multiple_validation_errors": {
        "input": [
            "discard all",
            "clearsession",
            "Hi",
            "8098",
            "pay",
            "8098",
            "yes",
            "4",
            "10000",
            "3",
            "09/20/2020",
            "1",
            "yes"

        ],
        "output": [
            "@@@@",
            "@@@@",
            "@@@@",
            "@@@@",
            "Which account do you want to pay?  Please text\n#1-Account ending in 9994\n#2-Account ending in 7935\n#3-Account ending in 8098\n#4-Account ending in 0222\n#5-Account ending in 6591\n#6-Account ending in 8310\n#7-Account ending in 0198\n#8-Account ending in 0214",
            "Before we begin, you should know that your account information, including last statement balance, current balance and minimum payment due, will be displayed on this device and any other device where you receive text messages. Do you want to continue and allow this information to be displayed?",
            "It looks like:\nYour Minimum Due is $0.00\nYour Last Statement Balance was $13492.46\nYour Current Balance is $2000.00\n\nWhat type of payment would you like to make?\nText 1 for Minimum Due\nText 2 for Last Statement Balance\nText 3 for Current Balance\nText 4 for Other Amount",
            "Please enter the amount of payment greater than $1 in $xx.xx format",
            "When do you want to make a payment? \n            Text 1 - Due Date 08/02/2020\n            Text 2 - Today 07/14/2020\n         Text 3 - A different date",
            "Please enter a valid date in MM/DD/YYYY format",
            "We have your account information from previous payments you have made\nWhich account do you want to use for your payment?  Please text #\n1- Account ending in 3232\n2- Account ending in 6789",
            "Almost done: let's confirm the payment information and get your authorization to make the payment. To confirm, today is 07/14/2020 and you are agreeing to a one-time payment of $10000.00 towards your The Home Depot® Consumer Credit Card ending in 8098, from your bank account ending in 3232 posting on 09/20/2020\n\nYou may cancel or change this payment online or by calling us at the number on the back of your card before 5:00 pm Eastern time on the day of your scheduled payment.\n\nText Y if the payment information above is correct\nText N to make changes",
            "Hmm.. You can schedule payments between today and 45 days in the future. Please type a date [MM/DD/YYYY] within 45 days from today.\n\nHmm.. You have exceeded the payment amount that can be scheduled for this account. Your maximum amount is the current balance.\n\nIt looks like:\nYour Minimum Due is $0.00\nYour Last Statement Balance was $13492.46\nYour Current Balance is $2000.00\n\nWhat type of payment would you like to make?\nText 1 for Minimum Due\nText 2 for Last Statement Balance\nText 3 for Current Balance\nText 4 for Other Amount"
        ]
    }
}





function addDataToTable(data) {
    var table = $("#" + data.name + "Id");
    // for (let i = 0; i < covaTableData.length; i++) {
    var row = $("<tr></tr>").appendTo(table);
    $("<td>" + counter + "</td>").appendTo(row);
    $("<td></td>").text(data.input).appendTo(row);
    $("<td></td>").text(data.expectedOutPut).appendTo(row);
    $("<td></td>").text(data.actualOutput).appendTo(row);
    if (data.status === "pass") {
        $("<td class='passData'></td>").text(data.status.toUpperCase()).appendTo(row);
    } else {
        $("<td class='failData'></td>").text(data.status.toUpperCase()).appendTo(row);
    }
    $("<td></td>").text(data.score).appendTo(row);
}



var testcases = Object.keys(testCasesConfig);
// Optional: Clear all existing options first:
select.innerHTML = "";
// Populate list with options:
for (var i = 0; i < testcases.length; i++) {
    var opt = testcases[i];
    select.innerHTML += "<option value=\"" + opt + "\">" + opt + "</option>";
}



