

var memes = [
    'Dude, you smashed my turtle saying "I\'M MARIO BROS!"',
    'Dude, you grabed seven oranges and yelled "I GOT THE DRAGON BALLS!"',
    'Dude, you threw my hamster across the room and said "PIKACHU I CHOOSE YOU!"',
    'Dude, you congratulated a potato for getting a part in Toy Story',
    'Dude, you were hugging an old man with a beard screaming "DUMBLEDORE YOU\'RE ALIVE!"',
    'Dude, you were cutting all my pinapples yelling "SPONGEBOB! I KNOW YOU\'RE THERE!"',
];

var random = document.querySelector('#random');

var counter = 0;

//random.innerHTML = memes[Math.floor(Math.random() * memes.length)];

/* Time */

var deviceTime = document.querySelector('.status-bar .time');
var messageTime = document.querySelectorAll('.message .time');

deviceTime.innerHTML = moment().format('h:mm');

setInterval(function () {
    deviceTime.innerHTML = moment().format('h:mm');
}, 1000);

for (var i = 0; i < messageTime.length; i++) {
    messageTime[i].innerHTML = moment().format('h:mm A');
}

/* Message */

//var form = document.querySelector('.conversation-compose');
var conversation = document.querySelector('.conversation-container');

//form.addEventListener('submit', newMessage);

$(document).ready(function () {
    $("span#siteId").text(getQueryStringValue("siteId").toUpperCase());
    $("#sendbutton").on("click", function () {
        newMessage();
    });
});

$('#userInput').keypress(function (e) {
    if (e.which == 13) {
        newMessage();
    }
});

function newMessage() {
    var input = document.getElementById("userInput").value;
    if (input) {
        var message = buildMessage(input);
        conversation.appendChild(message);
        //animateMessage(message);
        makeApiCall(input)
    }
    document.getElementById('userInput').value = ''
    conversation.scrollTop = conversation.scrollHeight;
    //e.preventDefault();
}

function getQueryStringValue(key) {
    return decodeURIComponent(window.location.search.replace(new RegExp("^(?:.*[&\\?]" + encodeURIComponent(key).replace(/[\.\+\*]/g, "\\$&") + "(?:\\=([^&]*))?)?.*$", "i"), "$1"));
}

var environments = {
    "DIT": {
        "url": "https://b172935-vip.nam.nsroot.net/chatbot/hooks/st-fc77c68b-a12c-5024-aae0-7aa1680690fa",
        "token": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwiYXBwSWQiOiJjcy1iODAxZDRlOS1iNTEwLTU0ZDYtOWNjNC0xNDJmZDhlN2NiMWQifQ.-Yoh1De6cltL3WFpN7T_95Y6n-0lt_n2dIKXjFdWatU",
        "botId": "st-fc77c68b-a12c-5024-aae0-7aa1680690fa"
    },
    "UAT": {
        "url": "https://uat.botbuilder.consumerna.citigroup.net/chatbot/hooks/st-5bda0ad1-6529-5279-948e-7d70bf790d80",
        "token": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwiYXBwSWQiOiJjcy0yYzk4ZGI0Zi1lNjQ5LTUzMTItOTk2Yi1jNDk5NmViZDVkYTYifQ.cEtnafkPuwgC7ef5igbaWlz_khIUfNhHwo_zg8nZGq4",
        "botId": "st-5bda0ad1-6529-5279-948e-7d70bf790d80"
    }
}

function makeApiCall(queryString) {

    //var type = getQueryStringValue("type").toLocaleLowerCase();
    var siteId = getQueryStringValue("siteId").toLocaleUpperCase();
    var phoneNumber = getQueryStringValue("phoneNumber")
    var env = "DIT";
     env = getQueryStringValue("env")
    


    var body = {
        "from": {
            "id": "+1" + phoneNumber + "@" + siteId
        },
        "to": {
            "id": environments[env].botId,
        },
        "message": {
            "text": queryString
        },
        "session": {
            "new": true
        },
        "siteId": siteId,
        "channelId": "SMSAG",
        "uuid": counter + "_" + phoneNumber + "_" + siteId + "_" + Math.round(new Date().getTime() / 1000)
    }
    counter = counter + 1;
    console.log(JSON.stringify(body));
    $.ajax({
        url: environments[env].url,
        type: "POST",
        dataType: "json",
        headers: {
            "Authorization": environments[env].token,
            "Content-Type": "application/json"
        },
        data: JSON.stringify(body),
        success: function (response) {
            console.log(response);
            var responseText = response.text;
            if (Array.isArray(responseText)) {
                responseText.forEach(function (element) {
                    console.log(" in Array " + element + " typeof element" + typeof element);
                    let msg;
                    if (IsJsonString(element)) {
                        msg = JSON.parse(element).textmessage;
                        if (msg.textmessage) {
                            msg = msg.textmessage;
                        }
                    } else if (typeof element === 'object') {
                        msg = element.textmessage;
                    } else {
                        msg = element;
                    }
                    let message = buildIncomingMessage(msg);
                    conversation.appendChild(message);
                    //animateMessage(message);

                });
            } else if (responseText instanceof Object) {
                console.log(" in object " + element);

                let message = buildIncomingMessage(JSON.parse(responseText).text);
                conversation.appendChild(message);
                //animateMessage(message);
            } else {
                console.log(" in default " + responseText + " type of: " + typeof responseText);
                let msg;
                if (IsJsonString(responseText)) {
                    msg = JSON.parse(responseText).textmessage;
                    if (!msg) {
                        msg = JSON.parse(responseText).text;
                    }
                } else {
                    msg = responseText;
                }

                let message = buildIncomingMessage(msg);
                conversation.appendChild(message);
                //animateMessage(message);
            };
            conversation.scrollTop = conversation.scrollHeight;
        },
        error: function () {
            console.log("error");
        }
    });
}

function buildMessage(text) {
    var element = document.createElement('div');
    element.classList.add('message', 'sent');
    element.innerHTML = text +
        '<span class="metadata">' +
        '<span class="sentTime">' + moment().format('h:mm A') + '</span>' +
        '</span>';

    return element;
}

function urlify(text) {
    var urlRegex = /(https?:\/\/[^\s]+)/g;
    return text.replace(urlRegex, function (url) {
        return '<a href="' + url + '">' + url + '</a>';
    })
}



function buildIncomingMessage(text) {
    console.log('buildIncomingMessage: ' + text);
    //text = text.split("#").join("");
    text = text.split("\n").join("<br>");
    text = urlify(text);
    if (!text) {
        text = "Looks like I had a technical issue on my end and I need to back up a sec. What do you need help with?";
    }
    var element = document.createElement('div');
    element.classList.add('message', 'received');
    element.innerHTML = '<div>' + text + '</div>'
    '<span class="metadata">' +
        '<span class="time">' + moment().format('h:mm A') + '</span>' +
        '</span>';

    return element;
}


function IsJsonString(str) {
    try {
        JSON.parse(str);
    } catch (e) {
        return false;
    }
    return true;
}

function animateMessage(message) {
    setTimeout(function () {
        var tick = message.querySelector('.tick');
        tick.classList.remove('tick-animation');
    }, 500);
}








